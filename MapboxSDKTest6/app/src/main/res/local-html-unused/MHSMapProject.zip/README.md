MAp Project Web View Test

style.css, replit.nix, and .replit are not part of the main runnable code technecally.
Observers ignore that.
