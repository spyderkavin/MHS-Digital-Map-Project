(function (f) {
  if (typeof exports === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;
    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }
    g.MapboxDirections = f();
  }
})(function () {
  var define, module, exports;
  return (function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw ((a.code = "MODULE_NOT_FOUND"), a);
          }
          var p = (n[i] = { exports: {} });
          e[i][0].call(
            p.exports,
            function (r) {
              var n = e[i][1][r];
              return o(n || r);
            },
            p,
            p.exports,
            r,
            e,
            n,
            t
          );
        }
        return n[i].exports;
      }
      for (
        var u = "function" == typeof require && require, i = 0;
        i < t.length;
        i++
      )
        o(t[i]);
      return o;
    }
    return r;
  })()(
    {
      1: [
        function (require, module, exports) {
          var toPropertyKey = require("./toPropertyKey.js");
          function _defineProperty(obj, key, value) {
            key = toPropertyKey(key);
            if (key in obj) {
              Object.defineProperty(obj, key, {
                value: value,
                enumerable: true,
                configurable: true,
                writable: true,
              });
            } else {
              obj[key] = value;
            }
            return obj;
          }
          (module.exports = _defineProperty),
            (module.exports.__esModule = true),
            (module.exports["default"] = module.exports);
        },
        { "./toPropertyKey.js": 4 },
      ],
      2: [
        function (require, module, exports) {
          var defineProperty = require("./defineProperty.js");
          function ownKeys(object, enumerableOnly) {
            var keys = Object.keys(object);
            if (Object.getOwnPropertySymbols) {
              var symbols = Object.getOwnPropertySymbols(object);
              enumerableOnly &&
                (symbols = symbols.filter(function (sym) {
                  return Object.getOwnPropertyDescriptor(
                    object,
                    sym
                  ).enumerable;
                })),
                keys.push.apply(keys, symbols);
            }
            return keys;
          }
          function _objectSpread2(target) {
            for (var i = 1; i < arguments.length; i++) {
              var source = null != arguments[i] ? arguments[i] : {};
              i % 2
                ? ownKeys(Object(source), !0).forEach(function (key) {
                    defineProperty(target, key, source[key]);
                  })
                : Object.getOwnPropertyDescriptors
                ? Object.defineProperties(
                    target,
                    Object.getOwnPropertyDescriptors(source)
                  )
                : ownKeys(Object(source)).forEach(function (key) {
                    Object.defineProperty(
                      target,
                      key,
                      Object.getOwnPropertyDescriptor(source, key)
                    );
                  });
            }
            return target;
          }
          (module.exports = _objectSpread2),
            (module.exports.__esModule = true),
            (module.exports["default"] = module.exports);
        },
        { "./defineProperty.js": 1 },
      ],
      3: [
        function (require, module, exports) {
          var _typeof = require("./typeof.js")["default"];
          function _toPrimitive(input, hint) {
            if (_typeof(input) !== "object" || input === null) return input;
            var prim = input[Symbol.toPrimitive];
            if (prim !== undefined) {
              var res = prim.call(input, hint || "default");
              if (_typeof(res) !== "object") return res;
              throw new TypeError(
                "@@toPrimitive must return a primitive value."
              );
            }
            return (hint === "string" ? String : Number)(input);
          }
          (module.exports = _toPrimitive),
            (module.exports.__esModule = true),
            (module.exports["default"] = module.exports);
        },
        { "./typeof.js": 5 },
      ],
      4: [
        function (require, module, exports) {
          var _typeof = require("./typeof.js")["default"];
          var toPrimitive = require("./toPrimitive.js");
          function _toPropertyKey(arg) {
            var key = toPrimitive(arg, "string");
            return _typeof(key) === "symbol" ? key : String(key);
          }
          (module.exports = _toPropertyKey),
            (module.exports.__esModule = true),
            (module.exports["default"] = module.exports);
        },
        { "./toPrimitive.js": 3, "./typeof.js": 5 },
      ],
      5: [
        function (require, module, exports) {
          function _typeof(obj) {
            "@babel/helpers - typeof";

            return (
              ((module.exports = _typeof =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (obj) {
                      return typeof obj;
                    }
                  : function (obj) {
                      return obj &&
                        "function" == typeof Symbol &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? "symbol"
                        : typeof obj;
                    }),
              (module.exports.__esModule = true),
              (module.exports["default"] = module.exports)),
              _typeof(obj)
            );
          }
          (module.exports = _typeof),
            (module.exports.__esModule = true),
            (module.exports["default"] = module.exports);
        },
        {},
      ],
      6: [
        function (require, module, exports) {
          "use strict";

          /**
           * Based off of [the offical Google document](https://developers.google.com/maps/documentation/utilities/polylinealgorithm)
           *
           * Some parts from [this implementation](http://facstaff.unca.edu/mcmcclur/GoogleMaps/EncodePolyline/PolylineEncoder.js)
           * by [Mark McClure](http://facstaff.unca.edu/mcmcclur/)
           *
           * @module polyline
           */

          var polyline = {};

          function py2_round(value) {
            // Google's polyline algorithm uses the same rounding strategy as Python 2, which is different from JS for negative values
            return Math.floor(Math.abs(value) + 0.5) * (value >= 0 ? 1 : -1);
          }

          function encode(current, previous, factor) {
            current = py2_round(current * factor);
            previous = py2_round(previous * factor);
            var coordinate = current - previous;
            coordinate <<= 1;
            if (current - previous < 0) {
              coordinate = ~coordinate;
            }
            var output = "";
            while (coordinate >= 0x20) {
              output += String.fromCharCode((0x20 | (coordinate & 0x1f)) + 63);
              coordinate >>= 5;
            }
            output += String.fromCharCode(coordinate + 63);
            return output;
          }

          /**
           * Decodes to a [latitude, longitude] coordinates array.
           *
           * This is adapted from the implementation in Project-OSRM.
           *
           * @param {String} str
           * @param {Number} precision
           * @returns {Array}
           *
           * @see https://github.com/Project-OSRM/osrm-frontend/blob/master/WebContent/routing/OSRM.RoutingGeometry.js
           */
          polyline.decode = function (str, precision) {
            var index = 0,
              lat = 0,
              lng = 0,
              coordinates = [],
              shift = 0,
              result = 0,
              byte = null,
              latitude_change,
              longitude_change,
              factor = Math.pow(
                10,
                Number.isInteger(precision) ? precision : 5
              );

            // Coordinates have variable length when encoded, so just keep
            // track of whether we've hit the end of the string. In each
            // loop iteration, a single coordinate is decoded.
            while (index < str.length) {
              // Reset shift, result, and byte
              byte = null;
              shift = 0;
              result = 0;

              do {
                byte = str.charCodeAt(index++) - 63;
                result |= (byte & 0x1f) << shift;
                shift += 5;
              } while (byte >= 0x20);

              latitude_change = result & 1 ? ~(result >> 1) : result >> 1;

              shift = result = 0;

              do {
                byte = str.charCodeAt(index++) - 63;
                result |= (byte & 0x1f) << shift;
                shift += 5;
              } while (byte >= 0x20);

              longitude_change = result & 1 ? ~(result >> 1) : result >> 1;

              lat += latitude_change;
              lng += longitude_change;

              coordinates.push([lat / factor, lng / factor]);
            }

            return coordinates;
          };

          /**
           * Encodes the given [latitude, longitude] coordinates array.
           *
           * @param {Array.<Array.<Number>>} coordinates
           * @param {Number} precision
           * @returns {String}
           */
          polyline.encode = function (coordinates, precision) {
            if (!coordinates.length) {
              return "";
            }

            var factor = Math.pow(
                10,
                Number.isInteger(precision) ? precision : 5
              ),
              output =
                encode(coordinates[0][0], 0, factor) +
                encode(coordinates[0][1], 0, factor);

            for (var i = 1; i < coordinates.length; i++) {
              var a = coordinates[i],
                b = coordinates[i - 1];
              output += encode(a[0], b[0], factor);
              output += encode(a[1], b[1], factor);
            }

            return output;
          };

          function flipped(coords) {
            var flipped = [];
            for (var i = 0; i < coords.length; i++) {
              var coord = coords[i].slice();
              flipped.push([coord[1], coord[0]]);
            }
            return flipped;
          }

          /**
           * Encodes a GeoJSON LineString feature/geometry.
           *
           * @param {Object} geojson
           * @param {Number} precision
           * @returns {String}
           */
          polyline.fromGeoJSON = function (geojson, precision) {
            if (geojson && geojson.type === "Feature") {
              geojson = geojson.geometry;
            }
            if (!geojson || geojson.type !== "LineString") {
              throw new Error("Input must be a GeoJSON LineString");
            }
            return polyline.encode(flipped(geojson.coordinates), precision);
          };

          /**
           * Decodes to a GeoJSON LineString geometry.
           *
           * @param {String} str
           * @param {Number} precision
           * @returns {Object}
           */
          polyline.toGeoJSON = function (str, precision) {
            var coords = polyline.decode(str, precision);
            return {
              type: "LineString",
              coordinates: flipped(coords),
            };
          };

          if (typeof module === "object" && module.exports) {
            module.exports = polyline;
          }
        },
        {},
      ],
      7: [
        function (require, module, exports) {
          // Copyright Joyent, Inc. and other Node contributors.
          //
          // Permission is hereby granted, free of charge, to any person obtaining a
          // copy of this software and associated documentation files (the
          // "Software"), to deal in the Software without restriction, including
          // without limitation the rights to use, copy, modify, merge, publish,
          // distribute, sublicense, and/or sell copies of the Software, and to permit
          // persons to whom the Software is furnished to do so, subject to the
          // following conditions:
          //
          // The above copyright notice and this permission notice shall be included
          // in all copies or substantial portions of the Software.
          //
          // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
          // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
          // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
          // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
          // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
          // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
          // USE OR OTHER DEALINGS IN THE SOFTWARE.

          "use strict";

          var R = typeof Reflect === "object" ? Reflect : null;
          var ReflectApply =
            R && typeof R.apply === "function"
              ? R.apply
              : function ReflectApply(target, receiver, args) {
                  return Function.prototype.apply.call(target, receiver, args);
                };

          var ReflectOwnKeys;
          if (R && typeof R.ownKeys === "function") {
            ReflectOwnKeys = R.ownKeys;
          } else if (Object.getOwnPropertySymbols) {
            ReflectOwnKeys = function ReflectOwnKeys(target) {
              return Object.getOwnPropertyNames(target).concat(
                Object.getOwnPropertySymbols(target)
              );
            };
          } else {
            ReflectOwnKeys = function ReflectOwnKeys(target) {
              return Object.getOwnPropertyNames(target);
            };
          }

          function ProcessEmitWarning(warning) {
            if (console && console.warn) console.warn(warning);
          }

          var NumberIsNaN =
            Number.isNaN ||
            function NumberIsNaN(value) {
              return value !== value;
            };

          function EventEmitter() {
            EventEmitter.init.call(this);
          }
          module.exports = EventEmitter;
          module.exports.once = once;

          // Backwards-compat with node 0.10.x
          EventEmitter.EventEmitter = EventEmitter;

          EventEmitter.prototype._events = undefined;
          EventEmitter.prototype._eventsCount = 0;
          EventEmitter.prototype._maxListeners = undefined;

          // By default EventEmitters will print a warning if more than 10 listeners are
          // added to it. This is a useful default which helps finding memory leaks.
          var defaultMaxListeners = 10;

          function checkListener(listener) {
            if (typeof listener !== "function") {
              throw new TypeError(
                'The "listener" argument must be of type Function. Received type ' +
                  typeof listener
              );
            }
          }

          Object.defineProperty(EventEmitter, "defaultMaxListeners", {
            enumerable: true,
            get: function () {
              return defaultMaxListeners;
            },
            set: function (arg) {
              if (typeof arg !== "number" || arg < 0 || NumberIsNaN(arg)) {
                throw new RangeError(
                  'The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' +
                    arg +
                    "."
                );
              }
              defaultMaxListeners = arg;
            },
          });

          EventEmitter.init = function () {
            if (
              this._events === undefined ||
              this._events === Object.getPrototypeOf(this)._events
            ) {
              this._events = Object.create(null);
              this._eventsCount = 0;
            }

            this._maxListeners = this._maxListeners || undefined;
          };

          // Obviously not all Emitters should be limited to 10. This function allows
          // that to be increased. Set to zero for unlimited.
          EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
            if (typeof n !== "number" || n < 0 || NumberIsNaN(n)) {
              throw new RangeError(
                'The value of "n" is out of range. It must be a non-negative number. Received ' +
                  n +
                  "."
              );
            }
            this._maxListeners = n;
            return this;
          };

          function _getMaxListeners(that) {
            if (that._maxListeners === undefined)
              return EventEmitter.defaultMaxListeners;
            return that._maxListeners;
          }

          EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
            return _getMaxListeners(this);
          };

          EventEmitter.prototype.emit = function emit(type) {
            var args = [];
            for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
            var doError = type === "error";

            var events = this._events;
            if (events !== undefined)
              doError = doError && events.error === undefined;
            else if (!doError) return false;

            // If there is no 'error' event listener then throw.
            if (doError) {
              var er;
              if (args.length > 0) er = args[0];
              if (er instanceof Error) {
                // Note: The comments on the `throw` lines are intentional, they show
                // up in Node's output if this results in an unhandled exception.
                throw er; // Unhandled 'error' event
              }
              // At least give some kind of context to the user
              var err = new Error(
                "Unhandled error." + (er ? " (" + er.message + ")" : "")
              );
              err.context = er;
              throw err; // Unhandled 'error' event
            }

            var handler = events[type];

            if (handler === undefined) return false;

            if (typeof handler === "function") {
              ReflectApply(handler, this, args);
            } else {
              var len = handler.length;
              var listeners = arrayClone(handler, len);
              for (var i = 0; i < len; ++i)
                ReflectApply(listeners[i], this, args);
            }

            return true;
          };

          function _addListener(target, type, listener, prepend) {
            var m;
            var events;
            var existing;

            checkListener(listener);

            events = target._events;
            if (events === undefined) {
              events = target._events = Object.create(null);
              target._eventsCount = 0;
            } else {
              // To avoid recursion in the case that type === "newListener"! Before
              // adding it to the listeners, first emit "newListener".
              if (events.newListener !== undefined) {
                target.emit(
                  "newListener",
                  type,
                  listener.listener ? listener.listener : listener
                );

                // Re-assign `events` because a newListener handler could have caused the
                // this._events to be assigned to a new object
                events = target._events;
              }
              existing = events[type];
            }

            if (existing === undefined) {
              // Optimize the case of one listener. Don't need the extra array object.
              existing = events[type] = listener;
              ++target._eventsCount;
            } else {
              if (typeof existing === "function") {
                // Adding the second element, need to change to array.
                existing = events[type] = prepend
                  ? [listener, existing]
                  : [existing, listener];
                // If we've already got an array, just append.
              } else if (prepend) {
                existing.unshift(listener);
              } else {
                existing.push(listener);
              }

              // Check for listener leak
              m = _getMaxListeners(target);
              if (m > 0 && existing.length > m && !existing.warned) {
                existing.warned = true;
                // No error code for this since it is a Warning
                // eslint-disable-next-line no-restricted-syntax
                var w = new Error(
                  "Possible EventEmitter memory leak detected. " +
                    existing.length +
                    " " +
                    String(type) +
                    " listeners " +
                    "added. Use emitter.setMaxListeners() to " +
                    "increase limit"
                );
                w.name = "MaxListenersExceededWarning";
                w.emitter = target;
                w.type = type;
                w.count = existing.length;
                ProcessEmitWarning(w);
              }
            }

            return target;
          }

          EventEmitter.prototype.addListener = function addListener(
            type,
            listener
          ) {
            return _addListener(this, type, listener, false);
          };

          EventEmitter.prototype.on = EventEmitter.prototype.addListener;

          EventEmitter.prototype.prependListener = function prependListener(
            type,
            listener
          ) {
            return _addListener(this, type, listener, true);
          };

          function onceWrapper() {
            if (!this.fired) {
              this.target.removeListener(this.type, this.wrapFn);
              this.fired = true;
              if (arguments.length === 0)
                return this.listener.call(this.target);
              return this.listener.apply(this.target, arguments);
            }
          }

          function _onceWrap(target, type, listener) {
            var state = {
              fired: false,
              wrapFn: undefined,
              target: target,
              type: type,
              listener: listener,
            };
            var wrapped = onceWrapper.bind(state);
            wrapped.listener = listener;
            state.wrapFn = wrapped;
            return wrapped;
          }

          EventEmitter.prototype.once = function once(type, listener) {
            checkListener(listener);
            this.on(type, _onceWrap(this, type, listener));
            return this;
          };

          EventEmitter.prototype.prependOnceListener =
            function prependOnceListener(type, listener) {
              checkListener(listener);
              this.prependListener(type, _onceWrap(this, type, listener));
              return this;
            };

          // Emits a 'removeListener' event if and only if the listener was removed.
          EventEmitter.prototype.removeListener = function removeListener(
            type,
            listener
          ) {
            var list, events, position, i, originalListener;

            checkListener(listener);

            events = this._events;
            if (events === undefined) return this;

            list = events[type];
            if (list === undefined) return this;

            if (list === listener || list.listener === listener) {
              if (--this._eventsCount === 0) this._events = Object.create(null);
              else {
                delete events[type];
                if (events.removeListener)
                  this.emit("removeListener", type, list.listener || listener);
              }
            } else if (typeof list !== "function") {
              position = -1;

              for (i = list.length - 1; i >= 0; i--) {
                if (list[i] === listener || list[i].listener === listener) {
                  originalListener = list[i].listener;
                  position = i;
                  break;
                }
              }

              if (position < 0) return this;

              if (position === 0) list.shift();
              else {
                spliceOne(list, position);
              }

              if (list.length === 1) events[type] = list[0];

              if (events.removeListener !== undefined)
                this.emit("removeListener", type, originalListener || listener);
            }

            return this;
          };

          EventEmitter.prototype.off = EventEmitter.prototype.removeListener;

          EventEmitter.prototype.removeAllListeners =
            function removeAllListeners(type) {
              var listeners, events, i;

              events = this._events;
              if (events === undefined) return this;

              // not listening for removeListener, no need to emit
              if (events.removeListener === undefined) {
                if (arguments.length === 0) {
                  this._events = Object.create(null);
                  this._eventsCount = 0;
                } else if (events[type] !== undefined) {
                  if (--this._eventsCount === 0)
                    this._events = Object.create(null);
                  else delete events[type];
                }
                return this;
              }

              // emit removeListener for all listeners on all events
              if (arguments.length === 0) {
                var keys = Object.keys(events);
                var key;
                for (i = 0; i < keys.length; ++i) {
                  key = keys[i];
                  if (key === "removeListener") continue;
                  this.removeAllListeners(key);
                }
                this.removeAllListeners("removeListener");
                this._events = Object.create(null);
                this._eventsCount = 0;
                return this;
              }

              listeners = events[type];

              if (typeof listeners === "function") {
                this.removeListener(type, listeners);
              } else if (listeners !== undefined) {
                // LIFO order
                for (i = listeners.length - 1; i >= 0; i--) {
                  this.removeListener(type, listeners[i]);
                }
              }

              return this;
            };

          function _listeners(target, type, unwrap) {
            var events = target._events;

            if (events === undefined) return [];

            var evlistener = events[type];
            if (evlistener === undefined) return [];

            if (typeof evlistener === "function")
              return unwrap
                ? [evlistener.listener || evlistener]
                : [evlistener];

            return unwrap
              ? unwrapListeners(evlistener)
              : arrayClone(evlistener, evlistener.length);
          }

          EventEmitter.prototype.listeners = function listeners(type) {
            return _listeners(this, type, true);
          };

          EventEmitter.prototype.rawListeners = function rawListeners(type) {
            return _listeners(this, type, false);
          };

          EventEmitter.listenerCount = function (emitter, type) {
            if (typeof emitter.listenerCount === "function") {
              return emitter.listenerCount(type);
            } else {
              return listenerCount.call(emitter, type);
            }
          };

          EventEmitter.prototype.listenerCount = listenerCount;
          function listenerCount(type) {
            var events = this._events;

            if (events !== undefined) {
              var evlistener = events[type];

              if (typeof evlistener === "function") {
                return 1;
              } else if (evlistener !== undefined) {
                return evlistener.length;
              }
            }

            return 0;
          }

          EventEmitter.prototype.eventNames = function eventNames() {
            return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
          };

          function arrayClone(arr, n) {
            var copy = new Array(n);
            for (var i = 0; i < n; ++i) copy[i] = arr[i];
            return copy;
          }

          function spliceOne(list, index) {
            for (; index + 1 < list.length; index++)
              list[index] = list[index + 1];
            list.pop();
          }

          function unwrapListeners(arr) {
            var ret = new Array(arr.length);
            for (var i = 0; i < ret.length; ++i) {
              ret[i] = arr[i].listener || arr[i];
            }
            return ret;
          }

          function once(emitter, name) {
            return new Promise(function (resolve, reject) {
              function errorListener(err) {
                emitter.removeListener(name, resolver);
                reject(err);
              }

              function resolver() {
                if (typeof emitter.removeListener === "function") {
                  emitter.removeListener("error", errorListener);
                }
                resolve([].slice.call(arguments));
              }

              eventTargetAgnosticAddListener(emitter, name, resolver, {
                once: true,
              });
              if (name !== "error") {
                addErrorHandlerIfEventEmitter(emitter, errorListener, {
                  once: true,
                });
              }
            });
          }

          function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
            if (typeof emitter.on === "function") {
              eventTargetAgnosticAddListener(emitter, "error", handler, flags);
            }
          }

          function eventTargetAgnosticAddListener(
            emitter,
            name,
            listener,
            flags
          ) {
            if (typeof emitter.on === "function") {
              if (flags.once) {
                emitter.once(name, listener);
              } else {
                emitter.on(name, listener);
              }
            } else if (typeof emitter.addEventListener === "function") {
              // EventTarget does not have `error` event semantics like Node
              // EventEmitters, we do not listen for `error` events here.
              emitter.addEventListener(name, function wrapListener(arg) {
                // IE does not have builtin `{ once: true }` support so we
                // have to do it manually.
                if (flags.once) {
                  emitter.removeEventListener(name, wrapListener);
                }
                listener(arg);
              });
            } else {
              throw new TypeError(
                'The "emitter" argument must be of type EventEmitter. Received type ' +
                  typeof emitter
              );
            }
          }
        },
        {},
      ],
      8: [
        function (require, module, exports) {
          "use strict";
          var isObj = require("is-obj");
          var hasOwnProperty = Object.prototype.hasOwnProperty;
          var propIsEnumerable = Object.prototype.propertyIsEnumerable;

          function toObject(val) {
            if (val === null || val === undefined) {
              throw new TypeError("Sources cannot be null or undefined");
            }

            return Object(val);
          }

          function assignKey(to, from, key) {
            var val = from[key];

            if (val === undefined || val === null) {
              return;
            }

            if (hasOwnProperty.call(to, key)) {
              if (to[key] === undefined || to[key] === null) {
                throw new TypeError(
                  "Cannot convert undefined or null to object (" + key + ")"
                );
              }
            }

            if (!hasOwnProperty.call(to, key) || !isObj(val)) {
              to[key] = val;
            } else {
              to[key] = assign(Object(to[key]), from[key]);
            }
          }

          function assign(to, from) {
            if (to === from) {
              return to;
            }

            from = Object(from);

            for (var key in from) {
              if (hasOwnProperty.call(from, key)) {
                assignKey(to, from, key);
              }
            }

            if (Object.getOwnPropertySymbols) {
              var symbols = Object.getOwnPropertySymbols(from);

              for (var i = 0; i < symbols.length; i++) {
                if (propIsEnumerable.call(from, symbols[i])) {
                  assignKey(to, from, symbols[i]);
                }
              }
            }

            return to;
          }

          module.exports = function deepAssign(target) {
            target = toObject(target);

            for (var s = 1; s < arguments.length; s++) {
              assign(target, arguments[s]);
            }

            return target;
          };
        },
        { "is-obj": 10 },
      ],
      9: [
        function (require, module, exports) {
          /*
           * Fuzzy
           * https://github.com/myork/fuzzy
           *
           * Copyright (c) 2012 Matt York
           * Licensed under the MIT license.
           */

          (function () {
            var root = this;

            var fuzzy = {};

            // Use in node or in browser
            if (typeof exports !== "undefined") {
              module.exports = fuzzy;
            } else {
              root.fuzzy = fuzzy;
            }

            // Return all elements of `array` that have a fuzzy
            // match against `pattern`.
            fuzzy.simpleFilter = function (pattern, array) {
              return array.filter(function (str) {
                return fuzzy.test(pattern, str);
              });
            };

            // Does `pattern` fuzzy match `str`?
            fuzzy.test = function (pattern, str) {
              return fuzzy.match(pattern, str) !== null;
            };

            // If `pattern` matches `str`, wrap each matching character
            // in `opts.pre` and `opts.post`. If no match, return null
            fuzzy.match = function (pattern, str, opts) {
              opts = opts || {};
              var patternIdx = 0,
                result = [],
                len = str.length,
                totalScore = 0,
                currScore = 0,
                // prefix
                pre = opts.pre || "",
                // suffix
                post = opts.post || "",
                // String to compare against. This might be a lowercase version of the
                // raw string
                compareString =
                  (opts.caseSensitive && str) || str.toLowerCase(),
                ch;

              pattern =
                (opts.caseSensitive && pattern) || pattern.toLowerCase();

              // For each character in the string, either add it to the result
              // or wrap in template if it's the next string in the pattern
              for (var idx = 0; idx < len; idx++) {
                ch = str[idx];
                if (compareString[idx] === pattern[patternIdx]) {
                  ch = pre + ch + post;
                  patternIdx += 1;

                  // consecutive characters should increase the score more than linearly
                  currScore += 1 + currScore;
                } else {
                  currScore = 0;
                }
                totalScore += currScore;
                result[result.length] = ch;
              }

              // return rendered string if we have a match for every char
              if (patternIdx === pattern.length) {
                // if the string is an exact match with pattern, totalScore should be maxed
                totalScore = compareString === pattern ? Infinity : totalScore;
                return { rendered: result.join(""), score: totalScore };
              }

              return null;
            };

            // The normal entry point. Filters `arr` for matches against `pattern`.
            // It returns an array with matching values of the type:
            //
            //     [{
            //         string:   '<b>lah' // The rendered string
            //       , index:    2        // The index of the element in `arr`
            //       , original: 'blah'   // The original element in `arr`
            //     }]
            //
            // `opts` is an optional argument bag. Details:
            //
            //    opts = {
            //        // string to put before a matching character
            //        pre:     '<b>'
            //
            //        // string to put after matching character
            //      , post:    '</b>'
            //
            //        // Optional function. Input is an entry in the given arr`,
            //        // output should be the string to test `pattern` against.
            //        // In this example, if `arr = [{crying: 'koala'}]` we would return
            //        // 'koala'.
            //      , extract: function(arg) { return arg.crying; }
            //    }
            fuzzy.filter = function (pattern, arr, opts) {
              if (!arr || arr.length === 0) {
                return [];
              }
              if (typeof pattern !== "string") {
                return arr;
              }
              opts = opts || {};
              return (
                arr
                  .reduce(function (prev, element, idx, arr) {
                    var str = element;
                    if (opts.extract) {
                      str = opts.extract(element);
                    }
                    var rendered = fuzzy.match(pattern, str, opts);
                    if (rendered != null) {
                      prev[prev.length] = {
                        string: rendered.rendered,
                        score: rendered.score,
                        index: idx,
                        original: element,
                      };
                    }
                    return prev;
                  }, [])

                  // Sort by score. Browsers are inconsistent wrt stable/unstable
                  // sorting, so force stable by using the index in the case of tie.
                  // See http://ofb.net/~sethml/is-sort-stable.html
                  .sort(function (a, b) {
                    var compare = b.score - a.score;
                    if (compare) return compare;
                    return a.index - b.index;
                  })
              );
            };
          })();
        },
        {},
      ],
      10: [
        function (require, module, exports) {
          "use strict";
          module.exports = function (x) {
            var type = typeof x;
            return x !== null && (type === "object" || type === "function");
          };
        },
        {},
      ],
      11: [
        function (require, module, exports) {
          /**
           * lodash 3.0.0 (Custom Build) <https://lodash.com/>
           * Build: `lodash modern modularize exports="npm" -o ./`
           * Copyright 2012-2015 The Dojo Foundation <http://dojofoundation.org/>
           * Based on Underscore.js 1.7.0 <http://underscorejs.org/LICENSE>
           * Copyright 2009-2015 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
           * Available under MIT license <https://lodash.com/license>
           */

          /** Used to match template delimiters. */
          var reInterpolate = /<%=([\s\S]+?)%>/g;

          module.exports = reInterpolate;
        },
        {},
      ],
      12: [
        function (require, module, exports) {
          (function (global) {
            (function () {
              /**
               * lodash (Custom Build) <https://lodash.com/>
               * Build: `lodash modularize exports="npm" -o ./`
               * Copyright jQuery Foundation and other contributors <https://jquery.org/>
               * Released under MIT license <https://lodash.com/license>
               * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
               * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
               */

              /** Used as the `TypeError` message for "Functions" methods. */
              var FUNC_ERROR_TEXT = "Expected a function";

              /** Used as references for various `Number` constants. */
              var NAN = 0 / 0;

              /** `Object#toString` result references. */
              var symbolTag = "[object Symbol]";

              /** Used to match leading and trailing whitespace. */
              var reTrim = /^\s+|\s+$/g;

              /** Used to detect bad signed hexadecimal string values. */
              var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

              /** Used to detect binary string values. */
              var reIsBinary = /^0b[01]+$/i;

              /** Used to detect octal string values. */
              var reIsOctal = /^0o[0-7]+$/i;

              /** Built-in method references without a dependency on `root`. */
              var freeParseInt = parseInt;

              /** Detect free variable `global` from Node.js. */
              var freeGlobal =
                typeof global == "object" &&
                global &&
                global.Object === Object &&
                global;

              /** Detect free variable `self`. */
              var freeSelf =
                typeof self == "object" &&
                self &&
                self.Object === Object &&
                self;

              /** Used as a reference to the global object. */
              var root = freeGlobal || freeSelf || Function("return this")();

              /** Used for built-in method references. */
              var objectProto = Object.prototype;

              /**
               * Used to resolve the
               * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
               * of values.
               */
              var objectToString = objectProto.toString;

              /* Built-in method references for those with the same name as other `lodash` methods. */
              var nativeMax = Math.max,
                nativeMin = Math.min;

              /**
               * Gets the timestamp of the number of milliseconds that have elapsed since
               * the Unix epoch (1 January 1970 00:00:00 UTC).
               *
               * @static
               * @memberOf _
               * @since 2.4.0
               * @category Date
               * @returns {number} Returns the timestamp.
               * @example
               *
               * _.defer(function(stamp) {
               *   console.log(_.now() - stamp);
               * }, _.now());
               * // => Logs the number of milliseconds it took for the deferred invocation.
               */
              var now = function () {
                return root.Date.now();
              };

              /**
               * Creates a debounced function that delays invoking `func` until after `wait`
               * milliseconds have elapsed since the last time the debounced function was
               * invoked. The debounced function comes with a `cancel` method to cancel
               * delayed `func` invocations and a `flush` method to immediately invoke them.
               * Provide `options` to indicate whether `func` should be invoked on the
               * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
               * with the last arguments provided to the debounced function. Subsequent
               * calls to the debounced function return the result of the last `func`
               * invocation.
               *
               * **Note:** If `leading` and `trailing` options are `true`, `func` is
               * invoked on the trailing edge of the timeout only if the debounced function
               * is invoked more than once during the `wait` timeout.
               *
               * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
               * until to the next tick, similar to `setTimeout` with a timeout of `0`.
               *
               * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
               * for details over the differences between `_.debounce` and `_.throttle`.
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Function
               * @param {Function} func The function to debounce.
               * @param {number} [wait=0] The number of milliseconds to delay.
               * @param {Object} [options={}] The options object.
               * @param {boolean} [options.leading=false]
               *  Specify invoking on the leading edge of the timeout.
               * @param {number} [options.maxWait]
               *  The maximum time `func` is allowed to be delayed before it's invoked.
               * @param {boolean} [options.trailing=true]
               *  Specify invoking on the trailing edge of the timeout.
               * @returns {Function} Returns the new debounced function.
               * @example
               *
               * // Avoid costly calculations while the window size is in flux.
               * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
               *
               * // Invoke `sendMail` when clicked, debouncing subsequent calls.
               * jQuery(element).on('click', _.debounce(sendMail, 300, {
               *   'leading': true,
               *   'trailing': false
               * }));
               *
               * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
               * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
               * var source = new EventSource('/stream');
               * jQuery(source).on('message', debounced);
               *
               * // Cancel the trailing debounced invocation.
               * jQuery(window).on('popstate', debounced.cancel);
               */
              function debounce(func, wait, options) {
                var lastArgs,
                  lastThis,
                  maxWait,
                  result,
                  timerId,
                  lastCallTime,
                  lastInvokeTime = 0,
                  leading = false,
                  maxing = false,
                  trailing = true;

                if (typeof func != "function") {
                  throw new TypeError(FUNC_ERROR_TEXT);
                }
                wait = toNumber(wait) || 0;
                if (isObject(options)) {
                  leading = !!options.leading;
                  maxing = "maxWait" in options;
                  maxWait = maxing
                    ? nativeMax(toNumber(options.maxWait) || 0, wait)
                    : maxWait;
                  trailing =
                    "trailing" in options ? !!options.trailing : trailing;
                }

                function invokeFunc(time) {
                  var args = lastArgs,
                    thisArg = lastThis;

                  lastArgs = lastThis = undefined;
                  lastInvokeTime = time;
                  result = func.apply(thisArg, args);
                  return result;
                }

                function leadingEdge(time) {
                  // Reset any `maxWait` timer.
                  lastInvokeTime = time;
                  // Start the timer for the trailing edge.
                  timerId = setTimeout(timerExpired, wait);
                  // Invoke the leading edge.
                  return leading ? invokeFunc(time) : result;
                }

                function remainingWait(time) {
                  var timeSinceLastCall = time - lastCallTime,
                    timeSinceLastInvoke = time - lastInvokeTime,
                    result = wait - timeSinceLastCall;

                  return maxing
                    ? nativeMin(result, maxWait - timeSinceLastInvoke)
                    : result;
                }

                function shouldInvoke(time) {
                  var timeSinceLastCall = time - lastCallTime,
                    timeSinceLastInvoke = time - lastInvokeTime;

                  // Either this is the first call, activity has stopped and we're at the
                  // trailing edge, the system time has gone backwards and we're treating
                  // it as the trailing edge, or we've hit the `maxWait` limit.
                  return (
                    lastCallTime === undefined ||
                    timeSinceLastCall >= wait ||
                    timeSinceLastCall < 0 ||
                    (maxing && timeSinceLastInvoke >= maxWait)
                  );
                }

                function timerExpired() {
                  var time = now();
                  if (shouldInvoke(time)) {
                    return trailingEdge(time);
                  }
                  // Restart the timer.
                  timerId = setTimeout(timerExpired, remainingWait(time));
                }

                function trailingEdge(time) {
                  timerId = undefined;

                  // Only invoke if we have `lastArgs` which means `func` has been
                  // debounced at least once.
                  if (trailing && lastArgs) {
                    return invokeFunc(time);
                  }
                  lastArgs = lastThis = undefined;
                  return result;
                }

                function cancel() {
                  if (timerId !== undefined) {
                    clearTimeout(timerId);
                  }
                  lastInvokeTime = 0;
                  lastArgs = lastCallTime = lastThis = timerId = undefined;
                }

                function flush() {
                  return timerId === undefined ? result : trailingEdge(now());
                }

                function debounced() {
                  var time = now(),
                    isInvoking = shouldInvoke(time);

                  lastArgs = arguments;
                  lastThis = this;
                  lastCallTime = time;

                  if (isInvoking) {
                    if (timerId === undefined) {
                      return leadingEdge(lastCallTime);
                    }
                    if (maxing) {
                      // Handle invocations in a tight loop.
                      timerId = setTimeout(timerExpired, wait);
                      return invokeFunc(lastCallTime);
                    }
                  }
                  if (timerId === undefined) {
                    timerId = setTimeout(timerExpired, wait);
                  }
                  return result;
                }
                debounced.cancel = cancel;
                debounced.flush = flush;
                return debounced;
              }

              /**
               * Checks if `value` is the
               * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
               * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an object, else `false`.
               * @example
               *
               * _.isObject({});
               * // => true
               *
               * _.isObject([1, 2, 3]);
               * // => true
               *
               * _.isObject(_.noop);
               * // => true
               *
               * _.isObject(null);
               * // => false
               */
              function isObject(value) {
                var type = typeof value;
                return !!value && (type == "object" || type == "function");
              }

              /**
               * Checks if `value` is object-like. A value is object-like if it's not `null`
               * and has a `typeof` result of "object".
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
               * @example
               *
               * _.isObjectLike({});
               * // => true
               *
               * _.isObjectLike([1, 2, 3]);
               * // => true
               *
               * _.isObjectLike(_.noop);
               * // => false
               *
               * _.isObjectLike(null);
               * // => false
               */
              function isObjectLike(value) {
                return !!value && typeof value == "object";
              }

              /**
               * Checks if `value` is classified as a `Symbol` primitive or object.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
               * @example
               *
               * _.isSymbol(Symbol.iterator);
               * // => true
               *
               * _.isSymbol('abc');
               * // => false
               */
              function isSymbol(value) {
                return (
                  typeof value == "symbol" ||
                  (isObjectLike(value) &&
                    objectToString.call(value) == symbolTag)
                );
              }

              /**
               * Converts `value` to a number.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to process.
               * @returns {number} Returns the number.
               * @example
               *
               * _.toNumber(3.2);
               * // => 3.2
               *
               * _.toNumber(Number.MIN_VALUE);
               * // => 5e-324
               *
               * _.toNumber(Infinity);
               * // => Infinity
               *
               * _.toNumber('3.2');
               * // => 3.2
               */
              function toNumber(value) {
                if (typeof value == "number") {
                  return value;
                }
                if (isSymbol(value)) {
                  return NAN;
                }
                if (isObject(value)) {
                  var other =
                    typeof value.valueOf == "function"
                      ? value.valueOf()
                      : value;
                  value = isObject(other) ? other + "" : other;
                }
                if (typeof value != "string") {
                  return value === 0 ? value : +value;
                }
                value = value.replace(reTrim, "");
                var isBinary = reIsBinary.test(value);
                return isBinary || reIsOctal.test(value)
                  ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
                  : reIsBadHex.test(value)
                  ? NAN
                  : +value;
              }

              module.exports = debounce;
            }.call(this));
          }.call(
            this,
            typeof global !== "undefined"
              ? global
              : typeof self !== "undefined"
              ? self
              : typeof window !== "undefined"
              ? window
              : {}
          ));
        },
        {},
      ],
      13: [
        function (require, module, exports) {
          (function (global) {
            (function () {
              /**
               * Lodash (Custom Build) <https://lodash.com/>
               * Build: `lodash modularize exports="npm" -o ./`
               * Copyright JS Foundation and other contributors <https://js.foundation/>
               * Released under MIT license <https://lodash.com/license>
               * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
               * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
               */

              /** Used as the size to enable large array optimizations. */
              var LARGE_ARRAY_SIZE = 200;

              /** Used to stand-in for `undefined` hash values. */
              var HASH_UNDEFINED = "__lodash_hash_undefined__";

              /** Used to compose bitmasks for value comparisons. */
              var COMPARE_PARTIAL_FLAG = 1,
                COMPARE_UNORDERED_FLAG = 2;

              /** Used as references for various `Number` constants. */
              var MAX_SAFE_INTEGER = 9007199254740991;

              /** `Object#toString` result references. */
              var argsTag = "[object Arguments]",
                arrayTag = "[object Array]",
                asyncTag = "[object AsyncFunction]",
                boolTag = "[object Boolean]",
                dateTag = "[object Date]",
                errorTag = "[object Error]",
                funcTag = "[object Function]",
                genTag = "[object GeneratorFunction]",
                mapTag = "[object Map]",
                numberTag = "[object Number]",
                nullTag = "[object Null]",
                objectTag = "[object Object]",
                promiseTag = "[object Promise]",
                proxyTag = "[object Proxy]",
                regexpTag = "[object RegExp]",
                setTag = "[object Set]",
                stringTag = "[object String]",
                symbolTag = "[object Symbol]",
                undefinedTag = "[object Undefined]",
                weakMapTag = "[object WeakMap]";

              var arrayBufferTag = "[object ArrayBuffer]",
                dataViewTag = "[object DataView]",
                float32Tag = "[object Float32Array]",
                float64Tag = "[object Float64Array]",
                int8Tag = "[object Int8Array]",
                int16Tag = "[object Int16Array]",
                int32Tag = "[object Int32Array]",
                uint8Tag = "[object Uint8Array]",
                uint8ClampedTag = "[object Uint8ClampedArray]",
                uint16Tag = "[object Uint16Array]",
                uint32Tag = "[object Uint32Array]";

              /**
               * Used to match `RegExp`
               * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
               */
              var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

              /** Used to detect host constructors (Safari). */
              var reIsHostCtor = /^\[object .+?Constructor\]$/;

              /** Used to detect unsigned integer values. */
              var reIsUint = /^(?:0|[1-9]\d*)$/;

              /** Used to identify `toStringTag` values of typed arrays. */
              var typedArrayTags = {};
              typedArrayTags[float32Tag] =
                typedArrayTags[float64Tag] =
                typedArrayTags[int8Tag] =
                typedArrayTags[int16Tag] =
                typedArrayTags[int32Tag] =
                typedArrayTags[uint8Tag] =
                typedArrayTags[uint8ClampedTag] =
                typedArrayTags[uint16Tag] =
                typedArrayTags[uint32Tag] =
                  true;
              typedArrayTags[argsTag] =
                typedArrayTags[arrayTag] =
                typedArrayTags[arrayBufferTag] =
                typedArrayTags[boolTag] =
                typedArrayTags[dataViewTag] =
                typedArrayTags[dateTag] =
                typedArrayTags[errorTag] =
                typedArrayTags[funcTag] =
                typedArrayTags[mapTag] =
                typedArrayTags[numberTag] =
                typedArrayTags[objectTag] =
                typedArrayTags[regexpTag] =
                typedArrayTags[setTag] =
                typedArrayTags[stringTag] =
                typedArrayTags[weakMapTag] =
                  false;

              /** Detect free variable `global` from Node.js. */
              var freeGlobal =
                typeof global == "object" &&
                global &&
                global.Object === Object &&
                global;

              /** Detect free variable `self`. */
              var freeSelf =
                typeof self == "object" &&
                self &&
                self.Object === Object &&
                self;

              /** Used as a reference to the global object. */
              var root = freeGlobal || freeSelf || Function("return this")();

              /** Detect free variable `exports`. */
              var freeExports =
                typeof exports == "object" &&
                exports &&
                !exports.nodeType &&
                exports;

              /** Detect free variable `module`. */
              var freeModule =
                freeExports &&
                typeof module == "object" &&
                module &&
                !module.nodeType &&
                module;

              /** Detect the popular CommonJS extension `module.exports`. */
              var moduleExports =
                freeModule && freeModule.exports === freeExports;

              /** Detect free variable `process` from Node.js. */
              var freeProcess = moduleExports && freeGlobal.process;

              /** Used to access faster Node.js helpers. */
              var nodeUtil = (function () {
                try {
                  return (
                    freeProcess &&
                    freeProcess.binding &&
                    freeProcess.binding("util")
                  );
                } catch (e) {}
              })();

              /* Node.js helper references. */
              var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;

              /**
               * A specialized version of `_.filter` for arrays without support for
               * iteratee shorthands.
               *
               * @private
               * @param {Array} [array] The array to iterate over.
               * @param {Function} predicate The function invoked per iteration.
               * @returns {Array} Returns the new filtered array.
               */
              function arrayFilter(array, predicate) {
                var index = -1,
                  length = array == null ? 0 : array.length,
                  resIndex = 0,
                  result = [];

                while (++index < length) {
                  var value = array[index];
                  if (predicate(value, index, array)) {
                    result[resIndex++] = value;
                  }
                }
                return result;
              }

              /**
               * Appends the elements of `values` to `array`.
               *
               * @private
               * @param {Array} array The array to modify.
               * @param {Array} values The values to append.
               * @returns {Array} Returns `array`.
               */
              function arrayPush(array, values) {
                var index = -1,
                  length = values.length,
                  offset = array.length;

                while (++index < length) {
                  array[offset + index] = values[index];
                }
                return array;
              }

              /**
               * A specialized version of `_.some` for arrays without support for iteratee
               * shorthands.
               *
               * @private
               * @param {Array} [array] The array to iterate over.
               * @param {Function} predicate The function invoked per iteration.
               * @returns {boolean} Returns `true` if any element passes the predicate check,
               *  else `false`.
               */
              function arraySome(array, predicate) {
                var index = -1,
                  length = array == null ? 0 : array.length;

                while (++index < length) {
                  if (predicate(array[index], index, array)) {
                    return true;
                  }
                }
                return false;
              }

              /**
               * The base implementation of `_.times` without support for iteratee shorthands
               * or max array length checks.
               *
               * @private
               * @param {number} n The number of times to invoke `iteratee`.
               * @param {Function} iteratee The function invoked per iteration.
               * @returns {Array} Returns the array of results.
               */
              function baseTimes(n, iteratee) {
                var index = -1,
                  result = Array(n);

                while (++index < n) {
                  result[index] = iteratee(index);
                }
                return result;
              }

              /**
               * The base implementation of `_.unary` without support for storing metadata.
               *
               * @private
               * @param {Function} func The function to cap arguments for.
               * @returns {Function} Returns the new capped function.
               */
              function baseUnary(func) {
                return function (value) {
                  return func(value);
                };
              }

              /**
               * Checks if a `cache` value for `key` exists.
               *
               * @private
               * @param {Object} cache The cache to query.
               * @param {string} key The key of the entry to check.
               * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
               */
              function cacheHas(cache, key) {
                return cache.has(key);
              }

              /**
               * Gets the value at `key` of `object`.
               *
               * @private
               * @param {Object} [object] The object to query.
               * @param {string} key The key of the property to get.
               * @returns {*} Returns the property value.
               */
              function getValue(object, key) {
                return object == null ? undefined : object[key];
              }

              /**
               * Converts `map` to its key-value pairs.
               *
               * @private
               * @param {Object} map The map to convert.
               * @returns {Array} Returns the key-value pairs.
               */
              function mapToArray(map) {
                var index = -1,
                  result = Array(map.size);

                map.forEach(function (value, key) {
                  result[++index] = [key, value];
                });
                return result;
              }

              /**
               * Creates a unary function that invokes `func` with its argument transformed.
               *
               * @private
               * @param {Function} func The function to wrap.
               * @param {Function} transform The argument transform.
               * @returns {Function} Returns the new function.
               */
              function overArg(func, transform) {
                return function (arg) {
                  return func(transform(arg));
                };
              }

              /**
               * Converts `set` to an array of its values.
               *
               * @private
               * @param {Object} set The set to convert.
               * @returns {Array} Returns the values.
               */
              function setToArray(set) {
                var index = -1,
                  result = Array(set.size);

                set.forEach(function (value) {
                  result[++index] = value;
                });
                return result;
              }

              /** Used for built-in method references. */
              var arrayProto = Array.prototype,
                funcProto = Function.prototype,
                objectProto = Object.prototype;

              /** Used to detect overreaching core-js shims. */
              var coreJsData = root["__core-js_shared__"];

              /** Used to resolve the decompiled source of functions. */
              var funcToString = funcProto.toString;

              /** Used to check objects for own properties. */
              var hasOwnProperty = objectProto.hasOwnProperty;

              /** Used to detect methods masquerading as native. */
              var maskSrcKey = (function () {
                var uid = /[^.]+$/.exec(
                  (coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO) ||
                    ""
                );
                return uid ? "Symbol(src)_1." + uid : "";
              })();

              /**
               * Used to resolve the
               * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
               * of values.
               */
              var nativeObjectToString = objectProto.toString;

              /** Used to detect if a method is native. */
              var reIsNative = RegExp(
                "^" +
                  funcToString
                    .call(hasOwnProperty)
                    .replace(reRegExpChar, "\\$&")
                    .replace(
                      /hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,
                      "$1.*?"
                    ) +
                  "$"
              );

              /** Built-in value references. */
              var Buffer = moduleExports ? root.Buffer : undefined,
                Symbol = root.Symbol,
                Uint8Array = root.Uint8Array,
                propertyIsEnumerable = objectProto.propertyIsEnumerable,
                splice = arrayProto.splice,
                symToStringTag = Symbol ? Symbol.toStringTag : undefined;

              /* Built-in method references for those with the same name as other `lodash` methods. */
              var nativeGetSymbols = Object.getOwnPropertySymbols,
                nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined,
                nativeKeys = overArg(Object.keys, Object);

              /* Built-in method references that are verified to be native. */
              var DataView = getNative(root, "DataView"),
                Map = getNative(root, "Map"),
                Promise = getNative(root, "Promise"),
                Set = getNative(root, "Set"),
                WeakMap = getNative(root, "WeakMap"),
                nativeCreate = getNative(Object, "create");

              /** Used to detect maps, sets, and weakmaps. */
              var dataViewCtorString = toSource(DataView),
                mapCtorString = toSource(Map),
                promiseCtorString = toSource(Promise),
                setCtorString = toSource(Set),
                weakMapCtorString = toSource(WeakMap);

              /** Used to convert symbols to primitives and strings. */
              var symbolProto = Symbol ? Symbol.prototype : undefined,
                symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;

              /**
               * Creates a hash object.
               *
               * @private
               * @constructor
               * @param {Array} [entries] The key-value pairs to cache.
               */
              function Hash(entries) {
                var index = -1,
                  length = entries == null ? 0 : entries.length;

                this.clear();
                while (++index < length) {
                  var entry = entries[index];
                  this.set(entry[0], entry[1]);
                }
              }

              /**
               * Removes all key-value entries from the hash.
               *
               * @private
               * @name clear
               * @memberOf Hash
               */
              function hashClear() {
                this.__data__ = nativeCreate ? nativeCreate(null) : {};
                this.size = 0;
              }

              /**
               * Removes `key` and its value from the hash.
               *
               * @private
               * @name delete
               * @memberOf Hash
               * @param {Object} hash The hash to modify.
               * @param {string} key The key of the value to remove.
               * @returns {boolean} Returns `true` if the entry was removed, else `false`.
               */
              function hashDelete(key) {
                var result = this.has(key) && delete this.__data__[key];
                this.size -= result ? 1 : 0;
                return result;
              }

              /**
               * Gets the hash value for `key`.
               *
               * @private
               * @name get
               * @memberOf Hash
               * @param {string} key The key of the value to get.
               * @returns {*} Returns the entry value.
               */
              function hashGet(key) {
                var data = this.__data__;
                if (nativeCreate) {
                  var result = data[key];
                  return result === HASH_UNDEFINED ? undefined : result;
                }
                return hasOwnProperty.call(data, key) ? data[key] : undefined;
              }

              /**
               * Checks if a hash value for `key` exists.
               *
               * @private
               * @name has
               * @memberOf Hash
               * @param {string} key The key of the entry to check.
               * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
               */
              function hashHas(key) {
                var data = this.__data__;
                return nativeCreate
                  ? data[key] !== undefined
                  : hasOwnProperty.call(data, key);
              }

              /**
               * Sets the hash `key` to `value`.
               *
               * @private
               * @name set
               * @memberOf Hash
               * @param {string} key The key of the value to set.
               * @param {*} value The value to set.
               * @returns {Object} Returns the hash instance.
               */
              function hashSet(key, value) {
                var data = this.__data__;
                this.size += this.has(key) ? 0 : 1;
                data[key] =
                  nativeCreate && value === undefined ? HASH_UNDEFINED : value;
                return this;
              }

              // Add methods to `Hash`.
              Hash.prototype.clear = hashClear;
              Hash.prototype["delete"] = hashDelete;
              Hash.prototype.get = hashGet;
              Hash.prototype.has = hashHas;
              Hash.prototype.set = hashSet;

              /**
               * Creates an list cache object.
               *
               * @private
               * @constructor
               * @param {Array} [entries] The key-value pairs to cache.
               */
              function ListCache(entries) {
                var index = -1,
                  length = entries == null ? 0 : entries.length;

                this.clear();
                while (++index < length) {
                  var entry = entries[index];
                  this.set(entry[0], entry[1]);
                }
              }

              /**
               * Removes all key-value entries from the list cache.
               *
               * @private
               * @name clear
               * @memberOf ListCache
               */
              function listCacheClear() {
                this.__data__ = [];
                this.size = 0;
              }

              /**
               * Removes `key` and its value from the list cache.
               *
               * @private
               * @name delete
               * @memberOf ListCache
               * @param {string} key The key of the value to remove.
               * @returns {boolean} Returns `true` if the entry was removed, else `false`.
               */
              function listCacheDelete(key) {
                var data = this.__data__,
                  index = assocIndexOf(data, key);

                if (index < 0) {
                  return false;
                }
                var lastIndex = data.length - 1;
                if (index == lastIndex) {
                  data.pop();
                } else {
                  splice.call(data, index, 1);
                }
                --this.size;
                return true;
              }

              /**
               * Gets the list cache value for `key`.
               *
               * @private
               * @name get
               * @memberOf ListCache
               * @param {string} key The key of the value to get.
               * @returns {*} Returns the entry value.
               */
              function listCacheGet(key) {
                var data = this.__data__,
                  index = assocIndexOf(data, key);

                return index < 0 ? undefined : data[index][1];
              }

              /**
               * Checks if a list cache value for `key` exists.
               *
               * @private
               * @name has
               * @memberOf ListCache
               * @param {string} key The key of the entry to check.
               * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
               */
              function listCacheHas(key) {
                return assocIndexOf(this.__data__, key) > -1;
              }

              /**
               * Sets the list cache `key` to `value`.
               *
               * @private
               * @name set
               * @memberOf ListCache
               * @param {string} key The key of the value to set.
               * @param {*} value The value to set.
               * @returns {Object} Returns the list cache instance.
               */
              function listCacheSet(key, value) {
                var data = this.__data__,
                  index = assocIndexOf(data, key);

                if (index < 0) {
                  ++this.size;
                  data.push([key, value]);
                } else {
                  data[index][1] = value;
                }
                return this;
              }

              // Add methods to `ListCache`.
              ListCache.prototype.clear = listCacheClear;
              ListCache.prototype["delete"] = listCacheDelete;
              ListCache.prototype.get = listCacheGet;
              ListCache.prototype.has = listCacheHas;
              ListCache.prototype.set = listCacheSet;

              /**
               * Creates a map cache object to store key-value pairs.
               *
               * @private
               * @constructor
               * @param {Array} [entries] The key-value pairs to cache.
               */
              function MapCache(entries) {
                var index = -1,
                  length = entries == null ? 0 : entries.length;

                this.clear();
                while (++index < length) {
                  var entry = entries[index];
                  this.set(entry[0], entry[1]);
                }
              }

              /**
               * Removes all key-value entries from the map.
               *
               * @private
               * @name clear
               * @memberOf MapCache
               */
              function mapCacheClear() {
                this.size = 0;
                this.__data__ = {
                  hash: new Hash(),
                  map: new (Map || ListCache)(),
                  string: new Hash(),
                };
              }

              /**
               * Removes `key` and its value from the map.
               *
               * @private
               * @name delete
               * @memberOf MapCache
               * @param {string} key The key of the value to remove.
               * @returns {boolean} Returns `true` if the entry was removed, else `false`.
               */
              function mapCacheDelete(key) {
                var result = getMapData(this, key)["delete"](key);
                this.size -= result ? 1 : 0;
                return result;
              }

              /**
               * Gets the map value for `key`.
               *
               * @private
               * @name get
               * @memberOf MapCache
               * @param {string} key The key of the value to get.
               * @returns {*} Returns the entry value.
               */
              function mapCacheGet(key) {
                return getMapData(this, key).get(key);
              }

              /**
               * Checks if a map value for `key` exists.
               *
               * @private
               * @name has
               * @memberOf MapCache
               * @param {string} key The key of the entry to check.
               * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
               */
              function mapCacheHas(key) {
                return getMapData(this, key).has(key);
              }

              /**
               * Sets the map `key` to `value`.
               *
               * @private
               * @name set
               * @memberOf MapCache
               * @param {string} key The key of the value to set.
               * @param {*} value The value to set.
               * @returns {Object} Returns the map cache instance.
               */
              function mapCacheSet(key, value) {
                var data = getMapData(this, key),
                  size = data.size;

                data.set(key, value);
                this.size += data.size == size ? 0 : 1;
                return this;
              }

              // Add methods to `MapCache`.
              MapCache.prototype.clear = mapCacheClear;
              MapCache.prototype["delete"] = mapCacheDelete;
              MapCache.prototype.get = mapCacheGet;
              MapCache.prototype.has = mapCacheHas;
              MapCache.prototype.set = mapCacheSet;

              /**
               *
               * Creates an array cache object to store unique values.
               *
               * @private
               * @constructor
               * @param {Array} [values] The values to cache.
               */
              function SetCache(values) {
                var index = -1,
                  length = values == null ? 0 : values.length;

                this.__data__ = new MapCache();
                while (++index < length) {
                  this.add(values[index]);
                }
              }

              /**
               * Adds `value` to the array cache.
               *
               * @private
               * @name add
               * @memberOf SetCache
               * @alias push
               * @param {*} value The value to cache.
               * @returns {Object} Returns the cache instance.
               */
              function setCacheAdd(value) {
                this.__data__.set(value, HASH_UNDEFINED);
                return this;
              }

              /**
               * Checks if `value` is in the array cache.
               *
               * @private
               * @name has
               * @memberOf SetCache
               * @param {*} value The value to search for.
               * @returns {number} Returns `true` if `value` is found, else `false`.
               */
              function setCacheHas(value) {
                return this.__data__.has(value);
              }

              // Add methods to `SetCache`.
              SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
              SetCache.prototype.has = setCacheHas;

              /**
               * Creates a stack cache object to store key-value pairs.
               *
               * @private
               * @constructor
               * @param {Array} [entries] The key-value pairs to cache.
               */
              function Stack(entries) {
                var data = (this.__data__ = new ListCache(entries));
                this.size = data.size;
              }

              /**
               * Removes all key-value entries from the stack.
               *
               * @private
               * @name clear
               * @memberOf Stack
               */
              function stackClear() {
                this.__data__ = new ListCache();
                this.size = 0;
              }

              /**
               * Removes `key` and its value from the stack.
               *
               * @private
               * @name delete
               * @memberOf Stack
               * @param {string} key The key of the value to remove.
               * @returns {boolean} Returns `true` if the entry was removed, else `false`.
               */
              function stackDelete(key) {
                var data = this.__data__,
                  result = data["delete"](key);

                this.size = data.size;
                return result;
              }

              /**
               * Gets the stack value for `key`.
               *
               * @private
               * @name get
               * @memberOf Stack
               * @param {string} key The key of the value to get.
               * @returns {*} Returns the entry value.
               */
              function stackGet(key) {
                return this.__data__.get(key);
              }

              /**
               * Checks if a stack value for `key` exists.
               *
               * @private
               * @name has
               * @memberOf Stack
               * @param {string} key The key of the entry to check.
               * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
               */
              function stackHas(key) {
                return this.__data__.has(key);
              }

              /**
               * Sets the stack `key` to `value`.
               *
               * @private
               * @name set
               * @memberOf Stack
               * @param {string} key The key of the value to set.
               * @param {*} value The value to set.
               * @returns {Object} Returns the stack cache instance.
               */
              function stackSet(key, value) {
                var data = this.__data__;
                if (data instanceof ListCache) {
                  var pairs = data.__data__;
                  if (!Map || pairs.length < LARGE_ARRAY_SIZE - 1) {
                    pairs.push([key, value]);
                    this.size = ++data.size;
                    return this;
                  }
                  data = this.__data__ = new MapCache(pairs);
                }
                data.set(key, value);
                this.size = data.size;
                return this;
              }

              // Add methods to `Stack`.
              Stack.prototype.clear = stackClear;
              Stack.prototype["delete"] = stackDelete;
              Stack.prototype.get = stackGet;
              Stack.prototype.has = stackHas;
              Stack.prototype.set = stackSet;

              /**
               * Creates an array of the enumerable property names of the array-like `value`.
               *
               * @private
               * @param {*} value The value to query.
               * @param {boolean} inherited Specify returning inherited property names.
               * @returns {Array} Returns the array of property names.
               */
              function arrayLikeKeys(value, inherited) {
                var isArr = isArray(value),
                  isArg = !isArr && isArguments(value),
                  isBuff = !isArr && !isArg && isBuffer(value),
                  isType = !isArr && !isArg && !isBuff && isTypedArray(value),
                  skipIndexes = isArr || isArg || isBuff || isType,
                  result = skipIndexes ? baseTimes(value.length, String) : [],
                  length = result.length;

                for (var key in value) {
                  if (
                    (inherited || hasOwnProperty.call(value, key)) &&
                    !(
                      skipIndexes &&
                      // Safari 9 has enumerable `arguments.length` in strict mode.
                      (key == "length" ||
                        // Node.js 0.10 has enumerable non-index properties on buffers.
                        (isBuff && (key == "offset" || key == "parent")) ||
                        // PhantomJS 2 has enumerable non-index properties on typed arrays.
                        (isType &&
                          (key == "buffer" ||
                            key == "byteLength" ||
                            key == "byteOffset")) ||
                        // Skip index properties.
                        isIndex(key, length))
                    )
                  ) {
                    result.push(key);
                  }
                }
                return result;
              }

              /**
               * Gets the index at which the `key` is found in `array` of key-value pairs.
               *
               * @private
               * @param {Array} array The array to inspect.
               * @param {*} key The key to search for.
               * @returns {number} Returns the index of the matched value, else `-1`.
               */
              function assocIndexOf(array, key) {
                var length = array.length;
                while (length--) {
                  if (eq(array[length][0], key)) {
                    return length;
                  }
                }
                return -1;
              }

              /**
               * The base implementation of `getAllKeys` and `getAllKeysIn` which uses
               * `keysFunc` and `symbolsFunc` to get the enumerable property names and
               * symbols of `object`.
               *
               * @private
               * @param {Object} object The object to query.
               * @param {Function} keysFunc The function to get the keys of `object`.
               * @param {Function} symbolsFunc The function to get the symbols of `object`.
               * @returns {Array} Returns the array of property names and symbols.
               */
              function baseGetAllKeys(object, keysFunc, symbolsFunc) {
                var result = keysFunc(object);
                return isArray(object)
                  ? result
                  : arrayPush(result, symbolsFunc(object));
              }

              /**
               * The base implementation of `getTag` without fallbacks for buggy environments.
               *
               * @private
               * @param {*} value The value to query.
               * @returns {string} Returns the `toStringTag`.
               */
              function baseGetTag(value) {
                if (value == null) {
                  return value === undefined ? undefinedTag : nullTag;
                }
                return symToStringTag && symToStringTag in Object(value)
                  ? getRawTag(value)
                  : objectToString(value);
              }

              /**
               * The base implementation of `_.isArguments`.
               *
               * @private
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an `arguments` object,
               */
              function baseIsArguments(value) {
                return isObjectLike(value) && baseGetTag(value) == argsTag;
              }

              /**
               * The base implementation of `_.isEqual` which supports partial comparisons
               * and tracks traversed objects.
               *
               * @private
               * @param {*} value The value to compare.
               * @param {*} other The other value to compare.
               * @param {boolean} bitmask The bitmask flags.
               *  1 - Unordered comparison
               *  2 - Partial comparison
               * @param {Function} [customizer] The function to customize comparisons.
               * @param {Object} [stack] Tracks traversed `value` and `other` objects.
               * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
               */
              function baseIsEqual(value, other, bitmask, customizer, stack) {
                if (value === other) {
                  return true;
                }
                if (
                  value == null ||
                  other == null ||
                  (!isObjectLike(value) && !isObjectLike(other))
                ) {
                  return value !== value && other !== other;
                }
                return baseIsEqualDeep(
                  value,
                  other,
                  bitmask,
                  customizer,
                  baseIsEqual,
                  stack
                );
              }

              /**
               * A specialized version of `baseIsEqual` for arrays and objects which performs
               * deep comparisons and tracks traversed objects enabling objects with circular
               * references to be compared.
               *
               * @private
               * @param {Object} object The object to compare.
               * @param {Object} other The other object to compare.
               * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
               * @param {Function} customizer The function to customize comparisons.
               * @param {Function} equalFunc The function to determine equivalents of values.
               * @param {Object} [stack] Tracks traversed `object` and `other` objects.
               * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
               */
              function baseIsEqualDeep(
                object,
                other,
                bitmask,
                customizer,
                equalFunc,
                stack
              ) {
                var objIsArr = isArray(object),
                  othIsArr = isArray(other),
                  objTag = objIsArr ? arrayTag : getTag(object),
                  othTag = othIsArr ? arrayTag : getTag(other);

                objTag = objTag == argsTag ? objectTag : objTag;
                othTag = othTag == argsTag ? objectTag : othTag;

                var objIsObj = objTag == objectTag,
                  othIsObj = othTag == objectTag,
                  isSameTag = objTag == othTag;

                if (isSameTag && isBuffer(object)) {
                  if (!isBuffer(other)) {
                    return false;
                  }
                  objIsArr = true;
                  objIsObj = false;
                }
                if (isSameTag && !objIsObj) {
                  stack || (stack = new Stack());
                  return objIsArr || isTypedArray(object)
                    ? equalArrays(
                        object,
                        other,
                        bitmask,
                        customizer,
                        equalFunc,
                        stack
                      )
                    : equalByTag(
                        object,
                        other,
                        objTag,
                        bitmask,
                        customizer,
                        equalFunc,
                        stack
                      );
                }
                if (!(bitmask & COMPARE_PARTIAL_FLAG)) {
                  var objIsWrapped =
                      objIsObj && hasOwnProperty.call(object, "__wrapped__"),
                    othIsWrapped =
                      othIsObj && hasOwnProperty.call(other, "__wrapped__");

                  if (objIsWrapped || othIsWrapped) {
                    var objUnwrapped = objIsWrapped ? object.value() : object,
                      othUnwrapped = othIsWrapped ? other.value() : other;

                    stack || (stack = new Stack());
                    return equalFunc(
                      objUnwrapped,
                      othUnwrapped,
                      bitmask,
                      customizer,
                      stack
                    );
                  }
                }
                if (!isSameTag) {
                  return false;
                }
                stack || (stack = new Stack());
                return equalObjects(
                  object,
                  other,
                  bitmask,
                  customizer,
                  equalFunc,
                  stack
                );
              }

              /**
               * The base implementation of `_.isNative` without bad shim checks.
               *
               * @private
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a native function,
               *  else `false`.
               */
              function baseIsNative(value) {
                if (!isObject(value) || isMasked(value)) {
                  return false;
                }
                var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
                return pattern.test(toSource(value));
              }

              /**
               * The base implementation of `_.isTypedArray` without Node.js optimizations.
               *
               * @private
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
               */
              function baseIsTypedArray(value) {
                return (
                  isObjectLike(value) &&
                  isLength(value.length) &&
                  !!typedArrayTags[baseGetTag(value)]
                );
              }

              /**
               * The base implementation of `_.keys` which doesn't treat sparse arrays as dense.
               *
               * @private
               * @param {Object} object The object to query.
               * @returns {Array} Returns the array of property names.
               */
              function baseKeys(object) {
                if (!isPrototype(object)) {
                  return nativeKeys(object);
                }
                var result = [];
                for (var key in Object(object)) {
                  if (
                    hasOwnProperty.call(object, key) &&
                    key != "constructor"
                  ) {
                    result.push(key);
                  }
                }
                return result;
              }

              /**
               * A specialized version of `baseIsEqualDeep` for arrays with support for
               * partial deep comparisons.
               *
               * @private
               * @param {Array} array The array to compare.
               * @param {Array} other The other array to compare.
               * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
               * @param {Function} customizer The function to customize comparisons.
               * @param {Function} equalFunc The function to determine equivalents of values.
               * @param {Object} stack Tracks traversed `array` and `other` objects.
               * @returns {boolean} Returns `true` if the arrays are equivalent, else `false`.
               */
              function equalArrays(
                array,
                other,
                bitmask,
                customizer,
                equalFunc,
                stack
              ) {
                var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
                  arrLength = array.length,
                  othLength = other.length;

                if (
                  arrLength != othLength &&
                  !(isPartial && othLength > arrLength)
                ) {
                  return false;
                }
                // Assume cyclic values are equal.
                var stacked = stack.get(array);
                if (stacked && stack.get(other)) {
                  return stacked == other;
                }
                var index = -1,
                  result = true,
                  seen =
                    bitmask & COMPARE_UNORDERED_FLAG
                      ? new SetCache()
                      : undefined;

                stack.set(array, other);
                stack.set(other, array);

                // Ignore non-index properties.
                while (++index < arrLength) {
                  var arrValue = array[index],
                    othValue = other[index];

                  if (customizer) {
                    var compared = isPartial
                      ? customizer(
                          othValue,
                          arrValue,
                          index,
                          other,
                          array,
                          stack
                        )
                      : customizer(
                          arrValue,
                          othValue,
                          index,
                          array,
                          other,
                          stack
                        );
                  }
                  if (compared !== undefined) {
                    if (compared) {
                      continue;
                    }
                    result = false;
                    break;
                  }
                  // Recursively compare arrays (susceptible to call stack limits).
                  if (seen) {
                    if (
                      !arraySome(other, function (othValue, othIndex) {
                        if (
                          !cacheHas(seen, othIndex) &&
                          (arrValue === othValue ||
                            equalFunc(
                              arrValue,
                              othValue,
                              bitmask,
                              customizer,
                              stack
                            ))
                        ) {
                          return seen.push(othIndex);
                        }
                      })
                    ) {
                      result = false;
                      break;
                    }
                  } else if (
                    !(
                      arrValue === othValue ||
                      equalFunc(arrValue, othValue, bitmask, customizer, stack)
                    )
                  ) {
                    result = false;
                    break;
                  }
                }
                stack["delete"](array);
                stack["delete"](other);
                return result;
              }

              /**
               * A specialized version of `baseIsEqualDeep` for comparing objects of
               * the same `toStringTag`.
               *
               * **Note:** This function only supports comparing values with tags of
               * `Boolean`, `Date`, `Error`, `Number`, `RegExp`, or `String`.
               *
               * @private
               * @param {Object} object The object to compare.
               * @param {Object} other The other object to compare.
               * @param {string} tag The `toStringTag` of the objects to compare.
               * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
               * @param {Function} customizer The function to customize comparisons.
               * @param {Function} equalFunc The function to determine equivalents of values.
               * @param {Object} stack Tracks traversed `object` and `other` objects.
               * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
               */
              function equalByTag(
                object,
                other,
                tag,
                bitmask,
                customizer,
                equalFunc,
                stack
              ) {
                switch (tag) {
                  case dataViewTag:
                    if (
                      object.byteLength != other.byteLength ||
                      object.byteOffset != other.byteOffset
                    ) {
                      return false;
                    }
                    object = object.buffer;
                    other = other.buffer;

                  case arrayBufferTag:
                    if (
                      object.byteLength != other.byteLength ||
                      !equalFunc(new Uint8Array(object), new Uint8Array(other))
                    ) {
                      return false;
                    }
                    return true;

                  case boolTag:
                  case dateTag:
                  case numberTag:
                    // Coerce booleans to `1` or `0` and dates to milliseconds.
                    // Invalid dates are coerced to `NaN`.
                    return eq(+object, +other);

                  case errorTag:
                    return (
                      object.name == other.name &&
                      object.message == other.message
                    );

                  case regexpTag:
                  case stringTag:
                    // Coerce regexes to strings and treat strings, primitives and objects,
                    // as equal. See http://www.ecma-international.org/ecma-262/7.0/#sec-regexp.prototype.tostring
                    // for more details.
                    return object == other + "";

                  case mapTag:
                    var convert = mapToArray;

                  case setTag:
                    var isPartial = bitmask & COMPARE_PARTIAL_FLAG;
                    convert || (convert = setToArray);

                    if (object.size != other.size && !isPartial) {
                      return false;
                    }
                    // Assume cyclic values are equal.
                    var stacked = stack.get(object);
                    if (stacked) {
                      return stacked == other;
                    }
                    bitmask |= COMPARE_UNORDERED_FLAG;

                    // Recursively compare objects (susceptible to call stack limits).
                    stack.set(object, other);
                    var result = equalArrays(
                      convert(object),
                      convert(other),
                      bitmask,
                      customizer,
                      equalFunc,
                      stack
                    );
                    stack["delete"](object);
                    return result;

                  case symbolTag:
                    if (symbolValueOf) {
                      return (
                        symbolValueOf.call(object) == symbolValueOf.call(other)
                      );
                    }
                }
                return false;
              }

              /**
               * A specialized version of `baseIsEqualDeep` for objects with support for
               * partial deep comparisons.
               *
               * @private
               * @param {Object} object The object to compare.
               * @param {Object} other The other object to compare.
               * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
               * @param {Function} customizer The function to customize comparisons.
               * @param {Function} equalFunc The function to determine equivalents of values.
               * @param {Object} stack Tracks traversed `object` and `other` objects.
               * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
               */
              function equalObjects(
                object,
                other,
                bitmask,
                customizer,
                equalFunc,
                stack
              ) {
                var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
                  objProps = getAllKeys(object),
                  objLength = objProps.length,
                  othProps = getAllKeys(other),
                  othLength = othProps.length;

                if (objLength != othLength && !isPartial) {
                  return false;
                }
                var index = objLength;
                while (index--) {
                  var key = objProps[index];
                  if (
                    !(isPartial
                      ? key in other
                      : hasOwnProperty.call(other, key))
                  ) {
                    return false;
                  }
                }
                // Assume cyclic values are equal.
                var stacked = stack.get(object);
                if (stacked && stack.get(other)) {
                  return stacked == other;
                }
                var result = true;
                stack.set(object, other);
                stack.set(other, object);

                var skipCtor = isPartial;
                while (++index < objLength) {
                  key = objProps[index];
                  var objValue = object[key],
                    othValue = other[key];

                  if (customizer) {
                    var compared = isPartial
                      ? customizer(
                          othValue,
                          objValue,
                          key,
                          other,
                          object,
                          stack
                        )
                      : customizer(
                          objValue,
                          othValue,
                          key,
                          object,
                          other,
                          stack
                        );
                  }
                  // Recursively compare objects (susceptible to call stack limits).
                  if (
                    !(compared === undefined
                      ? objValue === othValue ||
                        equalFunc(
                          objValue,
                          othValue,
                          bitmask,
                          customizer,
                          stack
                        )
                      : compared)
                  ) {
                    result = false;
                    break;
                  }
                  skipCtor || (skipCtor = key == "constructor");
                }
                if (result && !skipCtor) {
                  var objCtor = object.constructor,
                    othCtor = other.constructor;

                  // Non `Object` object instances with different constructors are not equal.
                  if (
                    objCtor != othCtor &&
                    "constructor" in object &&
                    "constructor" in other &&
                    !(
                      typeof objCtor == "function" &&
                      objCtor instanceof objCtor &&
                      typeof othCtor == "function" &&
                      othCtor instanceof othCtor
                    )
                  ) {
                    result = false;
                  }
                }
                stack["delete"](object);
                stack["delete"](other);
                return result;
              }

              /**
               * Creates an array of own enumerable property names and symbols of `object`.
               *
               * @private
               * @param {Object} object The object to query.
               * @returns {Array} Returns the array of property names and symbols.
               */
              function getAllKeys(object) {
                return baseGetAllKeys(object, keys, getSymbols);
              }

              /**
               * Gets the data for `map`.
               *
               * @private
               * @param {Object} map The map to query.
               * @param {string} key The reference key.
               * @returns {*} Returns the map data.
               */
              function getMapData(map, key) {
                var data = map.__data__;
                return isKeyable(key)
                  ? data[typeof key == "string" ? "string" : "hash"]
                  : data.map;
              }

              /**
               * Gets the native function at `key` of `object`.
               *
               * @private
               * @param {Object} object The object to query.
               * @param {string} key The key of the method to get.
               * @returns {*} Returns the function if it's native, else `undefined`.
               */
              function getNative(object, key) {
                var value = getValue(object, key);
                return baseIsNative(value) ? value : undefined;
              }

              /**
               * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
               *
               * @private
               * @param {*} value The value to query.
               * @returns {string} Returns the raw `toStringTag`.
               */
              function getRawTag(value) {
                var isOwn = hasOwnProperty.call(value, symToStringTag),
                  tag = value[symToStringTag];

                try {
                  value[symToStringTag] = undefined;
                  var unmasked = true;
                } catch (e) {}

                var result = nativeObjectToString.call(value);
                if (unmasked) {
                  if (isOwn) {
                    value[symToStringTag] = tag;
                  } else {
                    delete value[symToStringTag];
                  }
                }
                return result;
              }

              /**
               * Creates an array of the own enumerable symbols of `object`.
               *
               * @private
               * @param {Object} object The object to query.
               * @returns {Array} Returns the array of symbols.
               */
              var getSymbols = !nativeGetSymbols
                ? stubArray
                : function (object) {
                    if (object == null) {
                      return [];
                    }
                    object = Object(object);
                    return arrayFilter(
                      nativeGetSymbols(object),
                      function (symbol) {
                        return propertyIsEnumerable.call(object, symbol);
                      }
                    );
                  };

              /**
               * Gets the `toStringTag` of `value`.
               *
               * @private
               * @param {*} value The value to query.
               * @returns {string} Returns the `toStringTag`.
               */
              var getTag = baseGetTag;

              // Fallback for data views, maps, sets, and weak maps in IE 11 and promises in Node.js < 6.
              if (
                (DataView &&
                  getTag(new DataView(new ArrayBuffer(1))) != dataViewTag) ||
                (Map && getTag(new Map()) != mapTag) ||
                (Promise && getTag(Promise.resolve()) != promiseTag) ||
                (Set && getTag(new Set()) != setTag) ||
                (WeakMap && getTag(new WeakMap()) != weakMapTag)
              ) {
                getTag = function (value) {
                  var result = baseGetTag(value),
                    Ctor = result == objectTag ? value.constructor : undefined,
                    ctorString = Ctor ? toSource(Ctor) : "";

                  if (ctorString) {
                    switch (ctorString) {
                      case dataViewCtorString:
                        return dataViewTag;
                      case mapCtorString:
                        return mapTag;
                      case promiseCtorString:
                        return promiseTag;
                      case setCtorString:
                        return setTag;
                      case weakMapCtorString:
                        return weakMapTag;
                    }
                  }
                  return result;
                };
              }

              /**
               * Checks if `value` is a valid array-like index.
               *
               * @private
               * @param {*} value The value to check.
               * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
               * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
               */
              function isIndex(value, length) {
                length = length == null ? MAX_SAFE_INTEGER : length;
                return (
                  !!length &&
                  (typeof value == "number" || reIsUint.test(value)) &&
                  value > -1 &&
                  value % 1 == 0 &&
                  value < length
                );
              }

              /**
               * Checks if `value` is suitable for use as unique object key.
               *
               * @private
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
               */
              function isKeyable(value) {
                var type = typeof value;
                return type == "string" ||
                  type == "number" ||
                  type == "symbol" ||
                  type == "boolean"
                  ? value !== "__proto__"
                  : value === null;
              }

              /**
               * Checks if `func` has its source masked.
               *
               * @private
               * @param {Function} func The function to check.
               * @returns {boolean} Returns `true` if `func` is masked, else `false`.
               */
              function isMasked(func) {
                return !!maskSrcKey && maskSrcKey in func;
              }

              /**
               * Checks if `value` is likely a prototype object.
               *
               * @private
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a prototype, else `false`.
               */
              function isPrototype(value) {
                var Ctor = value && value.constructor,
                  proto =
                    (typeof Ctor == "function" && Ctor.prototype) ||
                    objectProto;

                return value === proto;
              }

              /**
               * Converts `value` to a string using `Object.prototype.toString`.
               *
               * @private
               * @param {*} value The value to convert.
               * @returns {string} Returns the converted string.
               */
              function objectToString(value) {
                return nativeObjectToString.call(value);
              }

              /**
               * Converts `func` to its source code.
               *
               * @private
               * @param {Function} func The function to convert.
               * @returns {string} Returns the source code.
               */
              function toSource(func) {
                if (func != null) {
                  try {
                    return funcToString.call(func);
                  } catch (e) {}
                  try {
                    return func + "";
                  } catch (e) {}
                }
                return "";
              }

              /**
               * Performs a
               * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
               * comparison between two values to determine if they are equivalent.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to compare.
               * @param {*} other The other value to compare.
               * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
               * @example
               *
               * var object = { 'a': 1 };
               * var other = { 'a': 1 };
               *
               * _.eq(object, object);
               * // => true
               *
               * _.eq(object, other);
               * // => false
               *
               * _.eq('a', 'a');
               * // => true
               *
               * _.eq('a', Object('a'));
               * // => false
               *
               * _.eq(NaN, NaN);
               * // => true
               */
              function eq(value, other) {
                return value === other || (value !== value && other !== other);
              }

              /**
               * Checks if `value` is likely an `arguments` object.
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an `arguments` object,
               *  else `false`.
               * @example
               *
               * _.isArguments(function() { return arguments; }());
               * // => true
               *
               * _.isArguments([1, 2, 3]);
               * // => false
               */
              var isArguments = baseIsArguments(
                (function () {
                  return arguments;
                })()
              )
                ? baseIsArguments
                : function (value) {
                    return (
                      isObjectLike(value) &&
                      hasOwnProperty.call(value, "callee") &&
                      !propertyIsEnumerable.call(value, "callee")
                    );
                  };

              /**
               * Checks if `value` is classified as an `Array` object.
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an array, else `false`.
               * @example
               *
               * _.isArray([1, 2, 3]);
               * // => true
               *
               * _.isArray(document.body.children);
               * // => false
               *
               * _.isArray('abc');
               * // => false
               *
               * _.isArray(_.noop);
               * // => false
               */
              var isArray = Array.isArray;

              /**
               * Checks if `value` is array-like. A value is considered array-like if it's
               * not a function and has a `value.length` that's an integer greater than or
               * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
               * @example
               *
               * _.isArrayLike([1, 2, 3]);
               * // => true
               *
               * _.isArrayLike(document.body.children);
               * // => true
               *
               * _.isArrayLike('abc');
               * // => true
               *
               * _.isArrayLike(_.noop);
               * // => false
               */
              function isArrayLike(value) {
                return (
                  value != null && isLength(value.length) && !isFunction(value)
                );
              }

              /**
               * Checks if `value` is a buffer.
               *
               * @static
               * @memberOf _
               * @since 4.3.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
               * @example
               *
               * _.isBuffer(new Buffer(2));
               * // => true
               *
               * _.isBuffer(new Uint8Array(2));
               * // => false
               */
              var isBuffer = nativeIsBuffer || stubFalse;

              /**
               * Performs a deep comparison between two values to determine if they are
               * equivalent.
               *
               * **Note:** This method supports comparing arrays, array buffers, booleans,
               * date objects, error objects, maps, numbers, `Object` objects, regexes,
               * sets, strings, symbols, and typed arrays. `Object` objects are compared
               * by their own, not inherited, enumerable properties. Functions and DOM
               * nodes are compared by strict equality, i.e. `===`.
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to compare.
               * @param {*} other The other value to compare.
               * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
               * @example
               *
               * var object = { 'a': 1 };
               * var other = { 'a': 1 };
               *
               * _.isEqual(object, other);
               * // => true
               *
               * object === other;
               * // => false
               */
              function isEqual(value, other) {
                return baseIsEqual(value, other);
              }

              /**
               * Checks if `value` is classified as a `Function` object.
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a function, else `false`.
               * @example
               *
               * _.isFunction(_);
               * // => true
               *
               * _.isFunction(/abc/);
               * // => false
               */
              function isFunction(value) {
                if (!isObject(value)) {
                  return false;
                }
                // The use of `Object#toString` avoids issues with the `typeof` operator
                // in Safari 9 which returns 'object' for typed arrays and other constructors.
                var tag = baseGetTag(value);
                return (
                  tag == funcTag ||
                  tag == genTag ||
                  tag == asyncTag ||
                  tag == proxyTag
                );
              }

              /**
               * Checks if `value` is a valid array-like length.
               *
               * **Note:** This method is loosely based on
               * [`ToLength`](http://ecma-international.org/ecma-262/7.0/#sec-tolength).
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
               * @example
               *
               * _.isLength(3);
               * // => true
               *
               * _.isLength(Number.MIN_VALUE);
               * // => false
               *
               * _.isLength(Infinity);
               * // => false
               *
               * _.isLength('3');
               * // => false
               */
              function isLength(value) {
                return (
                  typeof value == "number" &&
                  value > -1 &&
                  value % 1 == 0 &&
                  value <= MAX_SAFE_INTEGER
                );
              }

              /**
               * Checks if `value` is the
               * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
               * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an object, else `false`.
               * @example
               *
               * _.isObject({});
               * // => true
               *
               * _.isObject([1, 2, 3]);
               * // => true
               *
               * _.isObject(_.noop);
               * // => true
               *
               * _.isObject(null);
               * // => false
               */
              function isObject(value) {
                var type = typeof value;
                return (
                  value != null && (type == "object" || type == "function")
                );
              }

              /**
               * Checks if `value` is object-like. A value is object-like if it's not `null`
               * and has a `typeof` result of "object".
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
               * @example
               *
               * _.isObjectLike({});
               * // => true
               *
               * _.isObjectLike([1, 2, 3]);
               * // => true
               *
               * _.isObjectLike(_.noop);
               * // => false
               *
               * _.isObjectLike(null);
               * // => false
               */
              function isObjectLike(value) {
                return value != null && typeof value == "object";
              }

              /**
               * Checks if `value` is classified as a typed array.
               *
               * @static
               * @memberOf _
               * @since 3.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
               * @example
               *
               * _.isTypedArray(new Uint8Array);
               * // => true
               *
               * _.isTypedArray([]);
               * // => false
               */
              var isTypedArray = nodeIsTypedArray
                ? baseUnary(nodeIsTypedArray)
                : baseIsTypedArray;

              /**
               * Creates an array of the own enumerable property names of `object`.
               *
               * **Note:** Non-object values are coerced to objects. See the
               * [ES spec](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
               * for more details.
               *
               * @static
               * @since 0.1.0
               * @memberOf _
               * @category Object
               * @param {Object} object The object to query.
               * @returns {Array} Returns the array of property names.
               * @example
               *
               * function Foo() {
               *   this.a = 1;
               *   this.b = 2;
               * }
               *
               * Foo.prototype.c = 3;
               *
               * _.keys(new Foo);
               * // => ['a', 'b'] (iteration order is not guaranteed)
               *
               * _.keys('hi');
               * // => ['0', '1']
               */
              function keys(object) {
                return isArrayLike(object)
                  ? arrayLikeKeys(object)
                  : baseKeys(object);
              }

              /**
               * This method returns a new empty array.
               *
               * @static
               * @memberOf _
               * @since 4.13.0
               * @category Util
               * @returns {Array} Returns the new empty array.
               * @example
               *
               * var arrays = _.times(2, _.stubArray);
               *
               * console.log(arrays);
               * // => [[], []]
               *
               * console.log(arrays[0] === arrays[1]);
               * // => false
               */
              function stubArray() {
                return [];
              }

              /**
               * This method returns `false`.
               *
               * @static
               * @memberOf _
               * @since 4.13.0
               * @category Util
               * @returns {boolean} Returns `false`.
               * @example
               *
               * _.times(2, _.stubFalse);
               * // => [false, false]
               */
              function stubFalse() {
                return false;
              }

              module.exports = isEqual;
            }.call(this));
          }.call(
            this,
            typeof global !== "undefined"
              ? global
              : typeof self !== "undefined"
              ? self
              : typeof window !== "undefined"
              ? window
              : {}
          ));
        },
        {},
      ],
      14: [
        function (require, module, exports) {
          (function (global) {
            (function () {
              /**
               * Lodash (Custom Build) <https://lodash.com/>
               * Build: `lodash modularize exports="npm" -o ./`
               * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
               * Released under MIT license <https://lodash.com/license>
               * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
               * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
               */
              var reInterpolate = require("lodash._reinterpolate"),
                templateSettings = require("lodash.templatesettings");

              /** Used to detect hot functions by number of calls within a span of milliseconds. */
              var HOT_COUNT = 800,
                HOT_SPAN = 16;

              /** Used as references for various `Number` constants. */
              var INFINITY = 1 / 0,
                MAX_SAFE_INTEGER = 9007199254740991;

              /** `Object#toString` result references. */
              var argsTag = "[object Arguments]",
                arrayTag = "[object Array]",
                asyncTag = "[object AsyncFunction]",
                boolTag = "[object Boolean]",
                dateTag = "[object Date]",
                domExcTag = "[object DOMException]",
                errorTag = "[object Error]",
                funcTag = "[object Function]",
                genTag = "[object GeneratorFunction]",
                mapTag = "[object Map]",
                numberTag = "[object Number]",
                nullTag = "[object Null]",
                objectTag = "[object Object]",
                proxyTag = "[object Proxy]",
                regexpTag = "[object RegExp]",
                setTag = "[object Set]",
                stringTag = "[object String]",
                symbolTag = "[object Symbol]",
                undefinedTag = "[object Undefined]",
                weakMapTag = "[object WeakMap]";

              var arrayBufferTag = "[object ArrayBuffer]",
                dataViewTag = "[object DataView]",
                float32Tag = "[object Float32Array]",
                float64Tag = "[object Float64Array]",
                int8Tag = "[object Int8Array]",
                int16Tag = "[object Int16Array]",
                int32Tag = "[object Int32Array]",
                uint8Tag = "[object Uint8Array]",
                uint8ClampedTag = "[object Uint8ClampedArray]",
                uint16Tag = "[object Uint16Array]",
                uint32Tag = "[object Uint32Array]";

              /** Used to match empty string literals in compiled template source. */
              var reEmptyStringLeading = /\b__p \+= '';/g,
                reEmptyStringMiddle = /\b(__p \+=) '' \+/g,
                reEmptyStringTrailing = /(__e\(.*?\)|\b__t\)) \+\n'';/g;

              /**
               * Used to match `RegExp`
               * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
               */
              var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

              /**
               * Used to match
               * [ES template delimiters](http://ecma-international.org/ecma-262/7.0/#sec-template-literal-lexical-components).
               */
              var reEsTemplate = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g;

              /** Used to detect host constructors (Safari). */
              var reIsHostCtor = /^\[object .+?Constructor\]$/;

              /** Used to detect unsigned integer values. */
              var reIsUint = /^(?:0|[1-9]\d*)$/;

              /** Used to ensure capturing order of template delimiters. */
              var reNoMatch = /($^)/;

              /** Used to match unescaped characters in compiled string literals. */
              var reUnescapedString = /['\n\r\u2028\u2029\\]/g;

              /** Used to identify `toStringTag` values of typed arrays. */
              var typedArrayTags = {};
              typedArrayTags[float32Tag] =
                typedArrayTags[float64Tag] =
                typedArrayTags[int8Tag] =
                typedArrayTags[int16Tag] =
                typedArrayTags[int32Tag] =
                typedArrayTags[uint8Tag] =
                typedArrayTags[uint8ClampedTag] =
                typedArrayTags[uint16Tag] =
                typedArrayTags[uint32Tag] =
                  true;
              typedArrayTags[argsTag] =
                typedArrayTags[arrayTag] =
                typedArrayTags[arrayBufferTag] =
                typedArrayTags[boolTag] =
                typedArrayTags[dataViewTag] =
                typedArrayTags[dateTag] =
                typedArrayTags[errorTag] =
                typedArrayTags[funcTag] =
                typedArrayTags[mapTag] =
                typedArrayTags[numberTag] =
                typedArrayTags[objectTag] =
                typedArrayTags[regexpTag] =
                typedArrayTags[setTag] =
                typedArrayTags[stringTag] =
                typedArrayTags[weakMapTag] =
                  false;

              /** Used to escape characters for inclusion in compiled string literals. */
              var stringEscapes = {
                "\\": "\\",
                "'": "'",
                "\n": "n",
                "\r": "r",
                "\u2028": "u2028",
                "\u2029": "u2029",
              };

              /** Detect free variable `global` from Node.js. */
              var freeGlobal =
                typeof global == "object" &&
                global &&
                global.Object === Object &&
                global;

              /** Detect free variable `self`. */
              var freeSelf =
                typeof self == "object" &&
                self &&
                self.Object === Object &&
                self;

              /** Used as a reference to the global object. */
              var root = freeGlobal || freeSelf || Function("return this")();

              /** Detect free variable `exports`. */
              var freeExports =
                typeof exports == "object" &&
                exports &&
                !exports.nodeType &&
                exports;

              /** Detect free variable `module`. */
              var freeModule =
                freeExports &&
                typeof module == "object" &&
                module &&
                !module.nodeType &&
                module;

              /** Detect the popular CommonJS extension `module.exports`. */
              var moduleExports =
                freeModule && freeModule.exports === freeExports;

              /** Detect free variable `process` from Node.js. */
              var freeProcess = moduleExports && freeGlobal.process;

              /** Used to access faster Node.js helpers. */
              var nodeUtil = (function () {
                try {
                  // Use `util.types` for Node.js 10+.
                  var types =
                    freeModule &&
                    freeModule.require &&
                    freeModule.require("util").types;

                  if (types) {
                    return types;
                  }

                  // Legacy `process.binding('util')` for Node.js < 10.
                  return (
                    freeProcess &&
                    freeProcess.binding &&
                    freeProcess.binding("util")
                  );
                } catch (e) {}
              })();

              /* Node.js helper references. */
              var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;

              /**
               * A faster alternative to `Function#apply`, this function invokes `func`
               * with the `this` binding of `thisArg` and the arguments of `args`.
               *
               * @private
               * @param {Function} func The function to invoke.
               * @param {*} thisArg The `this` binding of `func`.
               * @param {Array} args The arguments to invoke `func` with.
               * @returns {*} Returns the result of `func`.
               */
              function apply(func, thisArg, args) {
                switch (args.length) {
                  case 0:
                    return func.call(thisArg);
                  case 1:
                    return func.call(thisArg, args[0]);
                  case 2:
                    return func.call(thisArg, args[0], args[1]);
                  case 3:
                    return func.call(thisArg, args[0], args[1], args[2]);
                }
                return func.apply(thisArg, args);
              }

              /**
               * A specialized version of `_.map` for arrays without support for iteratee
               * shorthands.
               *
               * @private
               * @param {Array} [array] The array to iterate over.
               * @param {Function} iteratee The function invoked per iteration.
               * @returns {Array} Returns the new mapped array.
               */
              function arrayMap(array, iteratee) {
                var index = -1,
                  length = array == null ? 0 : array.length,
                  result = Array(length);

                while (++index < length) {
                  result[index] = iteratee(array[index], index, array);
                }
                return result;
              }

              /**
               * The base implementation of `_.times` without support for iteratee shorthands
               * or max array length checks.
               *
               * @private
               * @param {number} n The number of times to invoke `iteratee`.
               * @param {Function} iteratee The function invoked per iteration.
               * @returns {Array} Returns the array of results.
               */
              function baseTimes(n, iteratee) {
                var index = -1,
                  result = Array(n);

                while (++index < n) {
                  result[index] = iteratee(index);
                }
                return result;
              }

              /**
               * The base implementation of `_.unary` without support for storing metadata.
               *
               * @private
               * @param {Function} func The function to cap arguments for.
               * @returns {Function} Returns the new capped function.
               */
              function baseUnary(func) {
                return function (value) {
                  return func(value);
                };
              }

              /**
               * The base implementation of `_.values` and `_.valuesIn` which creates an
               * array of `object` property values corresponding to the property names
               * of `props`.
               *
               * @private
               * @param {Object} object The object to query.
               * @param {Array} props The property names to get values for.
               * @returns {Object} Returns the array of property values.
               */
              function baseValues(object, props) {
                return arrayMap(props, function (key) {
                  return object[key];
                });
              }

              /**
               * Used by `_.template` to escape characters for inclusion in compiled string literals.
               *
               * @private
               * @param {string} chr The matched character to escape.
               * @returns {string} Returns the escaped character.
               */
              function escapeStringChar(chr) {
                return "\\" + stringEscapes[chr];
              }

              /**
               * Gets the value at `key` of `object`.
               *
               * @private
               * @param {Object} [object] The object to query.
               * @param {string} key The key of the property to get.
               * @returns {*} Returns the property value.
               */
              function getValue(object, key) {
                return object == null ? undefined : object[key];
              }

              /**
               * Creates a unary function that invokes `func` with its argument transformed.
               *
               * @private
               * @param {Function} func The function to wrap.
               * @param {Function} transform The argument transform.
               * @returns {Function} Returns the new function.
               */
              function overArg(func, transform) {
                return function (arg) {
                  return func(transform(arg));
                };
              }

              /** Used for built-in method references. */
              var funcProto = Function.prototype,
                objectProto = Object.prototype;

              /** Used to detect overreaching core-js shims. */
              var coreJsData = root["__core-js_shared__"];

              /** Used to resolve the decompiled source of functions. */
              var funcToString = funcProto.toString;

              /** Used to check objects for own properties. */
              var hasOwnProperty = objectProto.hasOwnProperty;

              /** Used to detect methods masquerading as native. */
              var maskSrcKey = (function () {
                var uid = /[^.]+$/.exec(
                  (coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO) ||
                    ""
                );
                return uid ? "Symbol(src)_1." + uid : "";
              })();

              /**
               * Used to resolve the
               * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
               * of values.
               */
              var nativeObjectToString = objectProto.toString;

              /** Used to infer the `Object` constructor. */
              var objectCtorString = funcToString.call(Object);

              /** Used to detect if a method is native. */
              var reIsNative = RegExp(
                "^" +
                  funcToString
                    .call(hasOwnProperty)
                    .replace(reRegExpChar, "\\$&")
                    .replace(
                      /hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,
                      "$1.*?"
                    ) +
                  "$"
              );

              /** Built-in value references. */
              var Buffer = moduleExports ? root.Buffer : undefined,
                Symbol = root.Symbol,
                getPrototype = overArg(Object.getPrototypeOf, Object),
                propertyIsEnumerable = objectProto.propertyIsEnumerable,
                symToStringTag = Symbol ? Symbol.toStringTag : undefined;

              var defineProperty = (function () {
                try {
                  var func = getNative(Object, "defineProperty");
                  func({}, "", {});
                  return func;
                } catch (e) {}
              })();

              /* Built-in method references for those with the same name as other `lodash` methods. */
              var nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined,
                nativeKeys = overArg(Object.keys, Object),
                nativeMax = Math.max,
                nativeNow = Date.now;

              /** Used to convert symbols to primitives and strings. */
              var symbolProto = Symbol ? Symbol.prototype : undefined,
                symbolToString = symbolProto ? symbolProto.toString : undefined;

              /**
               * Creates an array of the enumerable property names of the array-like `value`.
               *
               * @private
               * @param {*} value The value to query.
               * @param {boolean} inherited Specify returning inherited property names.
               * @returns {Array} Returns the array of property names.
               */
              function arrayLikeKeys(value, inherited) {
                var isArr = isArray(value),
                  isArg = !isArr && isArguments(value),
                  isBuff = !isArr && !isArg && isBuffer(value),
                  isType = !isArr && !isArg && !isBuff && isTypedArray(value),
                  skipIndexes = isArr || isArg || isBuff || isType,
                  result = skipIndexes ? baseTimes(value.length, String) : [],
                  length = result.length;

                for (var key in value) {
                  if (
                    (inherited || hasOwnProperty.call(value, key)) &&
                    !(
                      skipIndexes &&
                      // Safari 9 has enumerable `arguments.length` in strict mode.
                      (key == "length" ||
                        // Node.js 0.10 has enumerable non-index properties on buffers.
                        (isBuff && (key == "offset" || key == "parent")) ||
                        // PhantomJS 2 has enumerable non-index properties on typed arrays.
                        (isType &&
                          (key == "buffer" ||
                            key == "byteLength" ||
                            key == "byteOffset")) ||
                        // Skip index properties.
                        isIndex(key, length))
                    )
                  ) {
                    result.push(key);
                  }
                }
                return result;
              }

              /**
               * Assigns `value` to `key` of `object` if the existing value is not equivalent
               * using [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
               * for equality comparisons.
               *
               * @private
               * @param {Object} object The object to modify.
               * @param {string} key The key of the property to assign.
               * @param {*} value The value to assign.
               */
              function assignValue(object, key, value) {
                var objValue = object[key];
                if (
                  !(hasOwnProperty.call(object, key) && eq(objValue, value)) ||
                  (value === undefined && !(key in object))
                ) {
                  baseAssignValue(object, key, value);
                }
              }

              /**
               * The base implementation of `assignValue` and `assignMergeValue` without
               * value checks.
               *
               * @private
               * @param {Object} object The object to modify.
               * @param {string} key The key of the property to assign.
               * @param {*} value The value to assign.
               */
              function baseAssignValue(object, key, value) {
                if (key == "__proto__" && defineProperty) {
                  defineProperty(object, key, {
                    configurable: true,
                    enumerable: true,
                    value: value,
                    writable: true,
                  });
                } else {
                  object[key] = value;
                }
              }

              /**
               * The base implementation of `getTag` without fallbacks for buggy environments.
               *
               * @private
               * @param {*} value The value to query.
               * @returns {string} Returns the `toStringTag`.
               */
              function baseGetTag(value) {
                if (value == null) {
                  return value === undefined ? undefinedTag : nullTag;
                }
                return symToStringTag && symToStringTag in Object(value)
                  ? getRawTag(value)
                  : objectToString(value);
              }

              /**
               * The base implementation of `_.isArguments`.
               *
               * @private
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an `arguments` object,
               */
              function baseIsArguments(value) {
                return isObjectLike(value) && baseGetTag(value) == argsTag;
              }

              /**
               * The base implementation of `_.isNative` without bad shim checks.
               *
               * @private
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a native function,
               *  else `false`.
               */
              function baseIsNative(value) {
                if (!isObject(value) || isMasked(value)) {
                  return false;
                }
                var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
                return pattern.test(toSource(value));
              }

              /**
               * The base implementation of `_.isTypedArray` without Node.js optimizations.
               *
               * @private
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
               */
              function baseIsTypedArray(value) {
                return (
                  isObjectLike(value) &&
                  isLength(value.length) &&
                  !!typedArrayTags[baseGetTag(value)]
                );
              }

              /**
               * The base implementation of `_.keys` which doesn't treat sparse arrays as dense.
               *
               * @private
               * @param {Object} object The object to query.
               * @returns {Array} Returns the array of property names.
               */
              function baseKeys(object) {
                if (!isPrototype(object)) {
                  return nativeKeys(object);
                }
                var result = [];
                for (var key in Object(object)) {
                  if (
                    hasOwnProperty.call(object, key) &&
                    key != "constructor"
                  ) {
                    result.push(key);
                  }
                }
                return result;
              }

              /**
               * The base implementation of `_.keysIn` which doesn't treat sparse arrays as dense.
               *
               * @private
               * @param {Object} object The object to query.
               * @returns {Array} Returns the array of property names.
               */
              function baseKeysIn(object) {
                if (!isObject(object)) {
                  return nativeKeysIn(object);
                }
                var isProto = isPrototype(object),
                  result = [];

                for (var key in object) {
                  if (
                    !(
                      key == "constructor" &&
                      (isProto || !hasOwnProperty.call(object, key))
                    )
                  ) {
                    result.push(key);
                  }
                }
                return result;
              }

              /**
               * The base implementation of `_.rest` which doesn't validate or coerce arguments.
               *
               * @private
               * @param {Function} func The function to apply a rest parameter to.
               * @param {number} [start=func.length-1] The start position of the rest parameter.
               * @returns {Function} Returns the new function.
               */
              function baseRest(func, start) {
                return setToString(overRest(func, start, identity), func + "");
              }

              /**
               * The base implementation of `setToString` without support for hot loop shorting.
               *
               * @private
               * @param {Function} func The function to modify.
               * @param {Function} string The `toString` result.
               * @returns {Function} Returns `func`.
               */
              var baseSetToString = !defineProperty
                ? identity
                : function (func, string) {
                    return defineProperty(func, "toString", {
                      configurable: true,
                      enumerable: false,
                      value: constant(string),
                      writable: true,
                    });
                  };

              /**
               * The base implementation of `_.toString` which doesn't convert nullish
               * values to empty strings.
               *
               * @private
               * @param {*} value The value to process.
               * @returns {string} Returns the string.
               */
              function baseToString(value) {
                // Exit early for strings to avoid a performance hit in some environments.
                if (typeof value == "string") {
                  return value;
                }
                if (isArray(value)) {
                  // Recursively convert values (susceptible to call stack limits).
                  return arrayMap(value, baseToString) + "";
                }
                if (isSymbol(value)) {
                  return symbolToString ? symbolToString.call(value) : "";
                }
                var result = value + "";
                return result == "0" && 1 / value == -INFINITY ? "-0" : result;
              }

              /**
               * Copies properties of `source` to `object`.
               *
               * @private
               * @param {Object} source The object to copy properties from.
               * @param {Array} props The property identifiers to copy.
               * @param {Object} [object={}] The object to copy properties to.
               * @param {Function} [customizer] The function to customize copied values.
               * @returns {Object} Returns `object`.
               */
              function copyObject(source, props, object, customizer) {
                var isNew = !object;
                object || (object = {});

                var index = -1,
                  length = props.length;

                while (++index < length) {
                  var key = props[index];

                  var newValue = customizer
                    ? customizer(object[key], source[key], key, object, source)
                    : undefined;

                  if (newValue === undefined) {
                    newValue = source[key];
                  }
                  if (isNew) {
                    baseAssignValue(object, key, newValue);
                  } else {
                    assignValue(object, key, newValue);
                  }
                }
                return object;
              }

              /**
               * Creates a function like `_.assign`.
               *
               * @private
               * @param {Function} assigner The function to assign values.
               * @returns {Function} Returns the new assigner function.
               */
              function createAssigner(assigner) {
                return baseRest(function (object, sources) {
                  var index = -1,
                    length = sources.length,
                    customizer = length > 1 ? sources[length - 1] : undefined,
                    guard = length > 2 ? sources[2] : undefined;

                  customizer =
                    assigner.length > 3 && typeof customizer == "function"
                      ? (length--, customizer)
                      : undefined;

                  if (guard && isIterateeCall(sources[0], sources[1], guard)) {
                    customizer = length < 3 ? undefined : customizer;
                    length = 1;
                  }
                  object = Object(object);
                  while (++index < length) {
                    var source = sources[index];
                    if (source) {
                      assigner(object, source, index, customizer);
                    }
                  }
                  return object;
                });
              }

              /**
               * Used by `_.defaults` to customize its `_.assignIn` use to assign properties
               * of source objects to the destination object for all destination properties
               * that resolve to `undefined`.
               *
               * @private
               * @param {*} objValue The destination value.
               * @param {*} srcValue The source value.
               * @param {string} key The key of the property to assign.
               * @param {Object} object The parent object of `objValue`.
               * @returns {*} Returns the value to assign.
               */
              function customDefaultsAssignIn(objValue, srcValue, key, object) {
                if (
                  objValue === undefined ||
                  (eq(objValue, objectProto[key]) &&
                    !hasOwnProperty.call(object, key))
                ) {
                  return srcValue;
                }
                return objValue;
              }

              /**
               * Gets the native function at `key` of `object`.
               *
               * @private
               * @param {Object} object The object to query.
               * @param {string} key The key of the method to get.
               * @returns {*} Returns the function if it's native, else `undefined`.
               */
              function getNative(object, key) {
                var value = getValue(object, key);
                return baseIsNative(value) ? value : undefined;
              }

              /**
               * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
               *
               * @private
               * @param {*} value The value to query.
               * @returns {string} Returns the raw `toStringTag`.
               */
              function getRawTag(value) {
                var isOwn = hasOwnProperty.call(value, symToStringTag),
                  tag = value[symToStringTag];

                try {
                  value[symToStringTag] = undefined;
                  var unmasked = true;
                } catch (e) {}

                var result = nativeObjectToString.call(value);
                if (unmasked) {
                  if (isOwn) {
                    value[symToStringTag] = tag;
                  } else {
                    delete value[symToStringTag];
                  }
                }
                return result;
              }

              /**
               * Checks if `value` is a valid array-like index.
               *
               * @private
               * @param {*} value The value to check.
               * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
               * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
               */
              function isIndex(value, length) {
                var type = typeof value;
                length = length == null ? MAX_SAFE_INTEGER : length;

                return (
                  !!length &&
                  (type == "number" ||
                    (type != "symbol" && reIsUint.test(value))) &&
                  value > -1 &&
                  value % 1 == 0 &&
                  value < length
                );
              }

              /**
               * Checks if the given arguments are from an iteratee call.
               *
               * @private
               * @param {*} value The potential iteratee value argument.
               * @param {*} index The potential iteratee index or key argument.
               * @param {*} object The potential iteratee object argument.
               * @returns {boolean} Returns `true` if the arguments are from an iteratee call,
               *  else `false`.
               */
              function isIterateeCall(value, index, object) {
                if (!isObject(object)) {
                  return false;
                }
                var type = typeof index;
                if (
                  type == "number"
                    ? isArrayLike(object) && isIndex(index, object.length)
                    : type == "string" && index in object
                ) {
                  return eq(object[index], value);
                }
                return false;
              }

              /**
               * Checks if `func` has its source masked.
               *
               * @private
               * @param {Function} func The function to check.
               * @returns {boolean} Returns `true` if `func` is masked, else `false`.
               */
              function isMasked(func) {
                return !!maskSrcKey && maskSrcKey in func;
              }

              /**
               * Checks if `value` is likely a prototype object.
               *
               * @private
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a prototype, else `false`.
               */
              function isPrototype(value) {
                var Ctor = value && value.constructor,
                  proto =
                    (typeof Ctor == "function" && Ctor.prototype) ||
                    objectProto;

                return value === proto;
              }

              /**
               * This function is like
               * [`Object.keys`](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
               * except that it includes inherited enumerable properties.
               *
               * @private
               * @param {Object} object The object to query.
               * @returns {Array} Returns the array of property names.
               */
              function nativeKeysIn(object) {
                var result = [];
                if (object != null) {
                  for (var key in Object(object)) {
                    result.push(key);
                  }
                }
                return result;
              }

              /**
               * Converts `value` to a string using `Object.prototype.toString`.
               *
               * @private
               * @param {*} value The value to convert.
               * @returns {string} Returns the converted string.
               */
              function objectToString(value) {
                return nativeObjectToString.call(value);
              }

              /**
               * A specialized version of `baseRest` which transforms the rest array.
               *
               * @private
               * @param {Function} func The function to apply a rest parameter to.
               * @param {number} [start=func.length-1] The start position of the rest parameter.
               * @param {Function} transform The rest array transform.
               * @returns {Function} Returns the new function.
               */
              function overRest(func, start, transform) {
                start = nativeMax(
                  start === undefined ? func.length - 1 : start,
                  0
                );
                return function () {
                  var args = arguments,
                    index = -1,
                    length = nativeMax(args.length - start, 0),
                    array = Array(length);

                  while (++index < length) {
                    array[index] = args[start + index];
                  }
                  index = -1;
                  var otherArgs = Array(start + 1);
                  while (++index < start) {
                    otherArgs[index] = args[index];
                  }
                  otherArgs[start] = transform(array);
                  return apply(func, this, otherArgs);
                };
              }

              /**
               * Sets the `toString` method of `func` to return `string`.
               *
               * @private
               * @param {Function} func The function to modify.
               * @param {Function} string The `toString` result.
               * @returns {Function} Returns `func`.
               */
              var setToString = shortOut(baseSetToString);

              /**
               * Creates a function that'll short out and invoke `identity` instead
               * of `func` when it's called `HOT_COUNT` or more times in `HOT_SPAN`
               * milliseconds.
               *
               * @private
               * @param {Function} func The function to restrict.
               * @returns {Function} Returns the new shortable function.
               */
              function shortOut(func) {
                var count = 0,
                  lastCalled = 0;

                return function () {
                  var stamp = nativeNow(),
                    remaining = HOT_SPAN - (stamp - lastCalled);

                  lastCalled = stamp;
                  if (remaining > 0) {
                    if (++count >= HOT_COUNT) {
                      return arguments[0];
                    }
                  } else {
                    count = 0;
                  }
                  return func.apply(undefined, arguments);
                };
              }

              /**
               * Converts `func` to its source code.
               *
               * @private
               * @param {Function} func The function to convert.
               * @returns {string} Returns the source code.
               */
              function toSource(func) {
                if (func != null) {
                  try {
                    return funcToString.call(func);
                  } catch (e) {}
                  try {
                    return func + "";
                  } catch (e) {}
                }
                return "";
              }

              /**
               * Performs a
               * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
               * comparison between two values to determine if they are equivalent.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to compare.
               * @param {*} other The other value to compare.
               * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
               * @example
               *
               * var object = { 'a': 1 };
               * var other = { 'a': 1 };
               *
               * _.eq(object, object);
               * // => true
               *
               * _.eq(object, other);
               * // => false
               *
               * _.eq('a', 'a');
               * // => true
               *
               * _.eq('a', Object('a'));
               * // => false
               *
               * _.eq(NaN, NaN);
               * // => true
               */
              function eq(value, other) {
                return value === other || (value !== value && other !== other);
              }

              /**
               * Checks if `value` is likely an `arguments` object.
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an `arguments` object,
               *  else `false`.
               * @example
               *
               * _.isArguments(function() { return arguments; }());
               * // => true
               *
               * _.isArguments([1, 2, 3]);
               * // => false
               */
              var isArguments = baseIsArguments(
                (function () {
                  return arguments;
                })()
              )
                ? baseIsArguments
                : function (value) {
                    return (
                      isObjectLike(value) &&
                      hasOwnProperty.call(value, "callee") &&
                      !propertyIsEnumerable.call(value, "callee")
                    );
                  };

              /**
               * Checks if `value` is classified as an `Array` object.
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an array, else `false`.
               * @example
               *
               * _.isArray([1, 2, 3]);
               * // => true
               *
               * _.isArray(document.body.children);
               * // => false
               *
               * _.isArray('abc');
               * // => false
               *
               * _.isArray(_.noop);
               * // => false
               */
              var isArray = Array.isArray;

              /**
               * Checks if `value` is array-like. A value is considered array-like if it's
               * not a function and has a `value.length` that's an integer greater than or
               * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
               * @example
               *
               * _.isArrayLike([1, 2, 3]);
               * // => true
               *
               * _.isArrayLike(document.body.children);
               * // => true
               *
               * _.isArrayLike('abc');
               * // => true
               *
               * _.isArrayLike(_.noop);
               * // => false
               */
              function isArrayLike(value) {
                return (
                  value != null && isLength(value.length) && !isFunction(value)
                );
              }

              /**
               * Checks if `value` is a buffer.
               *
               * @static
               * @memberOf _
               * @since 4.3.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
               * @example
               *
               * _.isBuffer(new Buffer(2));
               * // => true
               *
               * _.isBuffer(new Uint8Array(2));
               * // => false
               */
              var isBuffer = nativeIsBuffer || stubFalse;

              /**
               * Checks if `value` is an `Error`, `EvalError`, `RangeError`, `ReferenceError`,
               * `SyntaxError`, `TypeError`, or `URIError` object.
               *
               * @static
               * @memberOf _
               * @since 3.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an error object, else `false`.
               * @example
               *
               * _.isError(new Error);
               * // => true
               *
               * _.isError(Error);
               * // => false
               */
              function isError(value) {
                if (!isObjectLike(value)) {
                  return false;
                }
                var tag = baseGetTag(value);
                return (
                  tag == errorTag ||
                  tag == domExcTag ||
                  (typeof value.message == "string" &&
                    typeof value.name == "string" &&
                    !isPlainObject(value))
                );
              }

              /**
               * Checks if `value` is classified as a `Function` object.
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a function, else `false`.
               * @example
               *
               * _.isFunction(_);
               * // => true
               *
               * _.isFunction(/abc/);
               * // => false
               */
              function isFunction(value) {
                if (!isObject(value)) {
                  return false;
                }
                // The use of `Object#toString` avoids issues with the `typeof` operator
                // in Safari 9 which returns 'object' for typed arrays and other constructors.
                var tag = baseGetTag(value);
                return (
                  tag == funcTag ||
                  tag == genTag ||
                  tag == asyncTag ||
                  tag == proxyTag
                );
              }

              /**
               * Checks if `value` is a valid array-like length.
               *
               * **Note:** This method is loosely based on
               * [`ToLength`](http://ecma-international.org/ecma-262/7.0/#sec-tolength).
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
               * @example
               *
               * _.isLength(3);
               * // => true
               *
               * _.isLength(Number.MIN_VALUE);
               * // => false
               *
               * _.isLength(Infinity);
               * // => false
               *
               * _.isLength('3');
               * // => false
               */
              function isLength(value) {
                return (
                  typeof value == "number" &&
                  value > -1 &&
                  value % 1 == 0 &&
                  value <= MAX_SAFE_INTEGER
                );
              }

              /**
               * Checks if `value` is the
               * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
               * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
               *
               * @static
               * @memberOf _
               * @since 0.1.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is an object, else `false`.
               * @example
               *
               * _.isObject({});
               * // => true
               *
               * _.isObject([1, 2, 3]);
               * // => true
               *
               * _.isObject(_.noop);
               * // => true
               *
               * _.isObject(null);
               * // => false
               */
              function isObject(value) {
                var type = typeof value;
                return (
                  value != null && (type == "object" || type == "function")
                );
              }

              /**
               * Checks if `value` is object-like. A value is object-like if it's not `null`
               * and has a `typeof` result of "object".
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
               * @example
               *
               * _.isObjectLike({});
               * // => true
               *
               * _.isObjectLike([1, 2, 3]);
               * // => true
               *
               * _.isObjectLike(_.noop);
               * // => false
               *
               * _.isObjectLike(null);
               * // => false
               */
              function isObjectLike(value) {
                return value != null && typeof value == "object";
              }

              /**
               * Checks if `value` is a plain object, that is, an object created by the
               * `Object` constructor or one with a `[[Prototype]]` of `null`.
               *
               * @static
               * @memberOf _
               * @since 0.8.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a plain object, else `false`.
               * @example
               *
               * function Foo() {
               *   this.a = 1;
               * }
               *
               * _.isPlainObject(new Foo);
               * // => false
               *
               * _.isPlainObject([1, 2, 3]);
               * // => false
               *
               * _.isPlainObject({ 'x': 0, 'y': 0 });
               * // => true
               *
               * _.isPlainObject(Object.create(null));
               * // => true
               */
              function isPlainObject(value) {
                if (!isObjectLike(value) || baseGetTag(value) != objectTag) {
                  return false;
                }
                var proto = getPrototype(value);
                if (proto === null) {
                  return true;
                }
                var Ctor =
                  hasOwnProperty.call(proto, "constructor") &&
                  proto.constructor;
                return (
                  typeof Ctor == "function" &&
                  Ctor instanceof Ctor &&
                  funcToString.call(Ctor) == objectCtorString
                );
              }

              /**
               * Checks if `value` is classified as a `Symbol` primitive or object.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
               * @example
               *
               * _.isSymbol(Symbol.iterator);
               * // => true
               *
               * _.isSymbol('abc');
               * // => false
               */
              function isSymbol(value) {
                return (
                  typeof value == "symbol" ||
                  (isObjectLike(value) && baseGetTag(value) == symbolTag)
                );
              }

              /**
               * Checks if `value` is classified as a typed array.
               *
               * @static
               * @memberOf _
               * @since 3.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
               * @example
               *
               * _.isTypedArray(new Uint8Array);
               * // => true
               *
               * _.isTypedArray([]);
               * // => false
               */
              var isTypedArray = nodeIsTypedArray
                ? baseUnary(nodeIsTypedArray)
                : baseIsTypedArray;

              /**
               * Converts `value` to a string. An empty string is returned for `null`
               * and `undefined` values. The sign of `-0` is preserved.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to convert.
               * @returns {string} Returns the converted string.
               * @example
               *
               * _.toString(null);
               * // => ''
               *
               * _.toString(-0);
               * // => '-0'
               *
               * _.toString([1, 2, 3]);
               * // => '1,2,3'
               */
              function toString(value) {
                return value == null ? "" : baseToString(value);
              }

              /**
               * This method is like `_.assignIn` except that it accepts `customizer`
               * which is invoked to produce the assigned values. If `customizer` returns
               * `undefined`, assignment is handled by the method instead. The `customizer`
               * is invoked with five arguments: (objValue, srcValue, key, object, source).
               *
               * **Note:** This method mutates `object`.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @alias extendWith
               * @category Object
               * @param {Object} object The destination object.
               * @param {...Object} sources The source objects.
               * @param {Function} [customizer] The function to customize assigned values.
               * @returns {Object} Returns `object`.
               * @see _.assignWith
               * @example
               *
               * function customizer(objValue, srcValue) {
               *   return _.isUndefined(objValue) ? srcValue : objValue;
               * }
               *
               * var defaults = _.partialRight(_.assignInWith, customizer);
               *
               * defaults({ 'a': 1 }, { 'b': 2 }, { 'a': 3 });
               * // => { 'a': 1, 'b': 2 }
               */
              var assignInWith = createAssigner(function (
                object,
                source,
                srcIndex,
                customizer
              ) {
                copyObject(source, keysIn(source), object, customizer);
              });

              /**
               * Creates an array of the own enumerable property names of `object`.
               *
               * **Note:** Non-object values are coerced to objects. See the
               * [ES spec](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
               * for more details.
               *
               * @static
               * @since 0.1.0
               * @memberOf _
               * @category Object
               * @param {Object} object The object to query.
               * @returns {Array} Returns the array of property names.
               * @example
               *
               * function Foo() {
               *   this.a = 1;
               *   this.b = 2;
               * }
               *
               * Foo.prototype.c = 3;
               *
               * _.keys(new Foo);
               * // => ['a', 'b'] (iteration order is not guaranteed)
               *
               * _.keys('hi');
               * // => ['0', '1']
               */
              function keys(object) {
                return isArrayLike(object)
                  ? arrayLikeKeys(object)
                  : baseKeys(object);
              }

              /**
               * Creates an array of the own and inherited enumerable property names of `object`.
               *
               * **Note:** Non-object values are coerced to objects.
               *
               * @static
               * @memberOf _
               * @since 3.0.0
               * @category Object
               * @param {Object} object The object to query.
               * @returns {Array} Returns the array of property names.
               * @example
               *
               * function Foo() {
               *   this.a = 1;
               *   this.b = 2;
               * }
               *
               * Foo.prototype.c = 3;
               *
               * _.keysIn(new Foo);
               * // => ['a', 'b', 'c'] (iteration order is not guaranteed)
               */
              function keysIn(object) {
                return isArrayLike(object)
                  ? arrayLikeKeys(object, true)
                  : baseKeysIn(object);
              }

              /**
               * Creates a compiled template function that can interpolate data properties
               * in "interpolate" delimiters, HTML-escape interpolated data properties in
               * "escape" delimiters, and execute JavaScript in "evaluate" delimiters. Data
               * properties may be accessed as free variables in the template. If a setting
               * object is given, it takes precedence over `_.templateSettings` values.
               *
               * **Note:** In the development build `_.template` utilizes
               * [sourceURLs](http://www.html5rocks.com/en/tutorials/developertools/sourcemaps/#toc-sourceurl)
               * for easier debugging.
               *
               * For more information on precompiling templates see
               * [lodash's custom builds documentation](https://lodash.com/custom-builds).
               *
               * For more information on Chrome extension sandboxes see
               * [Chrome's extensions documentation](https://developer.chrome.com/extensions/sandboxingEval).
               *
               * @static
               * @since 0.1.0
               * @memberOf _
               * @category String
               * @param {string} [string=''] The template string.
               * @param {Object} [options={}] The options object.
               * @param {RegExp} [options.escape=_.templateSettings.escape]
               *  The HTML "escape" delimiter.
               * @param {RegExp} [options.evaluate=_.templateSettings.evaluate]
               *  The "evaluate" delimiter.
               * @param {Object} [options.imports=_.templateSettings.imports]
               *  An object to import into the template as free variables.
               * @param {RegExp} [options.interpolate=_.templateSettings.interpolate]
               *  The "interpolate" delimiter.
               * @param {string} [options.sourceURL='templateSources[n]']
               *  The sourceURL of the compiled template.
               * @param {string} [options.variable='obj']
               *  The data object variable name.
               * @param- {Object} [guard] Enables use as an iteratee for methods like `_.map`.
               * @returns {Function} Returns the compiled template function.
               * @example
               *
               * // Use the "interpolate" delimiter to create a compiled template.
               * var compiled = _.template('hello <%= user %>!');
               * compiled({ 'user': 'fred' });
               * // => 'hello fred!'
               *
               * // Use the HTML "escape" delimiter to escape data property values.
               * var compiled = _.template('<b><%- value %></b>');
               * compiled({ 'value': '<script>' });
               * // => '<b>&lt;script&gt;</b>'
               *
               * // Use the "evaluate" delimiter to execute JavaScript and generate HTML.
               * var compiled = _.template('<% _.forEach(users, function(user) { %><li><%- user %></li><% }); %>');
               * compiled({ 'users': ['fred', 'barney'] });
               * // => '<li>fred</li><li>barney</li>'
               *
               * // Use the internal `print` function in "evaluate" delimiters.
               * var compiled = _.template('<% print("hello " + user); %>!');
               * compiled({ 'user': 'barney' });
               * // => 'hello barney!'
               *
               * // Use the ES template literal delimiter as an "interpolate" delimiter.
               * // Disable support by replacing the "interpolate" delimiter.
               * var compiled = _.template('hello ${ user }!');
               * compiled({ 'user': 'pebbles' });
               * // => 'hello pebbles!'
               *
               * // Use backslashes to treat delimiters as plain text.
               * var compiled = _.template('<%= "\\<%- value %\\>" %>');
               * compiled({ 'value': 'ignored' });
               * // => '<%- value %>'
               *
               * // Use the `imports` option to import `jQuery` as `jq`.
               * var text = '<% jq.each(users, function(user) { %><li><%- user %></li><% }); %>';
               * var compiled = _.template(text, { 'imports': { 'jq': jQuery } });
               * compiled({ 'users': ['fred', 'barney'] });
               * // => '<li>fred</li><li>barney</li>'
               *
               * // Use the `sourceURL` option to specify a custom sourceURL for the template.
               * var compiled = _.template('hello <%= user %>!', { 'sourceURL': '/basic/greeting.jst' });
               * compiled(data);
               * // => Find the source of "greeting.jst" under the Sources tab or Resources panel of the web inspector.
               *
               * // Use the `variable` option to ensure a with-statement isn't used in the compiled template.
               * var compiled = _.template('hi <%= data.user %>!', { 'variable': 'data' });
               * compiled.source;
               * // => function(data) {
               * //   var __t, __p = '';
               * //   __p += 'hi ' + ((__t = ( data.user )) == null ? '' : __t) + '!';
               * //   return __p;
               * // }
               *
               * // Use custom template delimiters.
               * _.templateSettings.interpolate = /{{([\s\S]+?)}}/g;
               * var compiled = _.template('hello {{ user }}!');
               * compiled({ 'user': 'mustache' });
               * // => 'hello mustache!'
               *
               * // Use the `source` property to inline compiled templates for meaningful
               * // line numbers in error messages and stack traces.
               * fs.writeFileSync(path.join(process.cwd(), 'jst.js'), '\
               *   var JST = {\
               *     "main": ' + _.template(mainText).source + '\
               *   };\
               * ');
               */
              function template(string, options, guard) {
                // Based on John Resig's `tmpl` implementation
                // (http://ejohn.org/blog/javascript-micro-templating/)
                // and Laura Doktorova's doT.js (https://github.com/olado/doT).
                var settings =
                  templateSettings.imports._.templateSettings ||
                  templateSettings;

                if (guard && isIterateeCall(string, options, guard)) {
                  options = undefined;
                }
                string = toString(string);
                options = assignInWith(
                  {},
                  options,
                  settings,
                  customDefaultsAssignIn
                );

                var imports = assignInWith(
                    {},
                    options.imports,
                    settings.imports,
                    customDefaultsAssignIn
                  ),
                  importsKeys = keys(imports),
                  importsValues = baseValues(imports, importsKeys);

                var isEscaping,
                  isEvaluating,
                  index = 0,
                  interpolate = options.interpolate || reNoMatch,
                  source = "__p += '";

                // Compile the regexp to match each delimiter.
                var reDelimiters = RegExp(
                  (options.escape || reNoMatch).source +
                    "|" +
                    interpolate.source +
                    "|" +
                    (interpolate === reInterpolate ? reEsTemplate : reNoMatch)
                      .source +
                    "|" +
                    (options.evaluate || reNoMatch).source +
                    "|$",
                  "g"
                );

                // Use a sourceURL for easier debugging.
                // The sourceURL gets injected into the source that's eval-ed, so be careful
                // with lookup (in case of e.g. prototype pollution), and strip newlines if any.
                // A newline wouldn't be a valid sourceURL anyway, and it'd enable code injection.
                var sourceURL = hasOwnProperty.call(options, "sourceURL")
                  ? "//# sourceURL=" +
                    (options.sourceURL + "").replace(/[\r\n]/g, " ") +
                    "\n"
                  : "";

                string.replace(
                  reDelimiters,
                  function (
                    match,
                    escapeValue,
                    interpolateValue,
                    esTemplateValue,
                    evaluateValue,
                    offset
                  ) {
                    interpolateValue || (interpolateValue = esTemplateValue);

                    // Escape characters that can't be included in string literals.
                    source += string
                      .slice(index, offset)
                      .replace(reUnescapedString, escapeStringChar);

                    // Replace delimiters with snippets.
                    if (escapeValue) {
                      isEscaping = true;
                      source += "' +\n__e(" + escapeValue + ") +\n'";
                    }
                    if (evaluateValue) {
                      isEvaluating = true;
                      source += "';\n" + evaluateValue + ";\n__p += '";
                    }
                    if (interpolateValue) {
                      source +=
                        "' +\n((__t = (" +
                        interpolateValue +
                        ")) == null ? '' : __t) +\n'";
                    }
                    index = offset + match.length;

                    // The JS engine embedded in Adobe products needs `match` returned in
                    // order to produce the correct `offset` value.
                    return match;
                  }
                );

                source += "';\n";

                // If `variable` is not specified wrap a with-statement around the generated
                // code to add the data object to the top of the scope chain.
                // Like with sourceURL, we take care to not check the option's prototype,
                // as this configuration is a code injection vector.
                var variable =
                  hasOwnProperty.call(options, "variable") && options.variable;
                if (!variable) {
                  source = "with (obj) {\n" + source + "\n}\n";
                }
                // Cleanup code by stripping empty strings.
                source = (
                  isEvaluating
                    ? source.replace(reEmptyStringLeading, "")
                    : source
                )
                  .replace(reEmptyStringMiddle, "$1")
                  .replace(reEmptyStringTrailing, "$1;");

                // Frame code as the function body.
                source =
                  "function(" +
                  (variable || "obj") +
                  ") {\n" +
                  (variable ? "" : "obj || (obj = {});\n") +
                  "var __t, __p = ''" +
                  (isEscaping ? ", __e = _.escape" : "") +
                  (isEvaluating
                    ? ", __j = Array.prototype.join;\n" +
                      "function print() { __p += __j.call(arguments, '') }\n"
                    : ";\n") +
                  source +
                  "return __p\n}";

                var result = attempt(function () {
                  return Function(
                    importsKeys,
                    sourceURL + "return " + source
                  ).apply(undefined, importsValues);
                });

                // Provide the compiled function's source by its `toString` method or
                // the `source` property as a convenience for inlining compiled templates.
                result.source = source;
                if (isError(result)) {
                  throw result;
                }
                return result;
              }

              /**
               * Attempts to invoke `func`, returning either the result or the caught error
               * object. Any additional arguments are provided to `func` when it's invoked.
               *
               * @static
               * @memberOf _
               * @since 3.0.0
               * @category Util
               * @param {Function} func The function to attempt.
               * @param {...*} [args] The arguments to invoke `func` with.
               * @returns {*} Returns the `func` result or error object.
               * @example
               *
               * // Avoid throwing errors for invalid selectors.
               * var elements = _.attempt(function(selector) {
               *   return document.querySelectorAll(selector);
               * }, '>_>');
               *
               * if (_.isError(elements)) {
               *   elements = [];
               * }
               */
              var attempt = baseRest(function (func, args) {
                try {
                  return apply(func, undefined, args);
                } catch (e) {
                  return isError(e) ? e : new Error(e);
                }
              });

              /**
               * Creates a function that returns `value`.
               *
               * @static
               * @memberOf _
               * @since 2.4.0
               * @category Util
               * @param {*} value The value to return from the new function.
               * @returns {Function} Returns the new constant function.
               * @example
               *
               * var objects = _.times(2, _.constant({ 'a': 1 }));
               *
               * console.log(objects);
               * // => [{ 'a': 1 }, { 'a': 1 }]
               *
               * console.log(objects[0] === objects[1]);
               * // => true
               */
              function constant(value) {
                return function () {
                  return value;
                };
              }

              /**
               * This method returns the first argument it receives.
               *
               * @static
               * @since 0.1.0
               * @memberOf _
               * @category Util
               * @param {*} value Any value.
               * @returns {*} Returns `value`.
               * @example
               *
               * var object = { 'a': 1 };
               *
               * console.log(_.identity(object) === object);
               * // => true
               */
              function identity(value) {
                return value;
              }

              /**
               * This method returns `false`.
               *
               * @static
               * @memberOf _
               * @since 4.13.0
               * @category Util
               * @returns {boolean} Returns `false`.
               * @example
               *
               * _.times(2, _.stubFalse);
               * // => [false, false]
               */
              function stubFalse() {
                return false;
              }

              module.exports = template;
            }.call(this));
          }.call(
            this,
            typeof global !== "undefined"
              ? global
              : typeof self !== "undefined"
              ? self
              : typeof window !== "undefined"
              ? window
              : {}
          ));
        },
        { "lodash._reinterpolate": 11, "lodash.templatesettings": 15 },
      ],
      15: [
        function (require, module, exports) {
          (function (global) {
            (function () {
              /**
               * lodash (Custom Build) <https://lodash.com/>
               * Build: `lodash modularize exports="npm" -o ./`
               * Copyright jQuery Foundation and other contributors <https://jquery.org/>
               * Released under MIT license <https://lodash.com/license>
               * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
               * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
               */
              var reInterpolate = require("lodash._reinterpolate");

              /** Used as references for various `Number` constants. */
              var INFINITY = 1 / 0;

              /** `Object#toString` result references. */
              var symbolTag = "[object Symbol]";

              /** Used to match HTML entities and HTML characters. */
              var reUnescapedHtml = /[&<>"'`]/g,
                reHasUnescapedHtml = RegExp(reUnescapedHtml.source);

              /** Used to match template delimiters. */
              var reEscape = /<%-([\s\S]+?)%>/g,
                reEvaluate = /<%([\s\S]+?)%>/g;

              /** Used to map characters to HTML entities. */
              var htmlEscapes = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;",
                "`": "&#96;",
              };

              /** Detect free variable `global` from Node.js. */
              var freeGlobal =
                typeof global == "object" &&
                global &&
                global.Object === Object &&
                global;

              /** Detect free variable `self`. */
              var freeSelf =
                typeof self == "object" &&
                self &&
                self.Object === Object &&
                self;

              /** Used as a reference to the global object. */
              var root = freeGlobal || freeSelf || Function("return this")();

              /**
               * The base implementation of `_.propertyOf` without support for deep paths.
               *
               * @private
               * @param {Object} object The object to query.
               * @returns {Function} Returns the new accessor function.
               */
              function basePropertyOf(object) {
                return function (key) {
                  return object == null ? undefined : object[key];
                };
              }

              /**
               * Used by `_.escape` to convert characters to HTML entities.
               *
               * @private
               * @param {string} chr The matched character to escape.
               * @returns {string} Returns the escaped character.
               */
              var escapeHtmlChar = basePropertyOf(htmlEscapes);

              /** Used for built-in method references. */
              var objectProto = Object.prototype;

              /**
               * Used to resolve the
               * [`toStringTag`](http://ecma-international.org/ecma-262/6.0/#sec-object.prototype.tostring)
               * of values.
               */
              var objectToString = objectProto.toString;

              /** Built-in value references. */
              var Symbol = root.Symbol;

              /** Used to convert symbols to primitives and strings. */
              var symbolProto = Symbol ? Symbol.prototype : undefined,
                symbolToString = symbolProto ? symbolProto.toString : undefined;

              /**
               * By default, the template delimiters used by lodash are like those in
               * embedded Ruby (ERB). Change the following template settings to use
               * alternative delimiters.
               *
               * @static
               * @memberOf _
               * @type {Object}
               */
              var templateSettings = {
                /**
                 * Used to detect `data` property values to be HTML-escaped.
                 *
                 * @memberOf _.templateSettings
                 * @type {RegExp}
                 */
                escape: reEscape,

                /**
                 * Used to detect code to be evaluated.
                 *
                 * @memberOf _.templateSettings
                 * @type {RegExp}
                 */
                evaluate: reEvaluate,

                /**
                 * Used to detect `data` property values to inject.
                 *
                 * @memberOf _.templateSettings
                 * @type {RegExp}
                 */
                interpolate: reInterpolate,

                /**
                 * Used to reference the data object in the template text.
                 *
                 * @memberOf _.templateSettings
                 * @type {string}
                 */
                variable: "",

                /**
                 * Used to import variables into the compiled template.
                 *
                 * @memberOf _.templateSettings
                 * @type {Object}
                 */
                imports: {
                  /**
                   * A reference to the `lodash` function.
                   *
                   * @memberOf _.templateSettings.imports
                   * @type {Function}
                   */
                  _: { escape: escape },
                },
              };

              /**
               * The base implementation of `_.toString` which doesn't convert nullish
               * values to empty strings.
               *
               * @private
               * @param {*} value The value to process.
               * @returns {string} Returns the string.
               */
              function baseToString(value) {
                // Exit early for strings to avoid a performance hit in some environments.
                if (typeof value == "string") {
                  return value;
                }
                if (isSymbol(value)) {
                  return symbolToString ? symbolToString.call(value) : "";
                }
                var result = value + "";
                return result == "0" && 1 / value == -INFINITY ? "-0" : result;
              }

              /**
               * Checks if `value` is object-like. A value is object-like if it's not `null`
               * and has a `typeof` result of "object".
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
               * @example
               *
               * _.isObjectLike({});
               * // => true
               *
               * _.isObjectLike([1, 2, 3]);
               * // => true
               *
               * _.isObjectLike(_.noop);
               * // => false
               *
               * _.isObjectLike(null);
               * // => false
               */
              function isObjectLike(value) {
                return !!value && typeof value == "object";
              }

              /**
               * Checks if `value` is classified as a `Symbol` primitive or object.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to check.
               * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
               * @example
               *
               * _.isSymbol(Symbol.iterator);
               * // => true
               *
               * _.isSymbol('abc');
               * // => false
               */
              function isSymbol(value) {
                return (
                  typeof value == "symbol" ||
                  (isObjectLike(value) &&
                    objectToString.call(value) == symbolTag)
                );
              }

              /**
               * Converts `value` to a string. An empty string is returned for `null`
               * and `undefined` values. The sign of `-0` is preserved.
               *
               * @static
               * @memberOf _
               * @since 4.0.0
               * @category Lang
               * @param {*} value The value to process.
               * @returns {string} Returns the string.
               * @example
               *
               * _.toString(null);
               * // => ''
               *
               * _.toString(-0);
               * // => '-0'
               *
               * _.toString([1, 2, 3]);
               * // => '1,2,3'
               */
              function toString(value) {
                return value == null ? "" : baseToString(value);
              }

              /**
               * Converts the characters "&", "<", ">", '"', "'", and "\`" in `string` to
               * their corresponding HTML entities.
               *
               * **Note:** No other characters are escaped. To escape additional
               * characters use a third-party library like [_he_](https://mths.be/he).
               *
               * Though the ">" character is escaped for symmetry, characters like
               * ">" and "/" don't need escaping in HTML and have no special meaning
               * unless they're part of a tag or unquoted attribute value. See
               * [Mathias Bynens's article](https://mathiasbynens.be/notes/ambiguous-ampersands)
               * (under "semi-related fun fact") for more details.
               *
               * Backticks are escaped because in IE < 9, they can break out of
               * attribute values or HTML comments. See [#59](https://html5sec.org/#59),
               * [#102](https://html5sec.org/#102), [#108](https://html5sec.org/#108), and
               * [#133](https://html5sec.org/#133) of the
               * [HTML5 Security Cheatsheet](https://html5sec.org/) for more details.
               *
               * When working with HTML you should always
               * [quote attribute values](http://wonko.com/post/html-escaping) to reduce
               * XSS vectors.
               *
               * @static
               * @since 0.1.0
               * @memberOf _
               * @category String
               * @param {string} [string=''] The string to escape.
               * @returns {string} Returns the escaped string.
               * @example
               *
               * _.escape('fred, barney, & pebbles');
               * // => 'fred, barney, &amp; pebbles'
               */
              function escape(string) {
                string = toString(string);
                return string && reHasUnescapedHtml.test(string)
                  ? string.replace(reUnescapedHtml, escapeHtmlChar)
                  : string;
              }

              module.exports = templateSettings;
            }.call(this));
          }.call(
            this,
            typeof global !== "undefined"
              ? global
              : typeof self !== "undefined"
              ? self
              : typeof window !== "undefined"
              ? window
              : {}
          ));
        },
        { "lodash._reinterpolate": 11 },
      ],
      16: [
        function (require, module, exports) {
          // shim for using process in browser
          var process = (module.exports = {});

          // cached from whatever global is present so that test runners that stub it
          // don't break things.  But we need to wrap it in a try catch in case it is
          // wrapped in strict mode code which doesn't define any globals.  It's inside a
          // function because try/catches deoptimize in certain engines.

          var cachedSetTimeout;
          var cachedClearTimeout;

          function defaultSetTimout() {
            throw new Error("setTimeout has not been defined");
          }
          function defaultClearTimeout() {
            throw new Error("clearTimeout has not been defined");
          }
          (function () {
            try {
              if (typeof setTimeout === "function") {
                cachedSetTimeout = setTimeout;
              } else {
                cachedSetTimeout = defaultSetTimout;
              }
            } catch (e) {
              cachedSetTimeout = defaultSetTimout;
            }
            try {
              if (typeof clearTimeout === "function") {
                cachedClearTimeout = clearTimeout;
              } else {
                cachedClearTimeout = defaultClearTimeout;
              }
            } catch (e) {
              cachedClearTimeout = defaultClearTimeout;
            }
          })();
          function runTimeout(fun) {
            if (cachedSetTimeout === setTimeout) {
              //normal enviroments in sane situations
              return setTimeout(fun, 0);
            }
            // if setTimeout wasn't available but was latter defined
            if (
              (cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) &&
              setTimeout
            ) {
              cachedSetTimeout = setTimeout;
              return setTimeout(fun, 0);
            }
            try {
              // when when somebody has screwed with setTimeout but no I.E. maddness
              return cachedSetTimeout(fun, 0);
            } catch (e) {
              try {
                // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
                return cachedSetTimeout.call(null, fun, 0);
              } catch (e) {
                // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
                return cachedSetTimeout.call(this, fun, 0);
              }
            }
          }
          function runClearTimeout(marker) {
            if (cachedClearTimeout === clearTimeout) {
              //normal enviroments in sane situations
              return clearTimeout(marker);
            }
            // if clearTimeout wasn't available but was latter defined
            if (
              (cachedClearTimeout === defaultClearTimeout ||
                !cachedClearTimeout) &&
              clearTimeout
            ) {
              cachedClearTimeout = clearTimeout;
              return clearTimeout(marker);
            }
            try {
              // when when somebody has screwed with setTimeout but no I.E. maddness
              return cachedClearTimeout(marker);
            } catch (e) {
              try {
                // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
                return cachedClearTimeout.call(null, marker);
              } catch (e) {
                // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
                // Some versions of I.E. have different rules for clearTimeout vs setTimeout
                return cachedClearTimeout.call(this, marker);
              }
            }
          }
          var queue = [];
          var draining = false;
          var currentQueue;
          var queueIndex = -1;

          function cleanUpNextTick() {
            if (!draining || !currentQueue) {
              return;
            }
            draining = false;
            if (currentQueue.length) {
              queue = currentQueue.concat(queue);
            } else {
              queueIndex = -1;
            }
            if (queue.length) {
              drainQueue();
            }
          }

          function drainQueue() {
            if (draining) {
              return;
            }
            var timeout = runTimeout(cleanUpNextTick);
            draining = true;

            var len = queue.length;
            while (len) {
              currentQueue = queue;
              queue = [];
              while (++queueIndex < len) {
                if (currentQueue) {
                  currentQueue[queueIndex].run();
                }
              }
              queueIndex = -1;
              len = queue.length;
            }
            currentQueue = null;
            draining = false;
            runClearTimeout(timeout);
          }

          process.nextTick = function (fun) {
            var args = new Array(arguments.length - 1);
            if (arguments.length > 1) {
              for (var i = 1; i < arguments.length; i++) {
                args[i - 1] = arguments[i];
              }
            }
            queue.push(new Item(fun, args));
            if (queue.length === 1 && !draining) {
              runTimeout(drainQueue);
            }
          };

          // v8 likes predictible objects
          function Item(fun, array) {
            this.fun = fun;
            this.array = array;
          }
          Item.prototype.run = function () {
            this.fun.apply(null, this.array);
          };
          process.title = "browser";
          process.browser = true;
          process.env = {};
          process.argv = [];
          process.version = ""; // empty string to avoid regexp issues
          process.versions = {};

          function noop() {}

          process.on = noop;
          process.addListener = noop;
          process.once = noop;
          process.off = noop;
          process.removeListener = noop;
          process.removeAllListeners = noop;
          process.emit = noop;
          process.prependListener = noop;
          process.prependOnceListener = noop;

          process.listeners = function (name) {
            return [];
          };

          process.binding = function (name) {
            throw new Error("process.binding is not supported");
          };

          process.cwd = function () {
            return "/";
          };
          process.chdir = function (dir) {
            throw new Error("process.chdir is not supported");
          };
          process.umask = function () {
            return 0;
          };
        },
        {},
      ],
      17: [
        function (require, module, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports.default = void 0;

          /** A function that accepts a potential "extra argument" value to be injected later,
           * and returns an instance of the thunk middleware that uses that value
           */
          function createThunkMiddleware(extraArgument) {
            // Standard Redux middleware definition pattern:
            // See: https://redux.js.org/tutorials/fundamentals/part-4-store#writing-custom-middleware
            var middleware = function middleware(_ref) {
              var dispatch = _ref.dispatch,
                getState = _ref.getState;
              return function (next) {
                return function (action) {
                  // The thunk middleware looks for any functions that were passed to `store.dispatch`.
                  // If this "action" is really a function, call it and return the result.
                  if (typeof action === "function") {
                    // Inject the store's `dispatch` and `getState` methods, as well as any "extra arg"
                    return action(dispatch, getState, extraArgument);
                  } // Otherwise, pass the action down the middleware chain as usual

                  return next(action);
                };
              };
            };

            return middleware;
          }

          var thunk = createThunkMiddleware(); // Attach the factory function so users can create a customized version
          // with whatever "extra arg" they want to inject into their thunks

          thunk.withExtraArgument = createThunkMiddleware;
          var _default = thunk;
          exports.default = _default;
        },
        {},
      ],
      18: [
        function (require, module, exports) {
          (function (process) {
            (function () {
              "use strict";

              Object.defineProperty(exports, "__esModule", { value: true });

              var _objectSpread = require("@babel/runtime/helpers/objectSpread2");

              function _interopDefaultLegacy(e) {
                return e && typeof e === "object" && "default" in e
                  ? e
                  : { default: e };
              }

              var _objectSpread__default =
                /*#__PURE__*/ _interopDefaultLegacy(_objectSpread);

              /**
               * Adapted from React: https://github.com/facebook/react/blob/master/packages/shared/formatProdErrorMessage.js
               *
               * Do not require this module directly! Use normal throw error calls. These messages will be replaced with error codes
               * during build.
               * @param {number} code
               */
              function formatProdErrorMessage(code) {
                return (
                  "Minified Redux error #" +
                  code +
                  "; visit https://redux.js.org/Errors?code=" +
                  code +
                  " for the full message or " +
                  "use the non-minified dev environment for full errors. "
                );
              }

              // Inlined version of the `symbol-observable` polyfill
              var $$observable = (function () {
                return (
                  (typeof Symbol === "function" && Symbol.observable) ||
                  "@@observable"
                );
              })();

              /**
               * These are private action types reserved by Redux.
               * For any unknown actions, you must return the current state.
               * If the current state is undefined, you must return the initial state.
               * Do not reference these action types directly in your code.
               */
              var randomString = function randomString() {
                return Math.random()
                  .toString(36)
                  .substring(7)
                  .split("")
                  .join(".");
              };

              var ActionTypes = {
                INIT: "@@redux/INIT" + randomString(),
                REPLACE: "@@redux/REPLACE" + randomString(),
                PROBE_UNKNOWN_ACTION: function PROBE_UNKNOWN_ACTION() {
                  return "@@redux/PROBE_UNKNOWN_ACTION" + randomString();
                },
              };

              /**
               * @param {any} obj The object to inspect.
               * @returns {boolean} True if the argument appears to be a plain object.
               */
              function isPlainObject(obj) {
                if (typeof obj !== "object" || obj === null) return false;
                var proto = obj;

                while (Object.getPrototypeOf(proto) !== null) {
                  proto = Object.getPrototypeOf(proto);
                }

                return Object.getPrototypeOf(obj) === proto;
              }

              // Inlined / shortened version of `kindOf` from https://github.com/jonschlinkert/kind-of
              function miniKindOf(val) {
                if (val === void 0) return "undefined";
                if (val === null) return "null";
                var type = typeof val;

                switch (type) {
                  case "boolean":
                  case "string":
                  case "number":
                  case "symbol":
                  case "function": {
                    return type;
                  }
                }

                if (Array.isArray(val)) return "array";
                if (isDate(val)) return "date";
                if (isError(val)) return "error";
                var constructorName = ctorName(val);

                switch (constructorName) {
                  case "Symbol":
                  case "Promise":
                  case "WeakMap":
                  case "WeakSet":
                  case "Map":
                  case "Set":
                    return constructorName;
                } // other

                return type.slice(8, -1).toLowerCase().replace(/\s/g, "");
              }

              function ctorName(val) {
                return typeof val.constructor === "function"
                  ? val.constructor.name
                  : null;
              }

              function isError(val) {
                return (
                  val instanceof Error ||
                  (typeof val.message === "string" &&
                    val.constructor &&
                    typeof val.constructor.stackTraceLimit === "number")
                );
              }

              function isDate(val) {
                if (val instanceof Date) return true;
                return (
                  typeof val.toDateString === "function" &&
                  typeof val.getDate === "function" &&
                  typeof val.setDate === "function"
                );
              }

              function kindOf(val) {
                var typeOfVal = typeof val;

                if (process.env.NODE_ENV !== "production") {
                  typeOfVal = miniKindOf(val);
                }

                return typeOfVal;
              }

              /**
               * @deprecated
               *
               * **We recommend using the `configureStore` method
               * of the `@reduxjs/toolkit` package**, which replaces `createStore`.
               *
               * Redux Toolkit is our recommended approach for writing Redux logic today,
               * including store setup, reducers, data fetching, and more.
               *
               * **For more details, please read this Redux docs page:**
               * **https://redux.js.org/introduction/why-rtk-is-redux-today**
               *
               * `configureStore` from Redux Toolkit is an improved version of `createStore` that
               * simplifies setup and helps avoid common bugs.
               *
               * You should not be using the `redux` core package by itself today, except for learning purposes.
               * The `createStore` method from the core `redux` package will not be removed, but we encourage
               * all users to migrate to using Redux Toolkit for all Redux code.
               *
               * If you want to use `createStore` without this visual deprecation warning, use
               * the `legacy_createStore` import instead:
               *
               * `import { legacy_createStore as createStore} from 'redux'`
               *
               */

              function createStore(reducer, preloadedState, enhancer) {
                var _ref2;

                if (
                  (typeof preloadedState === "function" &&
                    typeof enhancer === "function") ||
                  (typeof enhancer === "function" &&
                    typeof arguments[3] === "function")
                ) {
                  throw new Error(
                    process.env.NODE_ENV === "production"
                      ? formatProdErrorMessage(0)
                      : "It looks like you are passing several store enhancers to " +
                        "createStore(). This is not supported. Instead, compose them " +
                        "together to a single function. See https://redux.js.org/tutorials/fundamentals/part-4-store#creating-a-store-with-enhancers for an example."
                  );
                }

                if (
                  typeof preloadedState === "function" &&
                  typeof enhancer === "undefined"
                ) {
                  enhancer = preloadedState;
                  preloadedState = undefined;
                }

                if (typeof enhancer !== "undefined") {
                  if (typeof enhancer !== "function") {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(1)
                        : "Expected the enhancer to be a function. Instead, received: '" +
                          kindOf(enhancer) +
                          "'"
                    );
                  }

                  return enhancer(createStore)(reducer, preloadedState);
                }

                if (typeof reducer !== "function") {
                  throw new Error(
                    process.env.NODE_ENV === "production"
                      ? formatProdErrorMessage(2)
                      : "Expected the root reducer to be a function. Instead, received: '" +
                        kindOf(reducer) +
                        "'"
                  );
                }

                var currentReducer = reducer;
                var currentState = preloadedState;
                var currentListeners = [];
                var nextListeners = currentListeners;
                var isDispatching = false;
                /**
                 * This makes a shallow copy of currentListeners so we can use
                 * nextListeners as a temporary list while dispatching.
                 *
                 * This prevents any bugs around consumers calling
                 * subscribe/unsubscribe in the middle of a dispatch.
                 */

                function ensureCanMutateNextListeners() {
                  if (nextListeners === currentListeners) {
                    nextListeners = currentListeners.slice();
                  }
                }
                /**
                 * Reads the state tree managed by the store.
                 *
                 * @returns {any} The current state tree of your application.
                 */

                function getState() {
                  if (isDispatching) {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(3)
                        : "You may not call store.getState() while the reducer is executing. " +
                          "The reducer has already received the state as an argument. " +
                          "Pass it down from the top reducer instead of reading it from the store."
                    );
                  }

                  return currentState;
                }
                /**
                 * Adds a change listener. It will be called any time an action is dispatched,
                 * and some part of the state tree may potentially have changed. You may then
                 * call `getState()` to read the current state tree inside the callback.
                 *
                 * You may call `dispatch()` from a change listener, with the following
                 * caveats:
                 *
                 * 1. The subscriptions are snapshotted just before every `dispatch()` call.
                 * If you subscribe or unsubscribe while the listeners are being invoked, this
                 * will not have any effect on the `dispatch()` that is currently in progress.
                 * However, the next `dispatch()` call, whether nested or not, will use a more
                 * recent snapshot of the subscription list.
                 *
                 * 2. The listener should not expect to see all state changes, as the state
                 * might have been updated multiple times during a nested `dispatch()` before
                 * the listener is called. It is, however, guaranteed that all subscribers
                 * registered before the `dispatch()` started will be called with the latest
                 * state by the time it exits.
                 *
                 * @param {Function} listener A callback to be invoked on every dispatch.
                 * @returns {Function} A function to remove this change listener.
                 */

                function subscribe(listener) {
                  if (typeof listener !== "function") {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(4)
                        : "Expected the listener to be a function. Instead, received: '" +
                          kindOf(listener) +
                          "'"
                    );
                  }

                  if (isDispatching) {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(5)
                        : "You may not call store.subscribe() while the reducer is executing. " +
                          "If you would like to be notified after the store has been updated, subscribe from a " +
                          "component and invoke store.getState() in the callback to access the latest state. " +
                          "See https://redux.js.org/api/store#subscribelistener for more details."
                    );
                  }

                  var isSubscribed = true;
                  ensureCanMutateNextListeners();
                  nextListeners.push(listener);
                  return function unsubscribe() {
                    if (!isSubscribed) {
                      return;
                    }

                    if (isDispatching) {
                      throw new Error(
                        process.env.NODE_ENV === "production"
                          ? formatProdErrorMessage(6)
                          : "You may not unsubscribe from a store listener while the reducer is executing. " +
                            "See https://redux.js.org/api/store#subscribelistener for more details."
                      );
                    }

                    isSubscribed = false;
                    ensureCanMutateNextListeners();
                    var index = nextListeners.indexOf(listener);
                    nextListeners.splice(index, 1);
                    currentListeners = null;
                  };
                }
                /**
                 * Dispatches an action. It is the only way to trigger a state change.
                 *
                 * The `reducer` function, used to create the store, will be called with the
                 * current state tree and the given `action`. Its return value will
                 * be considered the **next** state of the tree, and the change listeners
                 * will be notified.
                 *
                 * The base implementation only supports plain object actions. If you want to
                 * dispatch a Promise, an Observable, a thunk, or something else, you need to
                 * wrap your store creating function into the corresponding middleware. For
                 * example, see the documentation for the `redux-thunk` package. Even the
                 * middleware will eventually dispatch plain object actions using this method.
                 *
                 * @param {Object} action A plain object representing “what changed”. It is
                 * a good idea to keep actions serializable so you can record and replay user
                 * sessions, or use the time travelling `redux-devtools`. An action must have
                 * a `type` property which may not be `undefined`. It is a good idea to use
                 * string constants for action types.
                 *
                 * @returns {Object} For convenience, the same action object you dispatched.
                 *
                 * Note that, if you use a custom middleware, it may wrap `dispatch()` to
                 * return something else (for example, a Promise you can await).
                 */

                function dispatch(action) {
                  if (!isPlainObject(action)) {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(7)
                        : "Actions must be plain objects. Instead, the actual type was: '" +
                          kindOf(action) +
                          "'. You may need to add middleware to your store setup to handle dispatching other values, such as 'redux-thunk' to handle dispatching functions. See https://redux.js.org/tutorials/fundamentals/part-4-store#middleware and https://redux.js.org/tutorials/fundamentals/part-6-async-logic#using-the-redux-thunk-middleware for examples."
                    );
                  }

                  if (typeof action.type === "undefined") {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(8)
                        : 'Actions may not have an undefined "type" property. You may have misspelled an action type string constant.'
                    );
                  }

                  if (isDispatching) {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(9)
                        : "Reducers may not dispatch actions."
                    );
                  }

                  try {
                    isDispatching = true;
                    currentState = currentReducer(currentState, action);
                  } finally {
                    isDispatching = false;
                  }

                  var listeners = (currentListeners = nextListeners);

                  for (var i = 0; i < listeners.length; i++) {
                    var listener = listeners[i];
                    listener();
                  }

                  return action;
                }
                /**
                 * Replaces the reducer currently used by the store to calculate the state.
                 *
                 * You might need this if your app implements code splitting and you want to
                 * load some of the reducers dynamically. You might also need this if you
                 * implement a hot reloading mechanism for Redux.
                 *
                 * @param {Function} nextReducer The reducer for the store to use instead.
                 * @returns {void}
                 */

                function replaceReducer(nextReducer) {
                  if (typeof nextReducer !== "function") {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(10)
                        : "Expected the nextReducer to be a function. Instead, received: '" +
                          kindOf(nextReducer)
                    );
                  }

                  currentReducer = nextReducer; // This action has a similiar effect to ActionTypes.INIT.
                  // Any reducers that existed in both the new and old rootReducer
                  // will receive the previous state. This effectively populates
                  // the new state tree with any relevant data from the old one.

                  dispatch({
                    type: ActionTypes.REPLACE,
                  });
                }
                /**
                 * Interoperability point for observable/reactive libraries.
                 * @returns {observable} A minimal observable of state changes.
                 * For more information, see the observable proposal:
                 * https://github.com/tc39/proposal-observable
                 */

                function observable() {
                  var _ref;

                  var outerSubscribe = subscribe;
                  return (
                    (_ref = {
                      /**
                       * The minimal observable subscription method.
                       * @param {Object} observer Any object that can be used as an observer.
                       * The observer object should have a `next` method.
                       * @returns {subscription} An object with an `unsubscribe` method that can
                       * be used to unsubscribe the observable from the store, and prevent further
                       * emission of values from the observable.
                       */
                      subscribe: function subscribe(observer) {
                        if (typeof observer !== "object" || observer === null) {
                          throw new Error(
                            process.env.NODE_ENV === "production"
                              ? formatProdErrorMessage(11)
                              : "Expected the observer to be an object. Instead, received: '" +
                                kindOf(observer) +
                                "'"
                          );
                        }

                        function observeState() {
                          if (observer.next) {
                            observer.next(getState());
                          }
                        }

                        observeState();
                        var unsubscribe = outerSubscribe(observeState);
                        return {
                          unsubscribe: unsubscribe,
                        };
                      },
                    }),
                    (_ref[$$observable] = function () {
                      return this;
                    }),
                    _ref
                  );
                } // When a store is created, an "INIT" action is dispatched so that every
                // reducer returns their initial state. This effectively populates
                // the initial state tree.

                dispatch({
                  type: ActionTypes.INIT,
                });
                return (
                  (_ref2 = {
                    dispatch: dispatch,
                    subscribe: subscribe,
                    getState: getState,
                    replaceReducer: replaceReducer,
                  }),
                  (_ref2[$$observable] = observable),
                  _ref2
                );
              }
              /**
               * Creates a Redux store that holds the state tree.
               *
               * **We recommend using `configureStore` from the
               * `@reduxjs/toolkit` package**, which replaces `createStore`:
               * **https://redux.js.org/introduction/why-rtk-is-redux-today**
               *
               * The only way to change the data in the store is to call `dispatch()` on it.
               *
               * There should only be a single store in your app. To specify how different
               * parts of the state tree respond to actions, you may combine several reducers
               * into a single reducer function by using `combineReducers`.
               *
               * @param {Function} reducer A function that returns the next state tree, given
               * the current state tree and the action to handle.
               *
               * @param {any} [preloadedState] The initial state. You may optionally specify it
               * to hydrate the state from the server in universal apps, or to restore a
               * previously serialized user session.
               * If you use `combineReducers` to produce the root reducer function, this must be
               * an object with the same shape as `combineReducers` keys.
               *
               * @param {Function} [enhancer] The store enhancer. You may optionally specify it
               * to enhance the store with third-party capabilities such as middleware,
               * time travel, persistence, etc. The only store enhancer that ships with Redux
               * is `applyMiddleware()`.
               *
               * @returns {Store} A Redux store that lets you read the state, dispatch actions
               * and subscribe to changes.
               */

              var legacy_createStore = createStore;

              /**
               * Prints a warning in the console if it exists.
               *
               * @param {String} message The warning message.
               * @returns {void}
               */
              function warning(message) {
                /* eslint-disable no-console */
                if (
                  typeof console !== "undefined" &&
                  typeof console.error === "function"
                ) {
                  console.error(message);
                }
                /* eslint-enable no-console */

                try {
                  // This error was thrown as a convenience so that if you enable
                  // "break on all exceptions" in your console,
                  // it would pause the execution at this line.
                  throw new Error(message);
                } catch (e) {} // eslint-disable-line no-empty
              }

              function getUnexpectedStateShapeWarningMessage(
                inputState,
                reducers,
                action,
                unexpectedKeyCache
              ) {
                var reducerKeys = Object.keys(reducers);
                var argumentName =
                  action && action.type === ActionTypes.INIT
                    ? "preloadedState argument passed to createStore"
                    : "previous state received by the reducer";

                if (reducerKeys.length === 0) {
                  return (
                    "Store does not have a valid reducer. Make sure the argument passed " +
                    "to combineReducers is an object whose values are reducers."
                  );
                }

                if (!isPlainObject(inputState)) {
                  return (
                    "The " +
                    argumentName +
                    ' has unexpected type of "' +
                    kindOf(inputState) +
                    '". Expected argument to be an object with the following ' +
                    ('keys: "' + reducerKeys.join('", "') + '"')
                  );
                }

                var unexpectedKeys = Object.keys(inputState).filter(function (
                  key
                ) {
                  return (
                    !reducers.hasOwnProperty(key) && !unexpectedKeyCache[key]
                  );
                });
                unexpectedKeys.forEach(function (key) {
                  unexpectedKeyCache[key] = true;
                });
                if (action && action.type === ActionTypes.REPLACE) return;

                if (unexpectedKeys.length > 0) {
                  return (
                    "Unexpected " +
                    (unexpectedKeys.length > 1 ? "keys" : "key") +
                    " " +
                    ('"' +
                      unexpectedKeys.join('", "') +
                      '" found in ' +
                      argumentName +
                      ". ") +
                    "Expected to find one of the known reducer keys instead: " +
                    ('"' +
                      reducerKeys.join('", "') +
                      '". Unexpected keys will be ignored.')
                  );
                }
              }

              function assertReducerShape(reducers) {
                Object.keys(reducers).forEach(function (key) {
                  var reducer = reducers[key];
                  var initialState = reducer(undefined, {
                    type: ActionTypes.INIT,
                  });

                  if (typeof initialState === "undefined") {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(12)
                        : 'The slice reducer for key "' +
                          key +
                          '" returned undefined during initialization. ' +
                          "If the state passed to the reducer is undefined, you must " +
                          "explicitly return the initial state. The initial state may " +
                          "not be undefined. If you don't want to set a value for this reducer, " +
                          "you can use null instead of undefined."
                    );
                  }

                  if (
                    typeof reducer(undefined, {
                      type: ActionTypes.PROBE_UNKNOWN_ACTION(),
                    }) === "undefined"
                  ) {
                    throw new Error(
                      process.env.NODE_ENV === "production"
                        ? formatProdErrorMessage(13)
                        : 'The slice reducer for key "' +
                          key +
                          '" returned undefined when probed with a random type. ' +
                          ("Don't try to handle '" +
                            ActionTypes.INIT +
                            '\' or other actions in "redux/*" ') +
                          "namespace. They are considered private. Instead, you must return the " +
                          "current state for any unknown actions, unless it is undefined, " +
                          "in which case you must return the initial state, regardless of the " +
                          "action type. The initial state may not be undefined, but can be null."
                    );
                  }
                });
              }
              /**
               * Turns an object whose values are different reducer functions, into a single
               * reducer function. It will call every child reducer, and gather their results
               * into a single state object, whose keys correspond to the keys of the passed
               * reducer functions.
               *
               * @param {Object} reducers An object whose values correspond to different
               * reducer functions that need to be combined into one. One handy way to obtain
               * it is to use ES6 `import * as reducers` syntax. The reducers may never return
               * undefined for any action. Instead, they should return their initial state
               * if the state passed to them was undefined, and the current state for any
               * unrecognized action.
               *
               * @returns {Function} A reducer function that invokes every reducer inside the
               * passed object, and builds a state object with the same shape.
               */

              function combineReducers(reducers) {
                var reducerKeys = Object.keys(reducers);
                var finalReducers = {};

                for (var i = 0; i < reducerKeys.length; i++) {
                  var key = reducerKeys[i];

                  if (process.env.NODE_ENV !== "production") {
                    if (typeof reducers[key] === "undefined") {
                      warning('No reducer provided for key "' + key + '"');
                    }
                  }

                  if (typeof reducers[key] === "function") {
                    finalReducers[key] = reducers[key];
                  }
                }

                var finalReducerKeys = Object.keys(finalReducers); // This is used to make sure we don't warn about the same
                // keys multiple times.

                var unexpectedKeyCache;

                if (process.env.NODE_ENV !== "production") {
                  unexpectedKeyCache = {};
                }

                var shapeAssertionError;

                try {
                  assertReducerShape(finalReducers);
                } catch (e) {
                  shapeAssertionError = e;
                }

                return function combination(state, action) {
                  if (state === void 0) {
                    state = {};
                  }

                  if (shapeAssertionError) {
                    throw shapeAssertionError;
                  }

                  if (process.env.NODE_ENV !== "production") {
                    var warningMessage = getUnexpectedStateShapeWarningMessage(
                      state,
                      finalReducers,
                      action,
                      unexpectedKeyCache
                    );

                    if (warningMessage) {
                      warning(warningMessage);
                    }
                  }

                  var hasChanged = false;
                  var nextState = {};

                  for (var _i = 0; _i < finalReducerKeys.length; _i++) {
                    var _key = finalReducerKeys[_i];
                    var reducer = finalReducers[_key];
                    var previousStateForKey = state[_key];
                    var nextStateForKey = reducer(previousStateForKey, action);

                    if (typeof nextStateForKey === "undefined") {
                      var actionType = action && action.type;
                      throw new Error(
                        process.env.NODE_ENV === "production"
                          ? formatProdErrorMessage(14)
                          : "When called with an action of type " +
                            (actionType
                              ? '"' + String(actionType) + '"'
                              : "(unknown type)") +
                            ', the slice reducer for key "' +
                            _key +
                            '" returned undefined. ' +
                            "To ignore an action, you must explicitly return the previous state. " +
                            "If you want this reducer to hold no value, you can return null instead of undefined."
                      );
                    }

                    nextState[_key] = nextStateForKey;
                    hasChanged =
                      hasChanged || nextStateForKey !== previousStateForKey;
                  }

                  hasChanged =
                    hasChanged ||
                    finalReducerKeys.length !== Object.keys(state).length;
                  return hasChanged ? nextState : state;
                };
              }

              function bindActionCreator(actionCreator, dispatch) {
                return function () {
                  return dispatch(actionCreator.apply(this, arguments));
                };
              }
              /**
               * Turns an object whose values are action creators, into an object with the
               * same keys, but with every function wrapped into a `dispatch` call so they
               * may be invoked directly. This is just a convenience method, as you can call
               * `store.dispatch(MyActionCreators.doSomething())` yourself just fine.
               *
               * For convenience, you can also pass an action creator as the first argument,
               * and get a dispatch wrapped function in return.
               *
               * @param {Function|Object} actionCreators An object whose values are action
               * creator functions. One handy way to obtain it is to use ES6 `import * as`
               * syntax. You may also pass a single function.
               *
               * @param {Function} dispatch The `dispatch` function available on your Redux
               * store.
               *
               * @returns {Function|Object} The object mimicking the original object, but with
               * every action creator wrapped into the `dispatch` call. If you passed a
               * function as `actionCreators`, the return value will also be a single
               * function.
               */

              function bindActionCreators(actionCreators, dispatch) {
                if (typeof actionCreators === "function") {
                  return bindActionCreator(actionCreators, dispatch);
                }

                if (
                  typeof actionCreators !== "object" ||
                  actionCreators === null
                ) {
                  throw new Error(
                    process.env.NODE_ENV === "production"
                      ? formatProdErrorMessage(16)
                      : "bindActionCreators expected an object or a function, but instead received: '" +
                        kindOf(actionCreators) +
                        "'. " +
                        'Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?'
                  );
                }

                var boundActionCreators = {};

                for (var key in actionCreators) {
                  var actionCreator = actionCreators[key];

                  if (typeof actionCreator === "function") {
                    boundActionCreators[key] = bindActionCreator(
                      actionCreator,
                      dispatch
                    );
                  }
                }

                return boundActionCreators;
              }

              /**
               * Composes single-argument functions from right to left. The rightmost
               * function can take multiple arguments as it provides the signature for
               * the resulting composite function.
               *
               * @param {...Function} funcs The functions to compose.
               * @returns {Function} A function obtained by composing the argument functions
               * from right to left. For example, compose(f, g, h) is identical to doing
               * (...args) => f(g(h(...args))).
               */
              function compose() {
                for (
                  var _len = arguments.length,
                    funcs = new Array(_len),
                    _key = 0;
                  _key < _len;
                  _key++
                ) {
                  funcs[_key] = arguments[_key];
                }

                if (funcs.length === 0) {
                  return function (arg) {
                    return arg;
                  };
                }

                if (funcs.length === 1) {
                  return funcs[0];
                }

                return funcs.reduce(function (a, b) {
                  return function () {
                    return a(b.apply(void 0, arguments));
                  };
                });
              }

              /**
               * Creates a store enhancer that applies middleware to the dispatch method
               * of the Redux store. This is handy for a variety of tasks, such as expressing
               * asynchronous actions in a concise manner, or logging every action payload.
               *
               * See `redux-thunk` package as an example of the Redux middleware.
               *
               * Because middleware is potentially asynchronous, this should be the first
               * store enhancer in the composition chain.
               *
               * Note that each middleware will be given the `dispatch` and `getState` functions
               * as named arguments.
               *
               * @param {...Function} middlewares The middleware chain to be applied.
               * @returns {Function} A store enhancer applying the middleware.
               */

              function applyMiddleware() {
                for (
                  var _len = arguments.length,
                    middlewares = new Array(_len),
                    _key = 0;
                  _key < _len;
                  _key++
                ) {
                  middlewares[_key] = arguments[_key];
                }

                return function (createStore) {
                  return function () {
                    var store = createStore.apply(void 0, arguments);

                    var _dispatch = function dispatch() {
                      throw new Error(
                        process.env.NODE_ENV === "production"
                          ? formatProdErrorMessage(15)
                          : "Dispatching while constructing your middleware is not allowed. " +
                            "Other middleware would not be applied to this dispatch."
                      );
                    };

                    var middlewareAPI = {
                      getState: store.getState,
                      dispatch: function dispatch() {
                        return _dispatch.apply(void 0, arguments);
                      },
                    };
                    var chain = middlewares.map(function (middleware) {
                      return middleware(middlewareAPI);
                    });
                    _dispatch = compose.apply(void 0, chain)(store.dispatch);
                    return _objectSpread__default["default"](
                      _objectSpread__default["default"]({}, store),
                      {},
                      {
                        dispatch: _dispatch,
                      }
                    );
                  };
                };
              }

              /*
               * This is a dummy function to check if the function name has been altered by minification.
               * If the function has been minified and NODE_ENV !== 'production', warn the user.
               */

              function isCrushed() {}

              if (
                process.env.NODE_ENV !== "production" &&
                typeof isCrushed.name === "string" &&
                isCrushed.name !== "isCrushed"
              ) {
                warning(
                  'You are currently using minified code outside of NODE_ENV === "production". ' +
                    "This means that you are running a slower development build of Redux. " +
                    "You can use loose-envify (https://github.com/zertosh/loose-envify) for browserify " +
                    "or setting mode to production in webpack (https://webpack.js.org/concepts/mode/) " +
                    "to ensure you have the correct code for your production build."
                );
              }

              exports.__DO_NOT_USE__ActionTypes = ActionTypes;
              exports.applyMiddleware = applyMiddleware;
              exports.bindActionCreators = bindActionCreators;
              exports.combineReducers = combineReducers;
              exports.compose = compose;
              exports.createStore = createStore;
              exports.legacy_createStore = legacy_createStore;
            }.call(this));
          }.call(this, require("_process")));
        },
        { "@babel/runtime/helpers/objectSpread2": 2, _process: 16 },
      ],
      19: [
        function (require, module, exports) {
          "use strict";

          /**
           * A typeahead component for inputs
           * @class Suggestions
           *
           * @param {HTMLInputElement} el A valid HTML input element
           * @param {Array} data An array of data used for results
           * @param {Object} options
           * @param {Number} [options.limit=5] Max number of results to display in the auto suggest list.
           * @param {Number} [options.minLength=2] Number of characters typed into an input to trigger suggestions.
           * @param {Boolean} [options.hideOnBlur=true] If `true`, hides the suggestions when focus is lost.
           * @return {Suggestions} `this`
           * @example
           * // in the browser
           * var input = document.querySelector('input');
           * var data = [
           *   'Roy Eldridge',
           *   'Roy Hargrove',
           *   'Rex Stewart'
           * ];
           *
           * new Suggestions(input, data);
           *
           * // with options
           * var input = document.querySelector('input');
           * var data = [{
           *   name: 'Roy Eldridge',
           *   year: 1911
           * }, {
           *   name: 'Roy Hargrove',
           *   year: 1969
           * }, {
           *   name: 'Rex Stewart',
           *   year: 1907
           * }];
           *
           * var typeahead = new Suggestions(input, data, {
           *   filter: false, // Disable filtering
           *   minLength: 3, // Number of characters typed into an input to trigger suggestions.
           *   limit: 3, //  Max number of results to display.
           *   hideOnBlur: false // Don't hide results when input loses focus
           * });
           *
           * // As we're passing an object of an arrays as data, override
           * // `getItemValue` by specifying the specific property to search on.
           * typeahead.getItemValue = function(item) { return item.name };
           *
           * input.addEventListener('change', function() {
           *   console.log(typeahead.selected); // Current selected item.
           * });
           *
           * // With browserify
           * var Suggestions = require('suggestions');
           *
           * new Suggestions(input, data);
           */
          var Suggestions = require("./src/suggestions");
          module.exports = Suggestions;

          if (typeof window !== "undefined") {
            window.Suggestions = Suggestions;
          }
        },
        { "./src/suggestions": 21 },
      ],
      20: [
        function (require, module, exports) {
          "use strict";

          var List = function (component) {
            this.component = component;
            this.items = [];
            this.active = 0;
            this.wrapper = document.createElement("div");
            this.wrapper.className = "suggestions-wrapper";
            this.element = document.createElement("ul");
            this.element.className = "suggestions";
            this.wrapper.appendChild(this.element);

            // selectingListItem is set to true in the time between the mousedown and mouseup when clicking an item in the list
            // mousedown on a list item will cause the input to blur which normally hides the list, so this flag is used to keep
            // the list open until the mouseup
            this.selectingListItem = false;

            component.el.parentNode.insertBefore(
              this.wrapper,
              component.el.nextSibling
            );
            return this;
          };

          List.prototype.show = function () {
            this.element.style.display = "block";
          };

          List.prototype.hide = function () {
            this.element.style.display = "none";
          };

          List.prototype.add = function (item) {
            this.items.push(item);
          };

          List.prototype.clear = function () {
            this.items = [];
            this.active = 0;
          };

          List.prototype.isEmpty = function () {
            return !this.items.length;
          };

          List.prototype.isVisible = function () {
            return this.element.style.display === "block";
          };

          List.prototype.draw = function () {
            this.element.innerHTML = "";

            if (this.items.length === 0) {
              this.hide();
              return;
            }

            for (var i = 0; i < this.items.length; i++) {
              this.drawItem(this.items[i], this.active === i);
            }

            this.show();
          };

          List.prototype.drawItem = function (item, active) {
            var li = document.createElement("li"),
              a = document.createElement("a");

            if (active) li.className += " active";

            a.innerHTML = item.string;

            li.appendChild(a);
            this.element.appendChild(li);

            li.addEventListener(
              "mousedown",
              function () {
                this.selectingListItem = true;
              }.bind(this)
            );

            li.addEventListener(
              "mouseup",
              function () {
                this.handleMouseUp.call(this, item);
              }.bind(this)
            );
          };

          List.prototype.handleMouseUp = function (item) {
            this.selectingListItem = false;
            this.component.value(item.original);
            this.clear();
            this.draw();
          };

          List.prototype.move = function (index) {
            this.active = index;
            this.draw();
          };

          List.prototype.previous = function () {
            this.move(
              this.active === 0 ? this.items.length - 1 : this.active - 1
            );
          };

          List.prototype.next = function () {
            this.move(
              this.active === this.items.length - 1 ? 0 : this.active + 1
            );
          };

          List.prototype.drawError = function (msg) {
            var li = document.createElement("li");

            li.innerHTML = msg;

            this.element.appendChild(li);
            this.show();
          };

          module.exports = List;
        },
        {},
      ],
      21: [
        function (require, module, exports) {
          "use strict";

          var extend = require("xtend");
          var fuzzy = require("fuzzy");
          var List = require("./list");

          var Suggestions = function (el, data, options) {
            options = options || {};

            this.options = extend(
              {
                minLength: 2,
                limit: 5,
                filter: true,
                hideOnBlur: true,
              },
              options
            );

            this.el = el;
            this.data = data || [];
            this.list = new List(this);

            this.query = "";
            this.selected = null;

            this.list.draw();

            this.el.addEventListener(
              "keyup",
              function (e) {
                this.handleKeyUp(e.keyCode);
              }.bind(this),
              false
            );

            this.el.addEventListener(
              "keydown",
              function (e) {
                this.handleKeyDown(e);
              }.bind(this)
            );

            this.el.addEventListener(
              "focus",
              function () {
                this.handleFocus();
              }.bind(this)
            );

            this.el.addEventListener(
              "blur",
              function () {
                this.handleBlur();
              }.bind(this)
            );

            this.el.addEventListener(
              "paste",
              function (e) {
                this.handlePaste(e);
              }.bind(this)
            );

            // use user-provided render function if given, otherwise just use the default
            this.render = this.options.render
              ? this.options.render.bind(this)
              : this.render.bind(this);

            this.getItemValue = this.options.getItemValue
              ? this.options.getItemValue.bind(this)
              : this.getItemValue.bind(this);

            return this;
          };

          Suggestions.prototype.handleKeyUp = function (keyCode) {
            // 40 - DOWN
            // 38 - UP
            // 27 - ESC
            // 13 - ENTER
            // 9 - TAB

            if (
              keyCode === 40 ||
              keyCode === 38 ||
              keyCode === 27 ||
              keyCode === 13 ||
              keyCode === 9
            )
              return;

            this.handleInputChange(this.el.value);
          };

          Suggestions.prototype.handleKeyDown = function (e) {
            switch (e.keyCode) {
              case 13: // ENTER
              case 9: // TAB
                if (!this.list.isEmpty()) {
                  if (this.list.isVisible()) {
                    e.preventDefault();
                  }
                  this.value(this.list.items[this.list.active].original);
                  this.list.hide();
                }
                break;
              case 27: // ESC
                if (!this.list.isEmpty()) this.list.hide();
                break;
              case 38: // UP
                this.list.previous();
                break;
              case 40: // DOWN
                this.list.next();
                break;
            }
          };

          Suggestions.prototype.handleBlur = function () {
            if (!this.list.selectingListItem && this.options.hideOnBlur) {
              this.list.hide();
            }
          };

          Suggestions.prototype.handlePaste = function (e) {
            if (e.clipboardData) {
              this.handleInputChange(e.clipboardData.getData("Text"));
            } else {
              var self = this;
              setTimeout(function () {
                self.handleInputChange(e.target.value);
              }, 100);
            }
          };

          Suggestions.prototype.handleInputChange = function (query) {
            this.query = this.normalize(query);

            this.list.clear();

            if (this.query.length < this.options.minLength) {
              this.list.draw();
              return;
            }

            this.getCandidates(
              function (data) {
                for (var i = 0; i < data.length; i++) {
                  this.list.add(data[i]);
                  if (i === this.options.limit - 1) break;
                }
                this.list.draw();
              }.bind(this)
            );
          };

          Suggestions.prototype.handleFocus = function () {
            if (!this.list.isEmpty()) this.list.show();
            this.list.selectingListItem = false;
          };

          /**
           * Update data previously passed
           *
           * @param {Array} revisedData
           */
          Suggestions.prototype.update = function (revisedData) {
            this.data = revisedData;
            this.handleKeyUp();
          };

          /**
           * Clears data
           */
          Suggestions.prototype.clear = function () {
            this.data = [];
            this.list.clear();
          };

          /**
           * Normalize the results list and input value for matching
           *
           * @param {String} value
           * @return {String}
           */
          Suggestions.prototype.normalize = function (value) {
            value = value.toLowerCase();
            return value;
          };

          /**
           * Evaluates whether an array item qualifies as a match with the current query
           *
           * @param {String} candidate a possible item from the array passed
           * @param {String} query the current query
           * @return {Boolean}
           */
          Suggestions.prototype.match = function (candidate, query) {
            return candidate.indexOf(query) > -1;
          };

          Suggestions.prototype.value = function (value) {
            this.selected = value;
            this.el.value = this.getItemValue(value);

            if (document.createEvent) {
              var e = document.createEvent("HTMLEvents");
              e.initEvent("change", true, false);
              this.el.dispatchEvent(e);
            } else {
              this.el.fireEvent("onchange");
            }
          };

          Suggestions.prototype.getCandidates = function (callback) {
            var options = {
              pre: "<strong>",
              post: "</strong>",
              extract: function (d) {
                return this.getItemValue(d);
              }.bind(this),
            };
            var results;
            if (this.options.filter) {
              results = fuzzy.filter(this.query, this.data, options);

              results = results.map(
                function (item) {
                  return {
                    original: item.original,
                    string: this.render(item.original, item.string),
                  };
                }.bind(this)
              );
            } else {
              results = this.data.map(
                function (d) {
                  var renderedString = this.render(d);
                  return {
                    original: d,
                    string: renderedString,
                  };
                }.bind(this)
              );
            }
            callback(results);
          };

          /**
           * For a given item in the data array, return what should be used as the candidate string
           *
           * @param {Object|String} item an item from the data array
           * @return {String} item
           */
          Suggestions.prototype.getItemValue = function (item) {
            return item;
          };

          /**
           * For a given item in the data array, return a string of html that should be rendered in the dropdown
           * @param {Object|String} item an item from the data array
           * @param {String} sourceFormatting a string that has pre-formatted html that should be passed directly through the render function
           * @return {String} html
           */
          Suggestions.prototype.render = function (item, sourceFormatting) {
            if (sourceFormatting) {
              // use existing formatting on the source string
              return sourceFormatting;
            }
            var boldString = item.original
              ? this.getItemValue(item.original)
              : this.getItemValue(item);
            var indexString = this.normalize(boldString);
            var indexOfQuery = indexString.lastIndexOf(this.query);
            while (indexOfQuery > -1) {
              var endIndexOfQuery = indexOfQuery + this.query.length;
              boldString =
                boldString.slice(0, indexOfQuery) +
                "<strong>" +
                boldString.slice(indexOfQuery, endIndexOfQuery) +
                "</strong>" +
                boldString.slice(endIndexOfQuery);
              indexOfQuery = indexString
                .slice(0, indexOfQuery)
                .lastIndexOf(this.query);
            }
            return boldString;
          };

          /**
           * Render an custom error message in the suggestions list
           * @param {String} msg An html string to render as an error message
           */
          Suggestions.prototype.renderError = function (msg) {
            this.list.drawError(msg);
          };

          module.exports = Suggestions;
        },
        { "./list": 20, fuzzy: 9, xtend: 24 },
      ],
      22: [
        function (require, module, exports) {
          var each = require("turf-meta").coordEach;

          /**
           * Takes any {@link GeoJSON} object, calculates the extent of all input features, and returns a bounding box.
           *
           * @module turf/extent
           * @category measurement
           * @param {GeoJSON} input any valid GeoJSON Object
           * @return {Array<number>} the bounding box of `input` given
           * as an array in WSEN order (west, south, east, north)
           * @example
           * var input = {
           *   "type": "FeatureCollection",
           *   "features": [
           *     {
           *       "type": "Feature",
           *       "properties": {},
           *       "geometry": {
           *         "type": "Point",
           *         "coordinates": [114.175329, 22.2524]
           *       }
           *     }, {
           *       "type": "Feature",
           *       "properties": {},
           *       "geometry": {
           *         "type": "Point",
           *         "coordinates": [114.170007, 22.267969]
           *       }
           *     }, {
           *       "type": "Feature",
           *       "properties": {},
           *       "geometry": {
           *         "type": "Point",
           *         "coordinates": [114.200649, 22.274641]
           *       }
           *     }, {
           *       "type": "Feature",
           *       "properties": {},
           *       "geometry": {
           *         "type": "Point",
           *         "coordinates": [114.186744, 22.265745]
           *       }
           *     }
           *   ]
           * };
           *
           * var bbox = turf.extent(input);
           *
           * var bboxPolygon = turf.bboxPolygon(bbox);
           *
           * var resultFeatures = input.features.concat(bboxPolygon);
           * var result = {
           *   "type": "FeatureCollection",
           *   "features": resultFeatures
           * };
           *
           * //=result
           */
          module.exports = function (layer) {
            var extent = [Infinity, Infinity, -Infinity, -Infinity];
            each(layer, function (coord) {
              if (extent[0] > coord[0]) extent[0] = coord[0];
              if (extent[1] > coord[1]) extent[1] = coord[1];
              if (extent[2] < coord[0]) extent[2] = coord[0];
              if (extent[3] < coord[1]) extent[3] = coord[1];
            });
            return extent;
          };
        },
        { "turf-meta": 23 },
      ],
      23: [
        function (require, module, exports) {
          /**
           * Lazily iterate over coordinates in any GeoJSON object, similar to
           * Array.forEach.
           *
           * @param {Object} layer any GeoJSON object
           * @param {Function} callback a method that takes (value)
           * @param {boolean=} excludeWrapCoord whether or not to include
           * the final coordinate of LinearRings that wraps the ring in its iteration.
           * @example
           * var point = { type: 'Point', coordinates: [0, 0] };
           * coordEach(point, function(coords) {
           *   // coords is equal to [0, 0]
           * });
           */
          function coordEach(layer, callback, excludeWrapCoord) {
            var i,
              j,
              k,
              g,
              geometry,
              stopG,
              coords,
              geometryMaybeCollection,
              wrapShrink = 0,
              isGeometryCollection,
              isFeatureCollection = layer.type === "FeatureCollection",
              isFeature = layer.type === "Feature",
              stop = isFeatureCollection ? layer.features.length : 1;

            // This logic may look a little weird. The reason why it is that way
            // is because it's trying to be fast. GeoJSON supports multiple kinds
            // of objects at its root: FeatureCollection, Features, Geometries.
            // This function has the responsibility of handling all of them, and that
            // means that some of the `for` loops you see below actually just don't apply
            // to certain inputs. For instance, if you give this just a
            // Point geometry, then both loops are short-circuited and all we do
            // is gradually rename the input until it's called 'geometry'.
            //
            // This also aims to allocate as few resources as possible: just a
            // few numbers and booleans, rather than any temporary arrays as would
            // be required with the normalization approach.
            for (i = 0; i < stop; i++) {
              geometryMaybeCollection = isFeatureCollection
                ? layer.features[i].geometry
                : isFeature
                ? layer.geometry
                : layer;
              isGeometryCollection =
                geometryMaybeCollection.type === "GeometryCollection";
              stopG = isGeometryCollection
                ? geometryMaybeCollection.geometries.length
                : 1;

              for (g = 0; g < stopG; g++) {
                geometry = isGeometryCollection
                  ? geometryMaybeCollection.geometries[g]
                  : geometryMaybeCollection;
                coords = geometry.coordinates;

                wrapShrink =
                  excludeWrapCoord &&
                  (geometry.type === "Polygon" ||
                    geometry.type === "MultiPolygon")
                    ? 1
                    : 0;

                if (geometry.type === "Point") {
                  callback(coords);
                } else if (
                  geometry.type === "LineString" ||
                  geometry.type === "MultiPoint"
                ) {
                  for (j = 0; j < coords.length; j++) callback(coords[j]);
                } else if (
                  geometry.type === "Polygon" ||
                  geometry.type === "MultiLineString"
                ) {
                  for (j = 0; j < coords.length; j++)
                    for (k = 0; k < coords[j].length - wrapShrink; k++)
                      callback(coords[j][k]);
                } else if (geometry.type === "MultiPolygon") {
                  for (j = 0; j < coords.length; j++)
                    for (k = 0; k < coords[j].length; k++)
                      for (l = 0; l < coords[j][k].length - wrapShrink; l++)
                        callback(coords[j][k][l]);
                } else {
                  throw new Error("Unknown Geometry Type");
                }
              }
            }
          }
          module.exports.coordEach = coordEach;

          /**
           * Lazily reduce coordinates in any GeoJSON object into a single value,
           * similar to how Array.reduce works. However, in this case we lazily run
           * the reduction, so an array of all coordinates is unnecessary.
           *
           * @param {Object} layer any GeoJSON object
           * @param {Function} callback a method that takes (memo, value) and returns
           * a new memo
           * @param {boolean=} excludeWrapCoord whether or not to include
           * the final coordinate of LinearRings that wraps the ring in its iteration.
           * @param {*} memo the starting value of memo: can be any type.
           */
          function coordReduce(layer, callback, memo, excludeWrapCoord) {
            coordEach(
              layer,
              function (coord) {
                memo = callback(memo, coord);
              },
              excludeWrapCoord
            );
            return memo;
          }
          module.exports.coordReduce = coordReduce;

          /**
           * Lazily iterate over property objects in any GeoJSON object, similar to
           * Array.forEach.
           *
           * @param {Object} layer any GeoJSON object
           * @param {Function} callback a method that takes (value)
           * @example
           * var point = { type: 'Feature', geometry: null, properties: { foo: 1 } };
           * propEach(point, function(props) {
           *   // props is equal to { foo: 1}
           * });
           */
          function propEach(layer, callback) {
            var i;
            switch (layer.type) {
              case "FeatureCollection":
                features = layer.features;
                for (i = 0; i < layer.features.length; i++) {
                  callback(layer.features[i].properties);
                }
                break;
              case "Feature":
                callback(layer.properties);
                break;
            }
          }
          module.exports.propEach = propEach;

          /**
           * Lazily reduce properties in any GeoJSON object into a single value,
           * similar to how Array.reduce works. However, in this case we lazily run
           * the reduction, so an array of all properties is unnecessary.
           *
           * @param {Object} layer any GeoJSON object
           * @param {Function} callback a method that takes (memo, coord) and returns
           * a new memo
           * @param {*} memo the starting value of memo: can be any type.
           */
          function propReduce(layer, callback, memo) {
            propEach(layer, function (prop) {
              memo = callback(memo, prop);
            });
            return memo;
          }
          module.exports.propReduce = propReduce;
        },
        {},
      ],
      24: [
        function (require, module, exports) {
          module.exports = extend;

          var hasOwnProperty = Object.prototype.hasOwnProperty;

          function extend() {
            var target = {};

            for (var i = 0; i < arguments.length; i++) {
              var source = arguments[i];

              for (var key in source) {
                if (hasOwnProperty.call(source, key)) {
                  target[key] = source[key];
                }
              }
            }

            return target;
          }
        },
        {},
      ],
      25: [
        function (require, module, exports) {
          "use strict";

          function _typeof(obj) {
            "@babel/helpers - typeof";
            return (
              (_typeof =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (obj) {
                      return typeof obj;
                    }
                  : function (obj) {
                      return obj &&
                        "function" == typeof Symbol &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? "symbol"
                        : typeof obj;
                    }),
              _typeof(obj)
            );
          }
          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports.addWaypoint = addWaypoint;
          exports.clearDestination = clearDestination;
          exports.clearOrigin = clearOrigin;
          exports.createDestination = createDestination;
          exports.createOrigin = createOrigin;
          exports.eventEmit = eventEmit;
          exports.eventSubscribe = eventSubscribe;
          exports.hoverMarker = hoverMarker;
          exports.queryDestination = queryDestination;
          exports.queryDestinationCoordinates = queryDestinationCoordinates;
          exports.queryOrigin = queryOrigin;
          exports.queryOriginCoordinates = queryOriginCoordinates;
          exports.removeWaypoint = removeWaypoint;
          exports.reverse = reverse;
          exports.setDestinationFromCoordinates = setDestinationFromCoordinates;
          exports.setOptions = setOptions;
          exports.setOriginFromCoordinates = setOriginFromCoordinates;
          exports.setProfile = setProfile;
          exports.setRouteIndex = setRouteIndex;
          exports.setWaypoint = setWaypoint;
          var types = _interopRequireWildcard(
            require("../constants/action_types")
          );
          var _utils = _interopRequireDefault(require("../utils"));
          function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : { default: obj };
          }
          function _getRequireWildcardCache(nodeInterop) {
            if (typeof WeakMap !== "function") return null;
            var cacheBabelInterop = new WeakMap();
            var cacheNodeInterop = new WeakMap();
            return (_getRequireWildcardCache =
              function _getRequireWildcardCache(nodeInterop) {
                return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
              })(nodeInterop);
          }
          function _interopRequireWildcard(obj, nodeInterop) {
            if (!nodeInterop && obj && obj.__esModule) {
              return obj;
            }
            if (
              obj === null ||
              (_typeof(obj) !== "object" && typeof obj !== "function")
            ) {
              return { default: obj };
            }
            var cache = _getRequireWildcardCache(nodeInterop);
            if (cache && cache.has(obj)) {
              return cache.get(obj);
            }
            var newObj = {};
            var hasPropertyDescriptor =
              Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var key in obj) {
              if (
                key !== "default" &&
                Object.prototype.hasOwnProperty.call(obj, key)
              ) {
                var desc = hasPropertyDescriptor
                  ? Object.getOwnPropertyDescriptor(obj, key)
                  : null;
                if (desc && (desc.get || desc.set)) {
                  Object.defineProperty(newObj, key, desc);
                } else {
                  newObj[key] = obj[key];
                }
              }
            }
            newObj["default"] = obj;
            if (cache) {
              cache.set(obj, newObj);
            }
            return newObj;
          }
          var request = new XMLHttpRequest();
          function originPoint(coordinates) {
            return function (dispatch) {
              var origin = _utils["default"].createPoint(coordinates, {
                id: "origin",
                "marker-symbol": "A",
              });
              dispatch({
                type: types.ORIGIN,
                origin: origin,
              });
              dispatch(
                eventEmit("origin", {
                  feature: origin,
                })
              );
            };
          }
          function destinationPoint(coordinates) {
            return function (dispatch) {
              var destination = _utils["default"].createPoint(coordinates, {
                id: "destination",
                "marker-symbol": "B",
              });
              dispatch({
                type: types.DESTINATION,
                destination: destination,
              });
              dispatch(
                eventEmit("destination", {
                  feature: destination,
                })
              );
            };
          }
          function setDirections(directions) {
            return function (dispatch) {
              dispatch({
                type: types.DIRECTIONS,
                directions: directions,
              });
              dispatch(
                eventEmit("route", {
                  route: directions,
                })
              );
            };
          }
          function updateWaypoints(waypoints) {
            return {
              type: types.WAYPOINTS,
              waypoints: waypoints,
            };
          }
          function setHoverMarker(feature) {
            return {
              type: types.HOVER_MARKER,
              hoverMarker: feature,
            };
          }
          function fetchDirections() {
            return function (dispatch, getState) {
              var _getState = getState(),
                api = _getState.api,
                accessToken = _getState.accessToken,
                routeIndex = _getState.routeIndex,
                profile = _getState.profile,
                alternatives = _getState.alternatives,
                congestion = _getState.congestion,
                destination = _getState.destination,
                language = _getState.language,
                exclude = _getState.exclude;
              // if there is no destination set, do not make request because it will fail
              if (!(destination && destination.geometry)) return;
              var query = buildDirectionsQuery(getState);

              // Request params
              var options = [];
              options.push("geometries=polyline");
              if (alternatives) options.push("alternatives=true");
              if (congestion) options.push("annotations=congestion");
              options.push("steps=true");
              options.push("overview=full");
              if (language) options.push("language=" + language);
              if (exclude) options.push("exclude=" + exclude);
              if (accessToken) options.push("access_token=" + accessToken);
              request.abort();
              request.open(
                "GET",
                ""
                  .concat(api)
                  .concat(profile, "/")
                  .concat(query, ".json?")
                  .concat(options.join("&")),
                true
              );
              request.onload = function () {
                if (request.status >= 200 && request.status < 400) {
                  var data = JSON.parse(request.responseText);
                  if (data.error) {
                    dispatch(setDirections([]));
                    return dispatch(setError(data.error));
                  }

                  // Catch no route responses and display message to user
                  if (data.message === "No route found") {
                    return dispatch(setError("No route found"));
                  }
                  dispatch(setError(null));
                  if (!data.routes[routeIndex]) dispatch(setRouteIndex(0));
                  dispatch(setDirections(data.routes));

                  // Revise origin / destination points
                  dispatch(originPoint(data.waypoints[0].location));
                  dispatch(
                    destinationPoint(
                      data.waypoints[data.waypoints.length - 1].location
                    )
                  );
                } else {
                  dispatch(setDirections([]));
                  return dispatch(
                    setError(JSON.parse(request.responseText).message)
                  );
                }
              };
              request.onerror = function () {
                dispatch(setDirections([]));
                if (request.responseText)
                  return dispatch(
                    setError(JSON.parse(request.responseText).message)
                  );
                return dispatch(setError("Error"));
              };
              request.send();
            };
          }

          /*
           * Build query used to fetch directions
           *
           * @param {Function} state
           */
          function buildDirectionsQuery(state) {
            var _state = state(),
              origin = _state.origin,
              destination = _state.destination,
              waypoints = _state.waypoints;
            var query = [];
            query.push(origin.geometry.coordinates.join(","));
            query.push(";");

            // Add any waypoints.
            if (waypoints.length) {
              waypoints.forEach(function (waypoint) {
                query.push(waypoint.geometry.coordinates.join(","));
                query.push(";");
              });
            }
            query.push(destination.geometry.coordinates.join(","));
            return encodeURIComponent(query.join(""));
          }
          function normalizeWaypoint(waypoint) {
            var properties = {
              id: "waypoint",
            };
            return Object.assign(waypoint, {
              properties: waypoint.properties
                ? Object.assign(waypoint.properties, properties)
                : properties,
            });
          }
          function setError(error) {
            return function (dispatch) {
              dispatch({
                type: "ERROR",
                error: error,
              });
              if (error)
                dispatch(
                  eventEmit("error", {
                    error: error,
                  })
                );
            };
          }
          function queryOrigin(query) {
            return {
              type: types.ORIGIN_QUERY,
              query: query,
            };
          }
          function queryDestination(query) {
            return {
              type: types.DESTINATION_QUERY,
              query: query,
            };
          }
          function queryOriginCoordinates(coords) {
            return {
              type: types.ORIGIN_FROM_COORDINATES,
              coordinates: coords,
            };
          }
          function queryDestinationCoordinates(coords) {
            return {
              type: types.DESTINATION_FROM_COORDINATES,
              coordinates: coords,
            };
          }
          function clearOrigin() {
            return function (dispatch) {
              dispatch({
                type: types.ORIGIN_CLEAR,
              });
              dispatch(
                eventEmit("clear", {
                  type: "origin",
                })
              );
              dispatch(setError(null));
            };
          }
          function clearDestination() {
            request.abort();
            return function (dispatch) {
              dispatch({
                type: types.DESTINATION_CLEAR,
              });
              dispatch(
                eventEmit("clear", {
                  type: "destination",
                })
              );
              dispatch(setError(null));
            };
          }
          function setOptions(options) {
            return {
              type: types.SET_OPTIONS,
              options: options,
            };
          }
          function hoverMarker(coordinates) {
            return function (dispatch) {
              var feature = coordinates
                ? _utils["default"].createPoint(coordinates, {
                    id: "hover",
                  })
                : {};
              dispatch(setHoverMarker(feature));
            };
          }
          function setRouteIndex(routeIndex) {
            return {
              type: types.ROUTE_INDEX,
              routeIndex: routeIndex,
            };
          }
          function createOrigin(coordinates) {
            return function (dispatch, getState) {
              var _getState2 = getState(),
                destination = _getState2.destination;
              dispatch(originPoint(coordinates));
              if (destination.geometry) dispatch(fetchDirections());
            };
          }
          function createDestination(coordinates) {
            return function (dispatch, getState) {
              var _getState3 = getState(),
                origin = _getState3.origin;
              dispatch(destinationPoint(coordinates));
              if (origin.geometry) dispatch(fetchDirections());
            };
          }
          function setProfile(profile) {
            return function (dispatch, getState) {
              var _getState4 = getState(),
                origin = _getState4.origin,
                destination = _getState4.destination;
              dispatch({
                type: types.DIRECTIONS_PROFILE,
                profile: profile,
              });
              dispatch(
                eventEmit("profile", {
                  profile: profile,
                })
              );
              if (origin.geometry && destination.geometry)
                dispatch(fetchDirections());
            };
          }
          function reverse() {
            return function (dispatch, getState) {
              var state = getState();
              if (state.destination.geometry)
                dispatch(originPoint(state.destination.geometry.coordinates));
              if (state.origin.geometry)
                dispatch(destinationPoint(state.origin.geometry.coordinates));
              if (state.origin.geometry && state.destination.geometry)
                dispatch(fetchDirections());
              var suggestions = document.getElementsByClassName("suggestions");
              for (var i = 0; i < suggestions.length; i++) {
                suggestions[i].style.visibility = "hidden";
              }
            };
          }

          /*
           * Set origin from coordinates
           *
           * @param {Array<number>} coordinates [lng, lat] array.
           */
          function setOriginFromCoordinates(coords) {
            return function (dispatch) {
              if (!_utils["default"].validCoords(coords))
                coords = [
                  _utils["default"].wrap(coords[0]),
                  _utils["default"].wrap(coords[1]),
                ];
              if (isNaN(coords[0]) && isNaN(coords[1]))
                return dispatch(
                  setError(new Error("Coordinates are not valid"))
                );
              dispatch(queryOriginCoordinates(coords));
              dispatch(createOrigin(coords));
            };
          }

          /*
           * Set destination from coordinates
           *
           * @param {Array<number>} coords [lng, lat] array.
           */
          function setDestinationFromCoordinates(coords) {
            return function (dispatch) {
              if (!_utils["default"].validCoords(coords))
                coords = [
                  _utils["default"].wrap(coords[0]),
                  _utils["default"].wrap(coords[1]),
                ];
              if (isNaN(coords[0]) && isNaN(coords[1]))
                return dispatch(
                  setError(new Error("Coordinates are not valid"))
                );
              dispatch(createDestination(coords));
              dispatch(queryDestinationCoordinates(coords));
            };
          }
          function addWaypoint(index, waypoint) {
            return function (dispatch, getState) {
              var _getState5 = getState(),
                destination = _getState5.destination,
                waypoints = _getState5.waypoints;
              waypoints.splice(index, 0, normalizeWaypoint(waypoint));
              dispatch(updateWaypoints(waypoints));
              if (destination.geometry) dispatch(fetchDirections());
            };
          }
          function setWaypoint(index, waypoint) {
            return function (dispatch, getState) {
              var _getState6 = getState(),
                destination = _getState6.destination,
                waypoints = _getState6.waypoints;
              waypoints[index] = normalizeWaypoint(waypoint);
              dispatch(updateWaypoints(waypoints));
              if (destination.geometry) dispatch(fetchDirections());
            };
          }
          function removeWaypoint(waypoint) {
            return function (dispatch, getState) {
              var _getState7 = getState(),
                destination = _getState7.destination,
                waypoints = _getState7.waypoints;
              waypoints = waypoints.filter(function (way) {
                return !_utils["default"].coordinateMatch(way, waypoint);
              });
              dispatch(updateWaypoints(waypoints));
              if (destination.geometry) dispatch(fetchDirections());
            };
          }
          function eventSubscribe(type, fn) {
            return function (dispatch, getState) {
              var _getState8 = getState(),
                events = _getState8.events;
              events[type] = events[type] || [];
              events[type].push(fn);
              return {
                type: types.EVENTS,
                events: events,
              };
            };
          }
          function eventEmit(type, data) {
            var _this = this;
            return function (dispatch, getState) {
              var _getState9 = getState(),
                events = _getState9.events;
              if (!events[type]) {
                return {
                  type: types.EVENTS,
                  events: events,
                };
              }
              var listeners = events[type].slice();
              for (var i = 0; i < listeners.length; i++) {
                listeners[i].call(_this, data);
              }
            };
          }
        },
        { "../constants/action_types": 26, "../utils": 34 },
      ],
      26: [
        function (require, module, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports.WAYPOINTS =
            exports.SET_OPTIONS =
            exports.ROUTE_INDEX =
            exports.ORIGIN_QUERY =
            exports.ORIGIN_FROM_COORDINATES =
            exports.ORIGIN_CLEAR =
            exports.ORIGIN =
            exports.HOVER_MARKER =
            exports.EVENTS =
            exports.ERROR =
            exports.DIRECTIONS_PROFILE =
            exports.DIRECTIONS =
            exports.DESTINATION_QUERY =
            exports.DESTINATION_FROM_COORDINATES =
            exports.DESTINATION_CLEAR =
            exports.DESTINATION =
              void 0;
          var DESTINATION = "DESTINATION";
          exports.DESTINATION = DESTINATION;
          var DESTINATION_CLEAR = "DESTINATION_CLEAR";
          exports.DESTINATION_CLEAR = DESTINATION_CLEAR;
          var DESTINATION_QUERY = "DESTINATION_QUERY";
          exports.DESTINATION_QUERY = DESTINATION_QUERY;
          var DESTINATION_FROM_COORDINATES = "DESTINATION_FROM_COORDINATES";
          exports.DESTINATION_FROM_COORDINATES = DESTINATION_FROM_COORDINATES;
          var DIRECTIONS = "DIRECTIONS";
          exports.DIRECTIONS = DIRECTIONS;
          var DIRECTIONS_PROFILE = "DIRECTIONS_PROFILE";
          exports.DIRECTIONS_PROFILE = DIRECTIONS_PROFILE;
          var EVENTS = "EVENTS";
          exports.EVENTS = EVENTS;
          var ERROR = "ERROR";
          exports.ERROR = ERROR;
          var HOVER_MARKER = "HOVER_MARKER";
          exports.HOVER_MARKER = HOVER_MARKER;
          var ORIGIN = "ORIGIN";
          exports.ORIGIN = ORIGIN;
          var ORIGIN_CLEAR = "ORIGIN_CLEAR";
          exports.ORIGIN_CLEAR = ORIGIN_CLEAR;
          var ORIGIN_QUERY = "ORIGIN_QUERY";
          exports.ORIGIN_QUERY = ORIGIN_QUERY;
          var ORIGIN_FROM_COORDINATES = "ORIGIN_FROM_COORDINATES";
          exports.ORIGIN_FROM_COORDINATES = ORIGIN_FROM_COORDINATES;
          var ROUTE_INDEX = "ROUTE_INDEX";
          exports.ROUTE_INDEX = ROUTE_INDEX;
          var SET_OPTIONS = "SET_OPTIONS";
          exports.SET_OPTIONS = SET_OPTIONS;
          var WAYPOINTS = "WAYPOINTS";
          exports.WAYPOINTS = WAYPOINTS;
        },
        {},
      ],
      27: [
        function (require, module, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports["default"] = void 0;
          var _suggestions = _interopRequireDefault(require("suggestions"));
          var _lodash = _interopRequireDefault(require("lodash.debounce"));
          var _events = require("events");
          var _utils = _interopRequireDefault(require("../utils"));
          function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : { default: obj };
          }
          function _typeof(obj) {
            "@babel/helpers - typeof";
            return (
              (_typeof =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (obj) {
                      return typeof obj;
                    }
                  : function (obj) {
                      return obj &&
                        "function" == typeof Symbol &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? "symbol"
                        : typeof obj;
                    }),
              _typeof(obj)
            );
          }
          function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
              throw new TypeError("Cannot call a class as a function");
            }
          }
          function _defineProperties(target, props) {
            for (var i = 0; i < props.length; i++) {
              var descriptor = props[i];
              descriptor.enumerable = descriptor.enumerable || false;
              descriptor.configurable = true;
              if ("value" in descriptor) descriptor.writable = true;
              Object.defineProperty(
                target,
                _toPropertyKey(descriptor.key),
                descriptor
              );
            }
          }
          function _createClass(Constructor, protoProps, staticProps) {
            if (protoProps)
              _defineProperties(Constructor.prototype, protoProps);
            if (staticProps) _defineProperties(Constructor, staticProps);
            Object.defineProperty(Constructor, "prototype", {
              writable: false,
            });
            return Constructor;
          }
          function _toPropertyKey(arg) {
            var key = _toPrimitive(arg, "string");
            return _typeof(key) === "symbol" ? key : String(key);
          }
          function _toPrimitive(input, hint) {
            if (_typeof(input) !== "object" || input === null) return input;
            var prim = input[Symbol.toPrimitive];
            if (prim !== undefined) {
              var res = prim.call(input, hint || "default");
              if (_typeof(res) !== "object") return res;
              throw new TypeError(
                "@@toPrimitive must return a primitive value."
              );
            }
            return (hint === "string" ? String : Number)(input);
          }
          // Geocoder - this slightly mimicks the mapboxl-gl-geocoder but isn't an exact replica.
          // Once gl-js plugins can be added to custom divs, we should be able to require mapbox-gl-geocoder
          // instead of including it here
          var Geocoder = /*#__PURE__*/ (function () {
            function Geocoder(options) {
              _classCallCheck(this, Geocoder);
              this._ev = new _events.EventEmitter();
              this.options = options;
              this.api =
                (options && options.api) ||
                "https://api.mapbox.com/geocoding/v5/mapbox.places/";
            }
            _createClass(Geocoder, [
              {
                key: "onAdd",
                value: function onAdd(map) {
                  this._map = map;
                  this.request = new XMLHttpRequest();

                  // Template
                  var el = document.createElement("div");
                  el.className = "mapboxgl-ctrl-geocoder";
                  var icon = document.createElement("span");
                  icon.className = "geocoder-icon geocoder-icon-search";
                  var input = (this._inputEl = document.createElement("input"));
                  input.type = "text";
                  input.placeholder = this.options.placeholder;
                  input.addEventListener(
                    "keydown",
                    (0, _lodash["default"])(
                      function (e) {
                        if (!e.target.value)
                          return this._clearEl.classList.remove("active");

                        // TAB, ESC, LEFT, RIGHT, ENTER, UP, DOWN
                        if (
                          e.metaKey ||
                          [9, 27, 37, 39, 13, 38, 40].indexOf(e.keyCode) !== -1
                        )
                          return;
                        this._queryFromInput(e.target.value);
                      }.bind(this)
                    ),
                    200
                  );
                  input.addEventListener(
                    "change",
                    function (e) {
                      if (e.target.value) this._clearEl.classList.add("active");
                      var selected = this._typeahead.selected;
                      if (selected) {
                        if (this.options.flyTo) {
                          if (
                            (selected.bbox &&
                              selected.context &&
                              selected.context.length <= 3) ||
                            (selected.bbox && !selected.context)
                          ) {
                            var bbox = selected.bbox;
                            map.fitBounds([
                              [bbox[0], bbox[1]],
                              [bbox[2], bbox[3]],
                            ]);
                          } else {
                            map.flyTo({
                              center: selected.center,
                              zoom: this.options.zoom,
                            });
                          }
                        }
                        this._input = selected;
                        this.fire("result", {
                          result: selected,
                        });
                      }
                    }.bind(this)
                  );
                  var actions = document.createElement("div");
                  actions.classList.add("geocoder-pin-right");
                  var clear = (this._clearEl =
                    document.createElement("button"));
                  clear.className = "geocoder-icon geocoder-icon-close";
                  clear.addEventListener("click", this._clear.bind(this));
                  var loading = (this._loadingEl =
                    document.createElement("span"));
                  loading.className = "geocoder-icon geocoder-icon-loading";
                  actions.appendChild(clear);
                  actions.appendChild(loading);
                  el.appendChild(icon);
                  el.appendChild(input);
                  el.appendChild(actions);

                  // Override the control being added to control containers
                  if (this.options.container) this.options.position = false;
                  this._typeahead = new _suggestions["default"](input, [], {
                    filter: false,
                  });
                  this._typeahead.getItemValue = function (item) {
                    return item.place_name;
                  };
                  return el;
                },
              },
              {
                key: "_geocode",
                value: function _geocode(q, callback) {
                  this._loadingEl.classList.add("active");
                  this.fire("loading");
                  var geocodingOptions = this.options;
                  var exclude = [
                    "placeholder",
                    "zoom",
                    "flyTo",
                    "accessToken",
                    "api",
                  ];
                  var options = Object.keys(this.options)
                    .filter(function (key) {
                      return exclude.indexOf(key) === -1;
                    })
                    .map(function (key) {
                      return key + "=" + geocodingOptions[key];
                    });
                  var accessToken = this.options.accessToken
                    ? this.options.accessToken
                    : mapboxgl.accessToken;
                  options.push("access_token=" + accessToken);
                  this.request.abort();
                  this.request.open(
                    "GET",
                    this.api +
                      encodeURIComponent(q.trim()) +
                      ".json?" +
                      options.join("&"),
                    true
                  );
                  this.request.onload = function () {
                    this._loadingEl.classList.remove("active");
                    if (
                      this.request.status >= 200 &&
                      this.request.status < 400
                    ) {
                      var data = JSON.parse(this.request.responseText);
                      if (data.features.length) {
                        this._clearEl.classList.add("active");
                      } else {
                        this._clearEl.classList.remove("active");
                        this._typeahead.selected = null;
                      }
                      this.fire("results", {
                        results: data.features,
                      });
                      this._typeahead.update(data.features);
                      return callback(data.features);
                    } else {
                      this.fire("error", {
                        error: JSON.parse(this.request.responseText).message,
                      });
                    }
                  }.bind(this);
                  this.request.onerror = function () {
                    this._loadingEl.classList.remove("active");
                    this.fire("error", {
                      error: JSON.parse(this.request.responseText).message,
                    });
                  }.bind(this);
                  this.request.send();
                },
              },
              {
                key: "_queryFromInput",
                value: function _queryFromInput(q) {
                  q = q.trim();
                  if (!q) this._clear();
                  if (q.length > 2) {
                    this._geocode(
                      q,
                      function (results) {
                        this._results = results;
                      }.bind(this)
                    );
                  }
                },
              },
              {
                key: "_change",
                value: function _change() {
                  var onChange = document.createEvent("HTMLEvents");
                  onChange.initEvent("change", true, false);
                  this._inputEl.dispatchEvent(onChange);
                },
              },
              {
                key: "_query",
                value: function _query(input) {
                  if (!input) return;
                  if (_typeof(input) === "object" && input.length) {
                    input = [
                      _utils["default"].wrap(input[0]),
                      _utils["default"].wrap(input[1]),
                    ].join();
                  }
                  this._geocode(
                    input,
                    function (results) {
                      if (!results.length) return;
                      var result = results[0];
                      this._results = results;
                      this._typeahead.selected = result;
                      this._inputEl.value = result.place_name;
                      this._change();
                    }.bind(this)
                  );
                },
              },
              {
                key: "_setInput",
                value: function _setInput(input) {
                  if (!input) return;
                  if (_typeof(input) === "object" && input.length) {
                    input = [
                      _utils["default"].roundWithOriginalPrecision(
                        _utils["default"].wrap(input[0]),
                        input[0]
                      ),
                      _utils["default"].roundWithOriginalPrecision(
                        _utils["default"].wrap(input[1]),
                        input[1]
                      ),
                    ].join();
                  }

                  // Set input value to passed value and clear everything else.
                  this._inputEl.value = input;
                  this._input = null;
                  this._typeahead.selected = null;
                  this._typeahead.clear();
                  this._change();
                },
              },
              {
                key: "_clear",
                value: function _clear() {
                  this._input = null;
                  this._inputEl.value = "";
                  this._typeahead.selected = null;
                  this._typeahead.clear();
                  this._change();
                  this._inputEl.focus();
                  this._clearEl.classList.remove("active");
                  this.fire("clear");
                },
              },
              {
                key: "getResult",
                value: function getResult() {
                  return this._input;
                },

                /**
                 * Set & query the input
                 * @param {Array|String} query An array of coordinates [lng, lat] or location name as a string.
                 * @returns {Geocoder} this
                 */
              },
              {
                key: "query",
                value: function query(_query2) {
                  this._query(_query2);
                  return this;
                },

                /**
                 * Set input
                 * @param {Array|String} value An array of coordinates [lng, lat] or location name as a string. Calling this function just sets the input and does not trigger an API request.
                 * @returns {Geocoder} this
                 */
              },
              {
                key: "setInput",
                value: function setInput(value) {
                  this._setInput(value);
                  return this;
                },

                /**
                 * Subscribe to events that happen within the plugin.
                 * @param {String} type name of event. Available events and the data passed into their respective event objects are:
                 *
                 * - __clear__ `Emitted when the input is cleared`
                 * - __loading__ `Emitted when the geocoder is looking up a query`
                 * - __results__ `{ results } Fired when the geocoder returns a response`
                 * - __result__ `{ result } Fired when input is set`
                 * - __error__ `{ error } Error as string`
                 * @param {Function} fn function that's called when the event is emitted.
                 * @returns {Geocoder} this;
                 */
              },
              {
                key: "on",
                value: function on(type, fn) {
                  this._ev.on(type, fn);
                  this._ev.on("error", function (err) {
                    console.log(err);
                  });
                  return this;
                },
                /**
                 * Fire an event
                 * @param {String} type event name.
                 * @param {Object} data event data to pass to the function subscribed.
                 * @returns {Geocoder} this
                 */
              },
              {
                key: "fire",
                value: function fire(type, data) {
                  this._ev.emit(type, data);
                  return this;
                },

                /**
                 * Remove an event
                 * @returns {Geocoder} this
                 * @param {String} type Event name.
                 * @param {Function} fn Function that should unsubscribe to the event emitted.
                 */
              },
              {
                key: "off",
                value: function off(type, fn) {
                  this._ev.removeListener(type, fn);
                  return this;
                },
              },
            ]);
            return Geocoder;
          })();
          exports["default"] = Geocoder;
        },
        { "../utils": 34, events: 7, "lodash.debounce": 12, suggestions: 19 },
      ],
      28: [
        function (require, module, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports["default"] = void 0;
          var _geocoder = _interopRequireDefault(require("./geocoder"));
          var _lodash = _interopRequireDefault(require("lodash.template"));
          var _lodash2 = _interopRequireDefault(require("lodash.isequal"));
          var _turfExtent = _interopRequireDefault(require("turf-extent"));
          function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : { default: obj };
          }
          function _typeof(obj) {
            "@babel/helpers - typeof";
            return (
              (_typeof =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (obj) {
                      return typeof obj;
                    }
                  : function (obj) {
                      return obj &&
                        "function" == typeof Symbol &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? "symbol"
                        : typeof obj;
                    }),
              _typeof(obj)
            );
          }
          function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
              throw new TypeError("Cannot call a class as a function");
            }
          }
          function _defineProperties(target, props) {
            for (var i = 0; i < props.length; i++) {
              var descriptor = props[i];
              descriptor.enumerable = descriptor.enumerable || false;
              descriptor.configurable = true;
              if ("value" in descriptor) descriptor.writable = true;
              Object.defineProperty(
                target,
                _toPropertyKey(descriptor.key),
                descriptor
              );
            }
          }
          function _createClass(Constructor, protoProps, staticProps) {
            if (protoProps)
              _defineProperties(Constructor.prototype, protoProps);
            if (staticProps) _defineProperties(Constructor, staticProps);
            Object.defineProperty(Constructor, "prototype", {
              writable: false,
            });
            return Constructor;
          }
          function _toPropertyKey(arg) {
            var key = _toPrimitive(arg, "string");
            return _typeof(key) === "symbol" ? key : String(key);
          }
          function _toPrimitive(input, hint) {
            if (_typeof(input) !== "object" || input === null) return input;
            var prim = input[Symbol.toPrimitive];
            if (prim !== undefined) {
              var res = prim.call(input, hint || "default");
              if (_typeof(res) !== "object") return res;
              throw new TypeError(
                "@@toPrimitive must return a primitive value."
              );
            }
            return (hint === "string" ? String : Number)(input);
          }
          // substack/brfs#39
          var tmpl = (0, _lodash["default"])(
            "<div class='mapbox-directions-component mapbox-directions-inputs'>\n  <div class='mapbox-directions-component-keyline'>\n    <div class='mapbox-directions-origin'>\n      <label class='mapbox-form-label'>\n        <span class='directions-icon directions-icon-depart'></span>\n      </label>\n      <div id='mapbox-directions-origin-input'></div>\n    </div>\n\n    <button\n      class='directions-icon directions-icon-reverse directions-reverse js-reverse-inputs'\n      title='Reverse origin &amp; destination'>\n    </button>\n\n    <div class='mapbox-directions-destination'>\n      <label class='mapbox-form-label'>\n        <span class='directions-icon directions-icon-arrive'></span>\n      </label>\n      <div id='mapbox-directions-destination-input'></div>\n    </div>\n  </div>\n\n  <% if (controls.profileSwitcher) { %>\n  <div class='mapbox-directions-profile mapbox-directions-component-keyline mapbox-directions-clearfix'><input\n      id='mapbox-directions-profile-driving-traffic'\n      type='radio'\n      name='profile'\n      value='mapbox/driving-traffic'\n      <% if (profile === 'mapbox/driving-traffic') { %>checked<% } %>\n    />\n     <input\n      id='mapbox-directions-profile-driving'\n      type='radio'\n      name='profile'\n      value='mapbox/driving'\n      <% if (profile === 'mapbox/driving') { %>checked<% } %>\n    />\n    <input\n      id='mapbox-directions-profile-walking'\n      type='radio'\n      name='profile'\n      value='mapbox/walking'\n      <% if (profile === 'mapbox/walking') { %>checked<% } else { %>checked<% } %>\n    />\n    <label for='mapbox-directions-profile-walking'>Walking</label>\n    <input\n      id='mapbox-directions-profile-cycling'\n      type='radio'\n      name='profile'\n      value='mapbox/cycling'\n      <% if (profile === 'mapbox/cycling') { %>checked<% } %>\n    />\n    <label for='mapbox-directions-profile-cycling'>Cycling</label>\n  </div>\n  <% } %>\n</div>\n"
          );

          /**
           * Inputs controller
           *
           * @param {HTMLElement} el Summary parent container
           * @param {Object} store A redux store
           * @param {Object} actions Actions an element can dispatch
           * @param {Object} map The mapboxgl instance
           * @private
           */
          var Inputs = /*#__PURE__*/ (function () {
            function Inputs(el, store, actions, map) {
              _classCallCheck(this, Inputs);
              var _store$getState = store.getState(),
                originQuery = _store$getState.originQuery,
                destinationQuery = _store$getState.destinationQuery,
                profile = _store$getState.profile,
                controls = _store$getState.controls;
              el.innerHTML = tmpl({
                originQuery: originQuery,
                destinationQuery: destinationQuery,
                profile: profile,
                controls: controls,
              });
              this.container = el;
              this.actions = actions;
              this.store = store;
              this._map = map;
              this.onAdd();
              this.render();
            }
            _createClass(Inputs, [
              {
                key: "animateToCoordinates",
                value: function animateToCoordinates(mode, coords) {
                  var _this$store$getState = this.store.getState(),
                    origin = _this$store$getState.origin,
                    destination = _this$store$getState.destination,
                    routePadding = _this$store$getState.routePadding;
                  if (
                    origin.geometry &&
                    destination.geometry &&
                    !(0, _lodash2["default"])(
                      origin.geometry,
                      destination.geometry
                    )
                  ) {
                    // Animate map to fit bounds.
                    var bb = (0, _turfExtent["default"])({
                      type: "FeatureCollection",
                      features: [origin, destination],
                    });
                    this._map.fitBounds(
                      [
                        [bb[0], bb[1]],
                        [bb[2], bb[3]],
                      ],
                      {
                        padding: routePadding,
                      }
                    );
                  } else {
                    this._map.flyTo({
                      center: coords,
                    });
                  }
                },
              },
              {
                key: "onAdd",
                value: function onAdd() {
                  var _this = this;
                  var _this$actions = this.actions,
                    clearOrigin = _this$actions.clearOrigin,
                    clearDestination = _this$actions.clearDestination,
                    createOrigin = _this$actions.createOrigin,
                    createDestination = _this$actions.createDestination,
                    setProfile = _this$actions.setProfile,
                    reverse = _this$actions.reverse;
                  var _this$store$getState2 = this.store.getState(),
                    geocoder = _this$store$getState2.geocoder,
                    accessToken = _this$store$getState2.accessToken,
                    flyTo = _this$store$getState2.flyTo,
                    placeholderOrigin = _this$store$getState2.placeholderOrigin,
                    placeholderDestination =
                      _this$store$getState2.placeholderDestination,
                    zoom = _this$store$getState2.zoom;
                  this.originInput = new _geocoder["default"](
                    Object.assign(
                      {},
                      {
                        accessToken: accessToken,
                      },
                      geocoder,
                      {
                        flyTo: flyTo,
                        placeholder: placeholderOrigin,
                        zoom: zoom,
                      }
                    )
                  );
                  var originEl = this.originInput.onAdd(this._map);
                  var originContainerEl = this.container.querySelector(
                    "#mapbox-directions-origin-input"
                  );
                  originContainerEl.appendChild(originEl);
                  this.destinationInput = new _geocoder["default"](
                    Object.assign(
                      {},
                      {
                        accessToken: accessToken,
                      },
                      geocoder,
                      {
                        flyTo: flyTo,
                        placeholder: placeholderDestination,
                        zoom: zoom,
                      }
                    )
                  );
                  var destinationEl = this.destinationInput.onAdd(this._map);
                  this.container
                    .querySelector("#mapbox-directions-destination-input")
                    .appendChild(destinationEl);
                  this.originInput.on("result", function (e) {
                    var coords = e.result.center;
                    createOrigin(coords);
                    _this.animateToCoordinates("origin", coords);
                  });
                  this.originInput.on("clear", clearOrigin);
                  this.destinationInput.on("result", function (e) {
                    var coords = e.result.center;
                    createDestination(coords);
                    _this.animateToCoordinates("destination", coords);
                  });
                  this.destinationInput.on("clear", clearDestination);

                  // Driving / Walking / Cycling profiles
                  var profiles = this.container.querySelectorAll(
                    'input[type="radio"]'
                  );
                  Array.prototype.forEach.call(profiles, function (el) {
                    el.addEventListener("change", function () {
                      setProfile(el.value);
                    });
                  });

                  // Reversing Origin / Destination
                  this.container
                    .querySelector(".js-reverse-inputs")
                    .addEventListener("click", function () {
                      var _this$store$getState3 = _this.store.getState(),
                        origin = _this$store$getState3.origin,
                        destination = _this$store$getState3.destination;
                      if (origin)
                        _this.actions.queryDestination(
                          origin.geometry.coordinates
                        );
                      if (destination)
                        _this.actions.queryOrigin(
                          destination.geometry.coordinates
                        );
                      reverse();
                    });
                },
              },
              {
                key: "render",
                value: function render() {
                  var _this2 = this;
                  this.store.subscribe(function () {
                    var _this2$store$getState = _this2.store.getState(),
                      originQuery = _this2$store$getState.originQuery,
                      destinationQuery = _this2$store$getState.destinationQuery,
                      originQueryCoordinates =
                        _this2$store$getState.originQueryCoordinates,
                      destinationQueryCoordinates =
                        _this2$store$getState.destinationQueryCoordinates;
                    if (originQuery) {
                      _this2.originInput.query(originQuery);
                      _this2.actions.queryOrigin(null);
                    }
                    if (destinationQuery) {
                      _this2.destinationInput.query(destinationQuery);
                      _this2.actions.queryDestination(null);
                    }
                    if (originQueryCoordinates) {
                      _this2.originInput.setInput(originQueryCoordinates);
                      _this2.animateToCoordinates(
                        "origin",
                        originQueryCoordinates
                      );
                      _this2.actions.queryOriginCoordinates(null);
                    }
                    if (destinationQueryCoordinates) {
                      _this2.destinationInput.setInput(
                        destinationQueryCoordinates
                      );
                      _this2.animateToCoordinates(
                        "destination",
                        destinationQueryCoordinates
                      );
                      _this2.actions.queryDestinationCoordinates(null);
                    }
                  });
                },
              },
            ]);
            return Inputs;
          })();
          exports["default"] = Inputs;
        },
        {
          "./geocoder": 27,
          "lodash.isequal": 13,
          "lodash.template": 14,
          "turf-extent": 22,
        },
      ],
      29: [
        function (require, module, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports["default"] = void 0;
          var _utils = _interopRequireDefault(require("../utils"));
          var _lodash = _interopRequireDefault(require("lodash.template"));
          var _lodash2 = _interopRequireDefault(require("lodash.isequal"));
          function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : { default: obj };
          }
          function _typeof(obj) {
            "@babel/helpers - typeof";
            return (
              (_typeof =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (obj) {
                      return typeof obj;
                    }
                  : function (obj) {
                      return obj &&
                        "function" == typeof Symbol &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? "symbol"
                        : typeof obj;
                    }),
              _typeof(obj)
            );
          }
          function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
              throw new TypeError("Cannot call a class as a function");
            }
          }
          function _defineProperties(target, props) {
            for (var i = 0; i < props.length; i++) {
              var descriptor = props[i];
              descriptor.enumerable = descriptor.enumerable || false;
              descriptor.configurable = true;
              if ("value" in descriptor) descriptor.writable = true;
              Object.defineProperty(
                target,
                _toPropertyKey(descriptor.key),
                descriptor
              );
            }
          }
          function _createClass(Constructor, protoProps, staticProps) {
            if (protoProps)
              _defineProperties(Constructor.prototype, protoProps);
            if (staticProps) _defineProperties(Constructor, staticProps);
            Object.defineProperty(Constructor, "prototype", {
              writable: false,
            });
            return Constructor;
          }
          function _toPropertyKey(arg) {
            var key = _toPrimitive(arg, "string");
            return _typeof(key) === "symbol" ? key : String(key);
          }
          function _toPrimitive(input, hint) {
            if (_typeof(input) !== "object" || input === null) return input;
            var prim = input[Symbol.toPrimitive];
            if (prim !== undefined) {
              var res = prim.call(input, hint || "default");
              if (_typeof(res) !== "object") return res;
              throw new TypeError(
                "@@toPrimitive must return a primitive value."
              );
            }
            return (hint === "string" ? String : Number)(input);
          }
          // substack/brfs#39
          var instructionsTemplate = (0, _lodash["default"])(
            "<div class='directions-control directions-control-directions'>\n  <div class='mapbox-directions-component mapbox-directions-route-summary<% if (routes > 1) { %> mapbox-directions-multiple<% } %>'>\n    <% if (routes > 1) { %>\n    <div class='mapbox-directions-routes mapbox-directions-clearfix'>\n      <% for (var i = 0; i < routes; i++) { %>\n        <input type='radio' name='routes' id='<%= i %>' <% if (i === routeIndex) { %>checked<% } %>>\n        <label for='<%= i %>' class='mapbox-directions-route'><%= i + 1 %></label>\n      <% } %>\n    </div>\n    <% } %>\n    <h1><%- duration %></h1>\n    <span><%- distance %></span>\n  </div>\n\n  <div class='mapbox-directions-instructions'>\n    <div class='mapbox-directions-instructions-wrapper'>\n      <ol class='mapbox-directions-steps'>\n        <% steps.forEach(function(step) { %>\n          <%\n            var distance = step.distance ? format(step.distance) : false;\n            var icon = step.maneuver.modifier ? step.maneuver.modifier.replace(/\\s+/g, '-').toLowerCase() : step.maneuver.type.replace(/\\s+/g, '-').toLowerCase();\n\n            if (step.maneuver.type === 'arrive' || step.maneuver.type === 'depart') {\n              icon = step.maneuver.type;\n            }\n\n            if (step.maneuver.type === 'roundabout' || step.maneuver.type === 'rotary') {\n              icon= 'roundabout';\n            }\n\n            var lng = step.maneuver.location[0];\n            var lat = step.maneuver.location[1];\n          %>\n          <li\n            data-lat='<%= lat %>'\n            data-lng='<%= lng %>'\n            class='mapbox-directions-step'>\n            <span class='directions-icon directions-icon-<%= icon %>'></span>\n            <div class='mapbox-directions-step-maneuver'>\n              <%= step.maneuver.instruction %>\n            </div>\n            <% if (distance) { %>\n              <div class='mapbox-directions-step-distance'>\n                <%= distance %>\n              </div>\n            <% } %>\n          </li>\n        <% }); %>\n      </ol>\n    </div>\n  </div>\n</div>\n"
          );
          var errorTemplate = (0, _lodash["default"])(
            "<div class='directions-control directions-control-directions'>\n  <div class='mapbox-directions-error'>\n    <%= error %>\n  </div>\n</div>\n"
          );

          /**
           * Summary/Instructions controller
           *
           * @param {HTMLElement} el Summary parent container
           * @param {Object} store A redux store
           * @param {Object} actions Actions an element can dispatch
           * @param {Object} map The mapboxgl instance
           * @private
           */
          var Instructions = /*#__PURE__*/ (function () {
            function Instructions(el, store, actions, map) {
              _classCallCheck(this, Instructions);
              this.container = el;
              this.actions = actions;
              this.store = store;
              this._map = map;
              this.directions = {};
              this.render();
            }
            _createClass(Instructions, [
              {
                key: "render",
                value: function render() {
                  var _this = this;
                  this.store.subscribe(function () {
                    var _this$actions = _this.actions,
                      hoverMarker = _this$actions.hoverMarker,
                      setRouteIndex = _this$actions.setRouteIndex;
                    var _this$store$getState = _this.store.getState(),
                      routeIndex = _this$store$getState.routeIndex,
                      unit = _this$store$getState.unit,
                      directions = _this$store$getState.directions,
                      error = _this$store$getState.error,
                      compile = _this$store$getState.compile;
                    var shouldRender = !(0, _lodash2["default"])(
                      directions[routeIndex],
                      _this.directions
                    );
                    if (error) {
                      _this.container.innerHTML = errorTemplate({
                        error: error,
                      });
                      return;
                    }
                    if (directions.length && shouldRender) {
                      var direction = (_this.directions =
                        directions[routeIndex]);
                      if (compile) {
                        direction.legs.forEach(function (leg) {
                          leg.steps.forEach(function (step) {
                            step.maneuver.instruction = compile("en", step);
                          });
                        });
                      }
                      _this.container.innerHTML = instructionsTemplate({
                        routeIndex: routeIndex,
                        routes: directions.length,
                        steps: direction.legs[0].steps,
                        // Todo: Respect all legs,
                        format: _utils["default"].format[unit],
                        duration: _utils["default"].format.duration(
                          direction.duration
                        ),
                        distance: _utils["default"].format[unit](
                          direction.distance
                        ),
                      });
                      var steps = _this.container.querySelectorAll(
                        ".mapbox-directions-step"
                      );
                      Array.prototype.forEach.call(steps, function (el) {
                        var lng = el.getAttribute("data-lng");
                        var lat = el.getAttribute("data-lat");
                        el.addEventListener("mouseover", function () {
                          hoverMarker([lng, lat]);
                        });
                        el.addEventListener("mouseout", function () {
                          hoverMarker(null);
                        });
                        el.addEventListener("click", function () {
                          _this._map.flyTo({
                            center: [lng, lat],
                            zoom: 16,
                          });
                        });
                      });
                      var routes = _this.container.querySelectorAll(
                        'input[type="radio"]'
                      );
                      Array.prototype.forEach.call(routes, function (el) {
                        el.addEventListener("change", function (e) {
                          setRouteIndex(parseInt(e.target.id, 10));
                        });
                      });
                    } else if (_this.container.innerHTML && shouldRender) {
                      _this.container.innerHTML = "";
                    }
                  });
                },
              },
            ]);
            return Instructions;
          })();
          exports["default"] = Instructions;
        },
        { "../utils": 34, "lodash.isequal": 13, "lodash.template": 14 },
      ],
      30: [
        function (require, module, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports["default"] = void 0;
          var _redux = require("redux");
          var _reduxThunk = _interopRequireDefault(require("redux-thunk"));
          var _polyline = require("@mapbox/polyline");
          var _utils = _interopRequireDefault(require("./utils"));
          var _reducers = _interopRequireDefault(require("./reducers"));
          var actions = _interopRequireWildcard(require("./actions"));
          var _directions_style = _interopRequireDefault(
            require("./directions_style")
          );
          var _inputs = _interopRequireDefault(require("./controls/inputs"));
          var _instructions = _interopRequireDefault(
            require("./controls/instructions")
          );
          function _getRequireWildcardCache(nodeInterop) {
            if (typeof WeakMap !== "function") return null;
            var cacheBabelInterop = new WeakMap();
            var cacheNodeInterop = new WeakMap();
            return (_getRequireWildcardCache =
              function _getRequireWildcardCache(nodeInterop) {
                return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
              })(nodeInterop);
          }
          function _interopRequireWildcard(obj, nodeInterop) {
            if (!nodeInterop && obj && obj.__esModule) {
              return obj;
            }
            if (
              obj === null ||
              (_typeof(obj) !== "object" && typeof obj !== "function")
            ) {
              return { default: obj };
            }
            var cache = _getRequireWildcardCache(nodeInterop);
            if (cache && cache.has(obj)) {
              return cache.get(obj);
            }
            var newObj = {};
            var hasPropertyDescriptor =
              Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var key in obj) {
              if (
                key !== "default" &&
                Object.prototype.hasOwnProperty.call(obj, key)
              ) {
                var desc = hasPropertyDescriptor
                  ? Object.getOwnPropertyDescriptor(obj, key)
                  : null;
                if (desc && (desc.get || desc.set)) {
                  Object.defineProperty(newObj, key, desc);
                } else {
                  newObj[key] = obj[key];
                }
              }
            }
            newObj["default"] = obj;
            if (cache) {
              cache.set(obj, newObj);
            }
            return newObj;
          }
          function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : { default: obj };
          }
          function _typeof(obj) {
            "@babel/helpers - typeof";
            return (
              (_typeof =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (obj) {
                      return typeof obj;
                    }
                  : function (obj) {
                      return obj &&
                        "function" == typeof Symbol &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? "symbol"
                        : typeof obj;
                    }),
              _typeof(obj)
            );
          }
          function _classCallCheck(instance, Constructor) {
            if (!(instance instanceof Constructor)) {
              throw new TypeError("Cannot call a class as a function");
            }
          }
          function _defineProperties(target, props) {
            for (var i = 0; i < props.length; i++) {
              var descriptor = props[i];
              descriptor.enumerable = descriptor.enumerable || false;
              descriptor.configurable = true;
              if ("value" in descriptor) descriptor.writable = true;
              Object.defineProperty(
                target,
                _toPropertyKey(descriptor.key),
                descriptor
              );
            }
          }
          function _createClass(Constructor, protoProps, staticProps) {
            if (protoProps)
              _defineProperties(Constructor.prototype, protoProps);
            if (staticProps) _defineProperties(Constructor, staticProps);
            Object.defineProperty(Constructor, "prototype", {
              writable: false,
            });
            return Constructor;
          }
          function _toPropertyKey(arg) {
            var key = _toPrimitive(arg, "string");
            return _typeof(key) === "symbol" ? key : String(key);
          }
          function _toPrimitive(input, hint) {
            if (_typeof(input) !== "object" || input === null) return input;
            var prim = input[Symbol.toPrimitive];
            if (prim !== undefined) {
              var res = prim.call(input, hint || "default");
              if (_typeof(res) !== "object") return res;
              throw new TypeError(
                "@@toPrimitive must return a primitive value."
              );
            }
            return (hint === "string" ? String : Number)(input);
          }
          var storeWithMiddleware = (0, _redux.applyMiddleware)(
            _reduxThunk["default"]
          )(_redux.createStore);
          var store = storeWithMiddleware(_reducers["default"]);

          // State object management via redux
          /**
           * The Directions control
           * @class MapboxDirections
           *
           * @param {Object} options
           * @param {Array} [options.styles] Override default layer properties of the [directions source](https://github.com/mapbox/mapbox-gl-directions/blob/master/src/directions_style.js). Documentation for each property are specified in the [Mapbox GL Style Reference](https://www.mapbox.com/mapbox-gl-style-spec/).
           * @param {String} [options.accessToken=null] Required unless `mapboxgl.accessToken` is set globally
           * @param {String} [options.api="https://api.mapbox.com/directions/v5/"] Override default routing endpoint url
           * @param {Boolean} [options.interactive=true] Enable/Disable mouse or touch interactivity from the plugin
           * @param {String} [options.profile="mapbox/driving-traffic"] Routing profile to use. Options: `mapbox/driving-traffic`, `mapbox/driving`, `mapbox/walking`, `mapbox/cycling`
           * @param {Boolean} [options.alternatives=false] Whether to enable alternatives.
           * @param {Boolean} [options.congestion=false] Whether to enable congestion along the route line.
           * @param {String} [options.unit="imperial"] Measurement system to be used in navigation instructions. Options: `imperial`, `metric`
           * @param {Function} [options.compile=null] Provide a custom function for generating instruction, compatible with osrm-text-instructions.
           * @param {Object} [options.geocoder] Accepts an object containing the query parameters as [documented here](https://www.mapbox.com/api-documentation/#search-for-places).
           * @param {Object} [options.controls]
           * @param {Boolean} [options.controls.inputs=true] Hide or display the inputs control.
           * @param {Boolean} [options.controls.instructions=true] Hide or display the instructions control.
           * @param {Boolean} [options.controls.profileSwitcher=true] Hide or display the default profile switch with options for traffic, driving, walking and cycling.
           * @param {Number} [options.zoom=16] If no bbox exists from the geocoder result, the zoom you set here will be used in the flyTo.
           * @param {String} [options.language="en"] The language of returned turn-by-turn text instructions. See supported languages : https://docs.mapbox.com/api/navigation/#instructions-languages
           * @param {String} [options.placeholderOrigin="Choose a starting place"] If set, this text will appear as the placeholder attribute for the origin input element.
           * @param {String} [options.placeholderDestination="Choose destination"] If set, this text will appear as the placeholder attribute for the destination input element.
           * @param {Boolean} [options.flyTo=true] If false, animating the map to a selected result is disabled.
           * @param {String} [options.exclude=null] Exclude certain road types from routing. The default is to not exclude anything. Search for `exclude` in `optional parameters`: https://docs.mapbox.com/api/navigation/#retrieve-directions
           * @param {number | PaddingOptions} [options.routePadding=80] Specify padding surrounding route. A single number of pixels or a [PaddingOptions](https://docs.mapbox.com/mapbox-gl-js/api/#paddingoptions) object.
           * @example
           * var MapboxDirections = require('../src/index');
           * var directions = new MapboxDirections({
           *   accessToken: 'YOUR-MAPBOX-ACCESS-TOKEN',
           *   unit: 'metric',
           *   profile: 'mapbox/cycling'
           * });
           * // add to your mapboxgl map
           * map.addControl(directions);
           *
           * @return {MapboxDirections} `this`
           */
          var MapboxDirections = /*#__PURE__*/ (function () {
            function MapboxDirections(options) {
              _classCallCheck(this, MapboxDirections);
              this.actions = (0, _redux.bindActionCreators)(
                actions,
                store.dispatch
              );
              this.actions.setOptions(options || {});
              this.options = options || {};
              this.onDragDown = this._onDragDown.bind(this);
              this.onDragMove = this._onDragMove.bind(this);
              this.onDragUp = this._onDragUp.bind(this);
              this.move = this._move.bind(this);
              this.onClick = this._clickHandler().bind(this);
            }
            _createClass(MapboxDirections, [
              {
                key: "onAdd",
                value: function onAdd(map) {
                  var _this = this;
                  this._map = map;
                  var _store$getState = store.getState(),
                    controls = _store$getState.controls;
                  var el = (this.container = document.createElement("div"));
                  el.className = "mapboxgl-ctrl-directions mapboxgl-ctrl";

                  // Add controls to the page
                  var inputEl = document.createElement("div");
                  inputEl.className =
                    "directions-control directions-control-inputs";
                  new _inputs["default"](
                    inputEl,
                    store,
                    this.actions,
                    this._map
                  );
                  var directionsEl = document.createElement("div");
                  directionsEl.className =
                    "directions-control directions-control-instructions";
                  new _instructions["default"](
                    directionsEl,
                    store,
                    {
                      hoverMarker: this.actions.hoverMarker,
                      setRouteIndex: this.actions.setRouteIndex,
                    },
                    this._map
                  );
                  if (controls.inputs) el.appendChild(inputEl);
                  if (controls.instructions) el.appendChild(directionsEl);
                  this.subscribedActions();
                  if (this._map.loaded()) this.mapState();
                  else
                    this._map.on("load", function () {
                      return _this.mapState();
                    });
                  return el;
                },

                /**
                 * Removes the control from the map it has been added to. This is called by `map.removeControl`,
                 * which is the recommended method to remove controls.
                 *
                 * @returns {Control} `this`
                 */
              },
              {
                key: "onRemove",
                value: function onRemove(map) {
                  this.container.parentNode.removeChild(this.container);
                  this.removeRoutes();
                  map.off("mousedown", this.onDragDown);
                  map.off("mousemove", this.move);
                  map.off("touchstart", this.onDragDown);
                  map.off("touchstart", this.move);
                  map.off("click", this.onClick);
                  if (this.storeUnsubscribe) {
                    this.storeUnsubscribe();
                    delete this.storeUnsubscribe;
                  }
                  _directions_style["default"].forEach(function (layer) {
                    if (map.getLayer(layer.id)) map.removeLayer(layer.id);
                  });
                  if (map.getSource("directions"))
                    map.removeSource("directions");
                  this._map = null;
                  return this;
                },
              },
              {
                key: "mapState",
                value: function mapState() {
                  var _this2 = this;
                  var _store$getState2 = store.getState(),
                    profile = _store$getState2.profile,
                    alternatives = _store$getState2.alternatives,
                    congestion = _store$getState2.congestion,
                    styles = _store$getState2.styles,
                    interactive = _store$getState2.interactive,
                    compile = _store$getState2.compile;

                  // Emit any default or option set config
                  this.actions.eventEmit("profile", {
                    profile: profile,
                  });
                  var geojson = {
                    type: "geojson",
                    data: {
                      type: "FeatureCollection",
                      features: [],
                    },
                  };

                  // Add and set data theme layer/style
                  this._map.addSource("directions", geojson);

                  // Add direction specific styles to the map
                  if (styles && styles.length)
                    styles.forEach(function (style) {
                      return _this2._map.addLayer(style);
                    });
                  _directions_style["default"].forEach(function (style) {
                    // only add the default style layer if a custom layer wasn't provided
                    if (!_this2._map.getLayer(style.id))
                      _this2._map.addLayer(style);
                  });
                  if (interactive) {
                    this._map.on("mousedown", this.onDragDown);
                    this._map.on("mousemove", this.move);
                    this._map.on("click", this.onClick);
                    this._map.on("touchstart", this.move);
                    this._map.on("touchstart", this.onDragDown);
                  }
                },
              },
              {
                key: "subscribedActions",
                value: function subscribedActions() {
                  var _this3 = this;
                  this.storeUnsubscribe = store.subscribe(function () {
                    var _store$getState3 = store.getState(),
                      origin = _store$getState3.origin,
                      destination = _store$getState3.destination,
                      hoverMarker = _store$getState3.hoverMarker,
                      directions = _store$getState3.directions,
                      routeIndex = _store$getState3.routeIndex;
                    var geojson = {
                      type: "FeatureCollection",
                      features: [origin, destination, hoverMarker].filter(
                        function (d) {
                          return d.geometry;
                        }
                      ),
                    };
                    if (directions.length) {
                      directions.forEach(function (feature, index) {
                        var features = [];
                        var decoded = (0, _polyline.decode)(
                          feature.geometry,
                          5
                        ).map(function (c) {
                          return c.reverse();
                        });
                        decoded.forEach(function (c, i) {
                          var previous = features[features.length - 1];
                          var congestion =
                            feature.legs[0].annotation &&
                            feature.legs[0].annotation.congestion &&
                            feature.legs[0].annotation.congestion[i - 1];
                          if (
                            previous &&
                            (!congestion ||
                              previous.properties.congestion === congestion)
                          ) {
                            previous.geometry.coordinates.push(c);
                          } else {
                            var segment = {
                              geometry: {
                                type: "LineString",
                                coordinates: [],
                              },
                              properties: {
                                "route-index": index,
                                route:
                                  index === routeIndex
                                    ? "selected"
                                    : "alternate",
                              },
                            };

                            // New segment starts with previous segment's last coordinate.
                            if (previous)
                              segment.geometry.coordinates.push(
                                previous.geometry.coordinates[
                                  previous.geometry.coordinates.length - 1
                                ]
                              );
                            segment.geometry.coordinates.push(c);
                            if (congestion) {
                              segment.properties.congestion =
                                feature.legs[0].annotation.congestion[i - 1];
                            }
                            features.push(segment);
                          }
                        });
                        geojson.features = geojson.features.concat(features);
                        if (index === routeIndex) {
                          // Collect any possible waypoints from steps
                          feature.legs[0].steps.forEach(function (d) {
                            if (d.maneuver.type === "waypoint") {
                              geojson.features.push({
                                type: "Feature",
                                geometry: d.maneuver.location,
                                properties: {
                                  id: "waypoint",
                                },
                              });
                            }
                          });
                        }
                      });
                    }
                    if (
                      _this3._map.style &&
                      _this3._map.getSource("directions")
                    ) {
                      _this3._map.getSource("directions").setData(geojson);
                    }
                  });
                },
              },
              {
                key: "_clickHandler",
                value: function _clickHandler() {
                  var timer = null;
                  var delay = 250;
                  return function (event) {
                    if (!timer) {
                      var singleClickHandler = this._onSingleClick.bind(this);
                      timer = setTimeout(function () {
                        singleClickHandler(event);
                        timer = null;
                      }, delay);
                    } else {
                      clearTimeout(timer);
                      timer = null;
                      this._map.zoomIn();
                    }
                  };
                },
              },
              {
                key: "_onSingleClick",
                value: function _onSingleClick(e) {
                  var _this4 = this;
                  var _store$getState4 = store.getState(),
                    origin = _store$getState4.origin;
                  var coords = [e.lngLat.lng, e.lngLat.lat];
                  if (!origin.geometry) {
                    this.actions.setOriginFromCoordinates(coords);
                  } else {
                    var features = this._map.queryRenderedFeatures(e.point, {
                      layers: [
                        "directions-origin-point",
                        "directions-destination-point",
                        "directions-waypoint-point",
                        "directions-route-line-alt",
                      ],
                    });
                    if (features.length) {
                      // Remove any waypoints
                      features.forEach(function (f) {
                        if (f.layer.id === "directions-waypoint-point") {
                          _this4.actions.removeWaypoint(f);
                        }
                      });
                      if (features[0].properties.route === "alternate") {
                        var index = features[0].properties["route-index"];
                        this.actions.setRouteIndex(index);
                      }
                    } else {
                      this.actions.setDestinationFromCoordinates(coords);
                      this._map.flyTo({
                        center: coords,
                      });
                    }
                  }
                },
              },
              {
                key: "_move",
                value: function _move(e) {
                  var _this5 = this;
                  var _store$getState5 = store.getState(),
                    hoverMarker = _store$getState5.hoverMarker;
                  var features = this._map.queryRenderedFeatures(e.point, {
                    layers: [
                      "directions-route-line-alt",
                      "directions-route-line",
                      "directions-origin-point",
                      "directions-destination-point",
                      "directions-hover-point",
                    ],
                  });
                  this._map.getCanvas().style.cursor = features.length
                    ? "pointer"
                    : "";
                  if (features.length) {
                    this.isCursorOverPoint = features[0];
                    this._map.dragPan.disable();

                    // Add a possible waypoint marker when hovering over the active route line
                    features.forEach(function (feature) {
                      if (feature.layer.id === "directions-route-line") {
                        _this5.actions.hoverMarker([
                          e.lngLat.lng,
                          e.lngLat.lat,
                        ]);
                      } else if (hoverMarker.geometry) {
                        _this5.actions.hoverMarker(null);
                      }
                    });
                  } else if (this.isCursorOverPoint) {
                    this.isCursorOverPoint = false;
                    this._map.dragPan.enable();
                  }
                },
              },
              {
                key: "_onDragDown",
                value: function _onDragDown() {
                  if (!this.isCursorOverPoint) return;
                  this.isDragging = this.isCursorOverPoint;
                  this._map.getCanvas().style.cursor = "grab";
                  this._map.on("mousemove", this.onDragMove);
                  this._map.on("mouseup", this.onDragUp);
                  this._map.on("touchmove", this.onDragMove);
                  this._map.on("touchend", this.onDragUp);
                },
              },
              {
                key: "_onDragMove",
                value: function _onDragMove(e) {
                  if (!this.isDragging) return;
                  var coords = [e.lngLat.lng, e.lngLat.lat];
                  switch (this.isDragging.layer.id) {
                    case "directions-origin-point":
                      this.actions.createOrigin(coords);
                      break;
                    case "directions-destination-point":
                      this.actions.createDestination(coords);
                      break;
                    case "directions-hover-point":
                      this.actions.hoverMarker(coords);
                      break;
                  }
                },
              },
              {
                key: "_onDragUp",
                value: function _onDragUp() {
                  if (!this.isDragging) return;
                  var _store$getState6 = store.getState(),
                    hoverMarker = _store$getState6.hoverMarker,
                    origin = _store$getState6.origin,
                    destination = _store$getState6.destination;
                  switch (this.isDragging.layer.id) {
                    case "directions-origin-point":
                      this.actions.setOriginFromCoordinates(
                        origin.geometry.coordinates
                      );
                      break;
                    case "directions-destination-point":
                      this.actions.setDestinationFromCoordinates(
                        destination.geometry.coordinates
                      );
                      break;
                    case "directions-hover-point":
                      // Add waypoint if a sufficent amount of dragging has occurred.
                      if (
                        hoverMarker.geometry &&
                        !_utils["default"].coordinateMatch(
                          this.isDragging,
                          hoverMarker
                        )
                      ) {
                        this.actions.addWaypoint(0, hoverMarker);
                      }
                      break;
                  }
                  this.isDragging = false;
                  this._map.getCanvas().style.cursor = "";
                  this._map.off("touchmove", this.onDragMove);
                  this._map.off("touchend", this.onDragUp);
                  this._map.off("mousemove", this.onDragMove);
                  this._map.off("mouseup", this.onDragUp);
                },

                // API Methods
                // ============================

                /**
                 * Turn on or off interactivity
                 * @param {Boolean} state sets interactivity based on a state of `true` or `false`.
                 * @returns {MapboxDirections} this
                 */
              },
              {
                key: "interactive",
                value: function interactive(state) {
                  if (state) {
                    this._map.on("touchstart", this.move);
                    this._map.on("touchstart", this.onDragDown);
                    this._map.on("mousedown", this.onDragDown);
                    this._map.on("mousemove", this.move);
                    this._map.on("click", this.onClick);
                  } else {
                    this._map.off("touchstart", this.move);
                    this._map.off("touchstart", this.onDragDown);
                    this._map.off("mousedown", this.onDragDown);
                    this._map.off("mousemove", this.move);
                    this._map.off("click", this.onClick);
                  }
                  return this;
                },

                /**
                 * Returns the origin of the current route.
                 * @returns {Object} origin
                 */
              },
              {
                key: "getOrigin",
                value: function getOrigin() {
                  return store.getState().origin;
                },

                /**
                 * Sets origin. _Note:_ calling this method requires the [map load event](https://www.mapbox.com/mapbox-gl-js/api/#Map.load)
                 * to have run.
                 * @param {Array<number>|String} query An array of coordinates [lng, lat] or location name as a string.
                 * @returns {MapboxDirections} this
                 */
              },
              {
                key: "setOrigin",
                value: function setOrigin(query) {
                  if (typeof query === "string") {
                    this.actions.queryOrigin(query);
                  } else {
                    this.actions.setOriginFromCoordinates(query);
                  }
                  return this;
                },

                /**
                 * Returns the destination of the current route.
                 * @returns {Object} destination
                 */
              },
              {
                key: "getDestination",
                value: function getDestination() {
                  return store.getState().destination;
                },

                /**
                 * Sets destination. _Note:_ calling this method requires the [map load event](https://www.mapbox.com/mapbox-gl-js/api/#Map.load)
                 * to have run.
                 * @param {Array<number>|String} query An array of coordinates [lng, lat] or location name as a string.
                 * @returns {MapboxDirections} this
                 */
              },
              {
                key: "setDestination",
                value: function setDestination(query) {
                  if (typeof query === "string") {
                    this.actions.queryDestination(query);
                  } else {
                    this.actions.setDestinationFromCoordinates(query);
                  }
                  return this;
                },

                /**
                 * Swap the origin and destination.
                 * @returns {MapboxDirections} this
                 */
              },
              {
                key: "reverse",
                value: function reverse() {
                  this.actions.reverse();
                  return this;
                },

                /**
                 * Add a waypoint to the route. _Note:_ calling this method requires the
                 * [map load event](https://www.mapbox.com/mapbox-gl-js/api/#Map.load) to have run.
                 * @param {Number} index position waypoint should be placed in the waypoint array
                 * @param {Array<number>|Point} waypoint can be a GeoJSON Point Feature or [lng, lat] coordinates.
                 * @returns {MapboxDirections} this;
                 */
              },
              {
                key: "addWaypoint",
                value: function addWaypoint(index, waypoint) {
                  if (!waypoint.type)
                    waypoint = _utils["default"].createPoint(waypoint, {
                      id: "waypoint",
                    });
                  this.actions.addWaypoint(index, waypoint);
                  return this;
                },

                /**
                 * Change the waypoint at a given index in the route. _Note:_ calling this
                 * method requires the [map load event](https://www.mapbox.com/mapbox-gl-js/api/#Map.load)
                 * to have run.
                 * @param {Number} index indexed position of the waypoint to update
                 * @param {Array<number>|Point} waypoint can be a GeoJSON Point Feature or [lng, lat] coordinates.
                 * @returns {MapboxDirections} this;
                 */
              },
              {
                key: "setWaypoint",
                value: function setWaypoint(index, waypoint) {
                  if (!waypoint.type)
                    waypoint = _utils["default"].createPoint(waypoint, {
                      id: "waypoint",
                    });
                  this.actions.setWaypoint(index, waypoint);
                  return this;
                },

                /**
                 * Remove a waypoint from the route.
                 * @param {Number} index position in the waypoints array.
                 * @returns {MapboxDirections} this;
                 */
              },
              {
                key: "removeWaypoint",
                value: function removeWaypoint(index) {
                  var _store$getState7 = store.getState(),
                    waypoints = _store$getState7.waypoints;
                  this.actions.removeWaypoint(waypoints[index]);
                  return this;
                },

                /**
                 * Fetch all current waypoints in a route.
                 * @returns {Array} waypoints
                 */
              },
              {
                key: "getWaypoints",
                value: function getWaypoints() {
                  return store.getState().waypoints;
                },

                /**
                 * Removes all routes and waypoints from the map.
                 *
                 * @returns {MapboxDirections} this;
                 */
              },
              {
                key: "removeRoutes",
                value: function removeRoutes() {
                  this.actions.clearOrigin();
                  this.actions.clearDestination();
                  return this;
                },

                /**
                 * Subscribe to events that happen within the plugin.
                 * @param {String} type name of event. Available events and the data passed into their respective event objects are:
                 *
                 * - __clear__ `{ type: } Type is one of 'origin' or 'destination'`
                 * - __loading__ `{ type: } Type is one of 'origin' or 'destination'`
                 * - __profile__ `{ profile } Profile is one of 'driving', 'walking', or 'cycling'`
                 * - __origin__ `{ feature } Fired when origin is set`
                 * - __destination__ `{ feature } Fired when destination is set`
                 * - __route__ `{ route } Fired when a route is updated`
                 * - __error__ `{ error } Error as string`
                 * @param {Function} fn function that's called when the event is emitted.
                 * @returns {MapboxDirections} this;
                 */
              },
              {
                key: "on",
                value: function on(type, fn) {
                  this.actions.eventSubscribe(type, fn);
                  return this;
                },
              },
            ]);
            return MapboxDirections;
          })();
          exports["default"] = MapboxDirections;
        },
        {
          "./actions": 25,
          "./controls/inputs": 28,
          "./controls/instructions": 29,
          "./directions_style": 31,
          "./reducers": 33,
          "./utils": 34,
          "@mapbox/polyline": 6,
          redux: 18,
          "redux-thunk": 17,
        },
      ],
      31: [
        function (require, module, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports["default"] = void 0;
          var style = [
            {
              id: "directions-route-line-alt",
              type: "line",
              source: "directions",
              layout: {
                "line-cap": "round",
                "line-join": "round",
              },
              paint: {
                "line-color": "#bbb",
                "line-width": 4,
              },
              filter: [
                "all",
                ["in", "$type", "LineString"],
                ["in", "route", "alternate"],
              ],
            },
            {
              id: "directions-route-line-casing",
              type: "line",
              source: "directions",
              layout: {
                "line-cap": "round",
                "line-join": "round",
              },
              paint: {
                "line-color": "#2d5f99",
                "line-width": 12,
              },
              filter: [
                "all",
                ["in", "$type", "LineString"],
                ["in", "route", "selected"],
              ],
            },
            {
              id: "directions-route-line",
              type: "line",
              source: "directions",
              layout: {
                "line-cap": "butt",
                "line-join": "round",
              },
              paint: {
                "line-color": {
                  property: "congestion",
                  type: "categorical",
                  default: "#4882c5",
                  stops: [
                    ["unknown", "#4882c5"],
                    ["low", "#4882c5"],
                    ["moderate", "#f09a46"],
                    ["heavy", "#e34341"],
                    ["severe", "#8b2342"],
                  ],
                },
                "line-width": 7,
              },
              filter: [
                "all",
                ["in", "$type", "LineString"],
                ["in", "route", "selected"],
              ],
            },
            {
              id: "directions-hover-point-casing",
              type: "circle",
              source: "directions",
              paint: {
                "circle-radius": 8,
                "circle-color": "#fff",
              },
              filter: ["all", ["in", "$type", "Point"], ["in", "id", "hover"]],
            },
            {
              id: "directions-hover-point",
              type: "circle",
              source: "directions",
              paint: {
                "circle-radius": 6,
                "circle-color": "#3bb2d0",
              },
              filter: ["all", ["in", "$type", "Point"], ["in", "id", "hover"]],
            },
            {
              id: "directions-waypoint-point-casing",
              type: "circle",
              source: "directions",
              paint: {
                "circle-radius": 8,
                "circle-color": "#fff",
              },
              filter: [
                "all",
                ["in", "$type", "Point"],
                ["in", "id", "waypoint"],
              ],
            },
            {
              id: "directions-waypoint-point",
              type: "circle",
              source: "directions",
              paint: {
                "circle-radius": 6,
                "circle-color": "#8a8bc9",
              },
              filter: [
                "all",
                ["in", "$type", "Point"],
                ["in", "id", "waypoint"],
              ],
            },
            {
              id: "directions-origin-point",
              type: "circle",
              source: "directions",
              paint: {
                "circle-radius": 18,
                "circle-color": "#3bb2d0",
              },
              filter: [
                "all",
                ["in", "$type", "Point"],
                ["in", "marker-symbol", "A"],
              ],
            },
            {
              id: "directions-origin-label",
              type: "symbol",
              source: "directions",
              layout: {
                "text-field": "A",
                "text-font": ["Open Sans Bold", "Arial Unicode MS Bold"],
                "text-size": 12,
              },
              paint: {
                "text-color": "#fff",
              },
              filter: [
                "all",
                ["in", "$type", "Point"],
                ["in", "marker-symbol", "A"],
              ],
            },
            {
              id: "directions-destination-point",
              type: "circle",
              source: "directions",
              paint: {
                "circle-radius": 18,
                "circle-color": "#8a8bc9",
              },
              filter: [
                "all",
                ["in", "$type", "Point"],
                ["in", "marker-symbol", "B"],
              ],
            },
            {
              id: "directions-destination-label",
              type: "symbol",
              source: "directions",
              layout: {
                "text-field": "B",
                "text-font": ["Open Sans Bold", "Arial Unicode MS Bold"],
                "text-size": 12,
              },
              paint: {
                "text-color": "#fff",
              },
              filter: [
                "all",
                ["in", "$type", "Point"],
                ["in", "marker-symbol", "B"],
              ],
            },
          ];
          var _default = style;
          exports["default"] = _default;
        },
        {},
      ],
      32: [
        function (require, module, exports) {
          "use strict";

          var _directions = _interopRequireDefault(require("./directions"));
          function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : { default: obj };
          }
          module.exports = _directions["default"];
        },
        { "./directions": 30 },
      ],
      33: [
        function (require, module, exports) {
          "use strict";

          function _typeof(obj) {
            "@babel/helpers - typeof";
            return (
              (_typeof =
                "function" == typeof Symbol &&
                "symbol" == typeof Symbol.iterator
                  ? function (obj) {
                      return typeof obj;
                    }
                  : function (obj) {
                      return obj &&
                        "function" == typeof Symbol &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? "symbol"
                        : typeof obj;
                    }),
              _typeof(obj)
            );
          }
          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports["default"] = void 0;
          var types = _interopRequireWildcard(
            require("../constants/action_types.js")
          );
          var _deepAssign = _interopRequireDefault(require("deep-assign"));
          function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : { default: obj };
          }
          function _getRequireWildcardCache(nodeInterop) {
            if (typeof WeakMap !== "function") return null;
            var cacheBabelInterop = new WeakMap();
            var cacheNodeInterop = new WeakMap();
            return (_getRequireWildcardCache =
              function _getRequireWildcardCache(nodeInterop) {
                return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
              })(nodeInterop);
          }
          function _interopRequireWildcard(obj, nodeInterop) {
            if (!nodeInterop && obj && obj.__esModule) {
              return obj;
            }
            if (
              obj === null ||
              (_typeof(obj) !== "object" && typeof obj !== "function")
            ) {
              return { default: obj };
            }
            var cache = _getRequireWildcardCache(nodeInterop);
            if (cache && cache.has(obj)) {
              return cache.get(obj);
            }
            var newObj = {};
            var hasPropertyDescriptor =
              Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var key in obj) {
              if (
                key !== "default" &&
                Object.prototype.hasOwnProperty.call(obj, key)
              ) {
                var desc = hasPropertyDescriptor
                  ? Object.getOwnPropertyDescriptor(obj, key)
                  : null;
                if (desc && (desc.get || desc.set)) {
                  Object.defineProperty(newObj, key, desc);
                } else {
                  newObj[key] = obj[key];
                }
              }
            }
            newObj["default"] = obj;
            if (cache) {
              cache.set(obj, newObj);
            }
            return newObj;
          }
          var initialState = {
            // Options set on initialization
            api: "https://api.mapbox.com/directions/v5/",
            profile: "mapbox/walking",
            alternatives: false,
            congestion: false,
            unit: "imperial",
            flyTo: true,
            placeholderOrigin: "Choose a starting place",
            placeholderDestination: "Choose destination",
            zoom: 16,
            language: "en",
            compile: null,
            proximity: false,
            styles: [],
            // UI controls
            controls: {
              profileSwitcher: true,
              inputs: true,
              instructions: true,
            },
            // Optional setting to pass options available to mapbox-gl-geocoder
            geocoder: {},
            interactive: true,
            // Container for client registered events
            events: {},
            // Marker feature drawn on the map at any point.
            origin: {},
            destination: {},
            hoverMarker: {},
            waypoints: [],
            // User input strings or result returned from geocoder
            originQuery: null,
            destinationQuery: null,
            originQueryCoordinates: null,
            destinationQueryCoordinates: null,
            // Directions data
            directions: [],
            routeIndex: 0,
            routePadding: 80,
          };
          function data() {
            var state =
              arguments.length > 0 && arguments[0] !== undefined
                ? arguments[0]
                : initialState;
            var action = arguments.length > 1 ? arguments[1] : undefined;
            switch (action.type) {
              case types.SET_OPTIONS:
                return (0, _deepAssign["default"])({}, state, action.options);
              case types.DIRECTIONS_PROFILE:
                return Object.assign({}, state, {
                  profile: action.profile,
                });
              case types.ORIGIN:
                return Object.assign({}, state, {
                  origin: action.origin,
                  hoverMarker: {},
                });
              case types.DESTINATION:
                return Object.assign({}, state, {
                  destination: action.destination,
                  hoverMarker: {},
                });
              case types.HOVER_MARKER:
                return Object.assign({}, state, {
                  hoverMarker: action.hoverMarker,
                });
              case types.WAYPOINTS:
                return Object.assign({}, state, {
                  waypoints: action.waypoints,
                });
              case types.ORIGIN_QUERY:
                return Object.assign({}, state, {
                  originQuery: action.query,
                });
              case types.DESTINATION_QUERY:
                return Object.assign({}, state, {
                  destinationQuery: action.query,
                });
              case types.ORIGIN_FROM_COORDINATES:
                return Object.assign({}, state, {
                  originQueryCoordinates: action.coordinates,
                });
              case types.DESTINATION_FROM_COORDINATES:
                return Object.assign({}, state, {
                  destinationQueryCoordinates: action.coordinates,
                });
              case types.ORIGIN_CLEAR:
                return Object.assign({}, state, {
                  origin: {},
                  originQuery: "",
                  waypoints: [],
                  directions: [],
                });
              case types.DESTINATION_CLEAR:
                return Object.assign({}, state, {
                  destination: {},
                  destinationQuery: "",
                  waypoints: [],
                  directions: [],
                });
              case types.DIRECTIONS:
                return Object.assign({}, state, {
                  directions: action.directions,
                });
              case types.ROUTE_INDEX:
                return Object.assign({}, state, {
                  routeIndex: action.routeIndex,
                });
              case types.ERROR:
                return Object.assign({}, state, {
                  error: action.error,
                });
              default:
                return state;
            }
          }
          var _default = data;
          exports["default"] = _default;
        },
        { "../constants/action_types.js": 26, "deep-assign": 8 },
      ],
      34: [
        function (require, module, exports) {
          "use strict";

          Object.defineProperty(exports, "__esModule", {
            value: true,
          });
          exports["default"] = void 0;
          function validCoords(coords) {
            return (
              coords[0] >= -180 &&
              coords[0] <= 180 &&
              coords[1] >= -90 &&
              coords[1] <= 90
            );
          }
          function coordinateMatch(a, b) {
            a = a.geometry.coordinates;
            b = b.geometry.coordinates;
            return (
              a.join() === b.join() ||
              (a[0].toFixed(3) === b[0].toFixed(3) &&
                a[1].toFixed(3) === b[1].toFixed(3))
            );
          }
          function wrap(n) {
            var d = 180 - -180;
            var w = ((((n - -180) % d) + d) % d) + -180;
            return w === -180 ? 180 : w;
          }
          function roundWithOriginalPrecision(input, original) {
            var precision = 0;
            if (Math.floor(original) !== original) {
              precision = original.toString().split(".")[1].length;
            }
            return input.toFixed(Math.min(precision, 5));
          }
          function createPoint(coordinates, properties) {
            return {
              type: "Feature",
              geometry: {
                type: "Point",
                coordinates: coordinates,
              },
              properties: properties ? properties : {},
            };
          }
          var format = {
            duration: function duration(s) {
              var m = Math.floor(s / 60),
                h = Math.floor(m / 60);
              s %= 60;
              m %= 60;
              if (h === 0 && m === 0) return s + "s";
              if (h === 0) return m + "min";
              return h + "h " + m + "min";
            },
            imperial: function imperial(m) {
              var mi = m / 1609.344;
              if (mi >= 100) return mi.toFixed(0) + "mi";
              if (mi >= 10) return mi.toFixed(1) + "mi";
              if (mi >= 0.1) return mi.toFixed(2) + "mi";
              return (mi * 5280).toFixed(0) + "ft";
            },
            metric: function metric(m) {
              if (m >= 100000) return (m / 1000).toFixed(0) + "km";
              if (m >= 10000) return (m / 1000).toFixed(1) + "km";
              if (m >= 100) return (m / 1000).toFixed(2) + "km";
              return m.toFixed(0) + "m";
            },
          };
          var _default = {
            format: format,
            coordinateMatch: coordinateMatch,
            createPoint: createPoint,
            validCoords: validCoords,
            wrap: wrap,
            roundWithOriginalPrecision: roundWithOriginalPrecision,
          };
          exports["default"] = _default;
        },
        {},
      ],
    },
    {},
    [32]
  )(32);
});
